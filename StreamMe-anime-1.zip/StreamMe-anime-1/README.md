# StreamMe Anime - Complete Anime Streaming Platform

A comprehensive anime streaming and community platform built with React, TypeScript, and Express.js.

## Features

### 🎌 Complete Application
- **Authentication System**: JWT-based login and registration
- **Real-time Chat**: WebSocket communication with AI integration
- **Anime Catalog**: Browse and search anime with trending section
- **User Profiles**: Complete profile management with stats and achievements
- **Settings Page**: Comprehensive account management
- **AI Integration**: Multiple AI models (Gemini, Grok, Image Generation)
- **Premium Features**: Unlock code system (demo code: 0814880)
- **Responsive Design**: Beautiful anime-themed UI

### 📱 Pages Included
- **Home Page**: Anime catalog with hero section and trending
- **Auth Page**: Login and registration forms
- **Chat Room**: Real-time messaging with AI chatbots
- **Profile Page**: User stats, achievements, and account info
- **Settings Page**: Profile, premium, notifications, and security tabs
- **404 Page**: Custom not found page

### 🛠 Technology Stack
- **Frontend**: React 18, TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: Express.js, JWT authentication, WebSocket
- **Database**: In-memory storage with MongoDB schema compatibility
- **Build Tools**: Vite, ESBuild
- **UI Components**: Radix UI, Lucide React icons

## Quick Start

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Start Development Server**:
   ```bash
   npm run dev
   ```

3. **Access Application**:
   - Open http://localhost:5000
   - Register a new account or login
   - Use unlock code `0814880` for premium chat access

## Project Structure

```
├── client/src/
│   ├── components/         # UI components
│   ├── pages/             # Application pages
│   ├── hooks/             # Custom React hooks
│   └── lib/               # Utilities and configuration
├── server/                # Express.js backend
├── shared/                # Shared types and schemas
└── README.md
```

## Features Overview

### Authentication
- JWT token-based authentication
- Secure password hashing with bcrypt
- Protected routes and API endpoints

### Real-time Chat
- WebSocket communication
- AI chatbot integration
- Message history and user management

### User Management
- Complete profile system
- Settings and preferences
- Premium unlock codes
- User statistics and achievements

### Anime Catalog
- Browse anime collection
- Search and filtering
- Trending section
- Responsive card layout

## API Endpoints

- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user
- `GET /api/anime` - Get anime catalog
- `GET /api/anime/trending` - Get trending anime
- `POST /api/chat/messages` - Send chat message
- `GET /api/user/stats` - Get user statistics

## Environment Variables

```env
JWT_SECRET=your_jwt_secret_key
NODE_ENV=development
```

## Development

The application uses in-memory storage for development. For production, configure your preferred database (MongoDB, PostgreSQL, etc.) in the storage layer.

## Deployment

Ready for deployment on any platform supporting Node.js applications. The build process creates optimized bundles for both frontend and backend.

## License

MIT License - Feel free to use this project for learning and development.

---

Built with ❤️ using modern web technologies