#!/bin/bash

# StreamMe Anime Vercel Deployment Script

echo "🚀 Starting StreamMe Anime deployment to Vercel..."

# Build the client
echo "📦 Building client application..."
npm run build:client

# Build the server for Vercel serverless
echo "🔧 Building server for Vercel..."
npx esbuild server/index.ts --platform=node --packages=external --bundle --format=cjs --outfile=api/index.js --target=node18

# Copy shared files
echo "📋 Copying shared modules..."
mkdir -p api/shared
cp -r shared/* api/shared/

# Deploy to Vercel
echo "🌐 Deploying to Vercel..."
npx vercel --prod

echo "✅ Deployment complete!"
echo "🎯 Your StreamMe Anime app is now live!"