// Vercel serverless function entry point
const express = require('express');

const app = express();

// CORS middleware
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  if (req.method === 'OPTIONS') {
    res.sendStatus(200);
  } else {
    next();
  }
});

// Middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// In-memory storage simulation
let users = [];
let chatMessages = [];

// Anime search using zetsu.xyz API
app.get('/api/anime/search', async (req, res) => {
  try {
    const { q } = req.query;
    if (!q) {
      return res.status(400).json({ error: 'Search query required' });
    }

    const apiKey = 'dbcbb1d2cd6121874d41b092f4d93a61';
    const searchUrl = `https://api.zetsu.xyz/animesu/search?q=${encodeURIComponent(q)}&apikey=${apiKey}`;
    
    console.log('Searching anime with URL:', searchUrl);
    
    const response = await fetch(searchUrl);
    const data = await response.json();
    
    console.log('API Response status:', response.status);
    console.log('API Response data:', data);
    
    if (!response.ok || !data.status) {
      throw new Error(`API error: ${response.status} - ${data.message || 'Unknown error'}`);
    }
    
    res.json(data);
  } catch (error) {
    console.error('Error searching anime:', error);
    res.status(500).json({ error: 'Failed to search anime', details: error.message });
  }
});

// Anime details using zetsu.xyz API
app.get('/api/anime/detail', async (req, res) => {
  try {
    const { url } = req.query;
    if (!url) {
      return res.status(400).json({ error: 'Anime URL required' });
    }

    const apiKey = 'dbcbb1d2cd6121874d41b092f4d93a61';
    const detailUrl = `https://api.zetsu.xyz/animesu/detail?url=${encodeURIComponent(url)}&apikey=${apiKey}`;
    
    console.log('Fetching anime details with URL:', detailUrl);
    
    const response = await fetch(detailUrl);
    const data = await response.json();
    
    console.log('Detail API Response status:', response.status);
    console.log('Detail API Response data:', data);
    
    if (!response.ok || !data.status) {
      throw new Error(`API error: ${response.status} - ${data.message || 'Unknown error'}`);
    }
    
    res.json(data);
  } catch (error) {
    console.error('Error fetching anime details:', error);
    res.status(500).json({ error: 'Failed to fetch anime details', details: error.message });
  }
});

// Episode download using zetsu.xyz API
app.get('/api/anime/download-episode', async (req, res) => {
  try {
    const { url } = req.query;
    if (!url) {
      return res.status(400).json({ error: 'Episode URL required' });
    }

    const apiKey = 'dbcbb1d2cd6121874d41b092f4d93a61';
    const downloadUrl = `https://api.zetsu.xyz/animesu/download?url=${encodeURIComponent(url)}&apikey=${apiKey}`;
    
    console.log('Fetching episode downloads with URL:', downloadUrl);
    
    const response = await fetch(downloadUrl);
    const data = await response.json();
    
    console.log('Download API Response status:', response.status);
    console.log('Download API Response data:', data);
    
    if (!response.ok || !data.status) {
      throw new Error(`API error: ${response.status} - ${data.message || 'Unknown error'}`);
    }
    
    res.json(data);
  } catch (error) {
    console.error('Error fetching download links:', error);
    res.status(500).json({ error: 'Failed to fetch download links', details: error.message });
  }
});

// Basic auth endpoints
app.post('/api/auth/register', async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const user = {
      id: Date.now().toString(),
      username,
      email,
      isPremium: false,
      chatAccess: true,
      aiTrialsLeft: 10
    };
    users.push(user);
    
    res.status(201).json({
      user,
      token: 'demo-token-' + user.id
    });
  } catch (error) {
    res.status(400).json({ error: 'Registration failed' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email } = req.body;
    let user = users.find(u => u.email === email);
    
    if (!user) {
      user = {
        id: Date.now().toString(),
        username: 'Demo User',
        email,
        isPremium: false,
        chatAccess: true,
        aiTrialsLeft: 10
      };
      users.push(user);
    }
    
    res.json({
      user,
      token: 'demo-token-' + user.id
    });
  } catch (error) {
    res.status(401).json({ error: 'Login failed' });
  }
});

// Sample anime data
app.get('/api/anime', (req, res) => {
  const sampleAnime = [
    {
      id: "1",
      title: "Demon Slayer",
      description: "A young boy becomes a demon slayer to save his sister and avenge his family.",
      genre: ["Action", "Supernatural", "Historical"],
      releaseDate: "2019-04-06",
      rating: 8.7,
      imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400",
      downloadUrl: "https://example.com/demon-slayer",
      episodes: 44,
      status: "Completed",
      type: "TV Series",
      studio: "Ufotable",
      duration: "24 min per ep"
    }
  ];
  res.json(sampleAnime);
});

app.get('/api/anime/trending', (req, res) => {
  const trending = [
    {
      id: "3",
      title: "Attack on Titan",
      description: "Humanity fights for survival against giant humanoid Titans.",
      genre: ["Action", "Drama", "Fantasy"],
      releaseDate: "2013-04-07",
      rating: 9.0,
      imageUrl: "https://images.unsplash.com/photo-1606041258204-b2d5f2d3c2d7?w=400",
      downloadUrl: "https://example.com/attack-on-titan",
      episodes: 87,
      status: "Completed",
      type: "TV Series",
      studio: "WIT Studio",
      duration: "24 min per ep"
    }
  ];
  res.json(trending);
});

app.get('/api/stats', (req, res) => {
  res.json({
    totalAnime: 4,
    activeUsers: Math.floor(Math.random() * 20000) + 5000,
    downloadsToday: Math.floor(Math.random() * 1000) + 500,
    seriesCount: 3,
    moviesCount: 1
  });
});

// Handle all routes
app.all('*', (req, res) => {
  res.status(404).json({ error: 'Not found' });
});

// Export for Vercel
module.exports = app;