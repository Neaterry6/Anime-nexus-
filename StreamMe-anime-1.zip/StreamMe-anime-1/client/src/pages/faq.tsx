import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { 
  ArrowLeft, 
  HelpCircle, 
  ExternalLink, 
  User, 
  Code, 
  Download, 
  BookOpen, 
  MessageSquare,
  Star,
  Shield,
  Smartphone,
  Globe
} from "lucide-react";

export default function FAQPage() {
  const [, setLocation] = useLocation();

  const faqs = [
    {
      category: "General",
      questions: [
        {
          question: "What is Stream Me ID?",
          answer: "Stream Me ID is a comprehensive multimedia streaming and download platform that combines anime streaming, manga reading, YouTube content downloads, and social features. It's designed to be your all-in-one entertainment hub with personalized recommendations and community interaction."
        },
        {
          question: "Is Stream Me ID free to use?",
          answer: "Yes! Stream Me ID offers a free tier with access to basic features including manga reading, anime browsing, and limited AI chat trials. Premium features are available through our unlock code system or subscription plans."
        },
        {
          question: "What devices are supported?",
          answer: "Stream Me ID is a web application that works on all modern devices including desktops, laptops, tablets, and smartphones. It's fully responsive and optimized for mobile use."
        }
      ]
    },
    {
      category: "Features",
      questions: [
        {
          question: "What content can I download?",
          answer: "You can download YouTube videos (MP4) and music (MP3) in various quality options, anime episodes from our integrated APIs, and save manga chapters for offline reading. All downloads respect content creators' rights and fair use policies."
        },
        {
          question: "How does the recommendation engine work?",
          answer: "Our AI-powered recommendation engine analyzes your reading history, favorite genres, completion rates, and reading patterns to suggest new manga and anime that match your preferences. The more you use the platform, the better the recommendations become."
        },
        {
          question: "What AI models are available?",
          answer: "We offer multiple AI chatbot models including Google Gemini, Grok, and image generation capabilities. Free users get 3 trial conversations, while premium users enjoy unlimited access."
        },
        {
          question: "Can I share content with friends?",
          answer: "Absolutely! We have comprehensive social sharing features that let you share manga discoveries, anime recommendations, and favorite content across 6 social platforms including Twitter, Facebook, Discord, Reddit, WhatsApp, and Telegram."
        }
      ]
    },
    {
      category: "Technical",
      questions: [
        {
          question: "How do I get premium access?",
          answer: "Premium access can be obtained through unlock codes or subscription plans. Contact the developer through the portfolio link below for unlock codes and premium features."
        },
        {
          question: "Is my data secure?",
          answer: "Yes, we use industry-standard security measures including JWT authentication, bcrypt password hashing, and secure database connections. Your personal data and reading history are protected and never shared with third parties."
        },
        {
          question: "Can I sync my data across devices?",
          answer: "Yes! Your reading history, favorites, bookmarks, and preferences are automatically synced across all your devices when you're logged in to your account."
        },
        {
          question: "What if I encounter bugs or issues?",
          answer: "Please report any bugs or issues through the developer contact information below. We actively maintain and improve the platform based on user feedback."
        }
      ]
    },
    {
      category: "Content",
      questions: [
        {
          question: "How often is new content added?",
          answer: "We continuously update our content library through integration with multiple APIs including MangaDex, anime databases, and YouTube. New manga chapters and anime episodes are added as they become available."
        },
        {
          question: "Can I request specific content?",
          answer: "Yes! You can suggest new features or content through the developer contact below. We consider all user requests and implement popular suggestions in future updates."
        },
        {
          question: "Are there content restrictions?",
          answer: "We follow standard content guidelines and age-appropriate restrictions. All content is sourced from legitimate APIs and follows fair use policies."
        }
      ]
    }
  ];

  const features = [
    { icon: BookOpen, title: "Manga Reader", description: "Comprehensive manga reading with favorites and bookmarks" },
    { icon: Download, title: "YouTube Downloader", description: "Download videos and music in multiple formats and qualities" },
    { icon: MessageSquare, title: "AI Chatbots", description: "Multiple AI models for assistance and entertainment" },
    { icon: Star, title: "Recommendations", description: "Personalized content suggestions based on your history" },
    { icon: Shield, title: "Secure Platform", description: "Protected user data with modern security standards" },
    { icon: Globe, title: "Social Sharing", description: "Share discoveries across 6 social platforms" }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-anime-dark via-purple-900 to-anime-dark text-white">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-anime-dark/95 backdrop-blur-md border-b border-purple-500/30">
        <div className="max-w-6xl mx-auto p-4">
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              onClick={() => setLocation('/')}
              className="text-purple-400 hover:text-purple-300 hover:bg-purple-500/20 p-2"
              data-testid="button-back-home"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <HelpCircle className="w-8 h-8 text-purple-400" />
            <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
              FAQ & App Info
            </h1>
          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto p-4 space-y-8">
        {/* App Overview */}
        <Card className="bg-anime-dark/50 border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-2xl text-purple-400 flex items-center gap-2">
              <Code className="w-6 h-6" />
              About Stream Me ID
            </CardTitle>
            <CardDescription className="text-gray-300 text-lg">
              A comprehensive multimedia streaming and download platform built with modern web technologies
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="prose prose-invert max-w-none">
              <p className="text-gray-300 leading-relaxed">
                Stream Me ID is a feature-rich entertainment platform that combines anime streaming, manga reading, 
                YouTube content downloads, and AI-powered interactions. Built with React, TypeScript, and Express.js, 
                it offers a seamless user experience across all devices with real-time features and personalized content discovery.
              </p>
            </div>

            {/* Features Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
              {features.map((feature, index) => (
                <div 
                  key={index} 
                  className="bg-purple-900/30 border border-purple-500/20 rounded-lg p-4 hover:border-purple-400/40 transition-colors"
                >
                  <feature.icon className="w-8 h-8 text-purple-400 mb-2" />
                  <h3 className="font-semibold text-white mb-1">{feature.title}</h3>
                  <p className="text-sm text-gray-400">{feature.description}</p>
                </div>
              ))}
            </div>

            {/* Tech Stack */}
            <div className="mt-6">
              <h3 className="text-lg font-semibold text-purple-300 mb-3">Technology Stack</h3>
              <div className="flex flex-wrap gap-2">
                {["React", "TypeScript", "Express.js", "PostgreSQL", "Tailwind CSS", "WebSocket", "Drizzle ORM", "JWT Auth"].map((tech) => (
                  <Badge key={tech} variant="secondary" className="bg-purple-600/80 text-white">
                    {tech}
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Developer Info */}
        <Card className="bg-anime-dark/50 border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-2xl text-purple-400 flex items-center gap-2">
              <User className="w-6 h-6" />
              Developer Information
            </CardTitle>
            <CardDescription className="text-gray-300">
              Get in touch with the developer for support, premium features, or collaboration
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-purple-900/30 border border-purple-500/20 rounded-lg p-6">
              <h3 className="text-lg font-semibold text-white mb-2">Portfolio & Contact</h3>
              <p className="text-gray-300 mb-4">
                View the developer's complete portfolio, other projects, and get in touch for:
              </p>
              <ul className="list-disc list-inside text-gray-300 space-y-1 mb-4">
                <li>Premium unlock codes and features</li>
                <li>Custom development requests</li>
                <li>Bug reports and feature suggestions</li>
                <li>Collaboration opportunities</li>
                <li>Technical support and assistance</li>
              </ul>
              <Button 
                onClick={() => window.open('https://portfolio-neaterry6s-projects.vercel.app/', '_blank')}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                data-testid="button-portfolio"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Visit Developer Portfolio
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* FAQ Sections */}
        {faqs.map((section, sectionIndex) => (
          <Card key={sectionIndex} className="bg-anime-dark/50 border-purple-500/30">
            <CardHeader>
              <CardTitle className="text-xl text-purple-400">{section.category} Questions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {section.questions.map((faq, faqIndex) => (
                <div key={faqIndex} className="border-b border-purple-500/20 last:border-b-0 pb-4 last:pb-0">
                  <h4 className="font-semibold text-white mb-2">{faq.question}</h4>
                  <p className="text-gray-300 leading-relaxed">{faq.answer}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        ))}

        {/* Additional Support */}
        <Card className="bg-anime-dark/50 border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-xl text-purple-400">Need More Help?</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-purple-900/30 border border-purple-500/20 rounded-lg p-4">
                <Smartphone className="w-8 h-8 text-purple-400 mb-2" />
                <h3 className="font-semibold text-white mb-2">Mobile App</h3>
                <p className="text-gray-400 text-sm">
                  Stream Me ID is optimized for mobile browsers. Add it to your home screen for an app-like experience.
                </p>
              </div>
              <div className="bg-purple-900/30 border border-purple-500/20 rounded-lg p-4">
                <MessageSquare className="w-8 h-8 text-purple-400 mb-2" />
                <h3 className="font-semibold text-white mb-2">Community</h3>
                <p className="text-gray-400 text-sm">
                  Join our community chat for real-time discussions, recommendations, and support from other users.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}