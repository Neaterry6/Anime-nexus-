import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import NavigationHeader from "@/components/navigation-header";
import { Search, Download, Play, Music, FileText, Star, Clock, Eye, Heart, MessageCircle, TrendingUp, Calendar, Award, User, ThumbsUp, ThumbsDown } from "lucide-react";

interface MovieResult {
  title: string;
  url: string;
  thumbnail: string;
  duration: string;
  views: string;
  channel: string;
  uploadTime: string;
}

interface DownloadQuality {
  quality: string;
  url: string;
  fileSize?: string;
}

interface TrendingMovie {
  id: string;
  title: string;
  poster: string;
  year: string;
  genre: string[];
  rating: number;
  reviews: number;
  description: string;
  trailer?: string;
  director: string;
  cast: string[];
  trending: boolean;
}

interface MovieReview {
  id: string;
  movieId: string;
  user: string;
  avatar: string;
  rating: number;
  review: string;
  date: string;
  likes: number;
  dislikes: number;
}

const MOVIE_API_KEY = 'a0ebe80e-bf1a-4dbf-8d36-6935b1bfa5ea';
const SEARCH_API = 'https://kaiz-apis.gleeze.com/api/ytsearch';
const MP3_API = 'https://kaiz-apis.gleeze.com/api/ytdown-mp3';
const VIDEO_API = 'https://kaiz-apis.gleeze.com/api/ytmp4';
const LYRICS_API = 'https://kaiz-apis.gleeze.com/api/shazam-lyrics';
const MOVIE_DL_API = 'https://api-ix-ix.hf.space/api/moviedl';

const trendingMovies: TrendingMovie[] = [
  {
    id: "1",
    title: "Avatar: The Way of Water",
    poster: "https://images.unsplash.com/photo-1594736797933-d0400cbb1096?w=300&h=450&fit=crop",
    year: "2022",
    genre: ["Action", "Adventure", "Sci-Fi"],
    rating: 8.7,
    reviews: 1250,
    description: "Jake Sully lives with his newfound family formed on the extrasolar moon Pandora.",
    director: "James Cameron",
    cast: ["Sam Worthington", "Zoe Saldana", "Sigourney Weaver"],
    trending: true
  },
  {
    id: "2", 
    title: "Top Gun: Maverick",
    poster: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300&h=450&fit=crop",
    year: "2022",
    genre: ["Action", "Drama"],
    rating: 9.1,
    reviews: 2100,
    description: "After thirty years, Maverick is still pushing the envelope as a top naval aviator.",
    director: "Joseph Kosinski",
    cast: ["Tom Cruise", "Miles Teller", "Jennifer Connelly"],
    trending: true
  },
  {
    id: "3",
    title: "Black Panther: Wakanda Forever",
    poster: "https://images.unsplash.com/photo-1635805737707-575885ab0820?w=300&h=450&fit=crop",
    year: "2022", 
    genre: ["Action", "Adventure", "Drama"],
    rating: 8.2,
    reviews: 890,
    description: "The people of Wakanda fight to protect their home from intervening world powers.",
    director: "Ryan Coogler",
    cast: ["Letitia Wright", "Angela Bassett", "Tenoch Huerta"],
    trending: true
  },
  {
    id: "4",
    title: "Spider-Man: No Way Home",
    poster: "https://images.unsplash.com/photo-1626814026160-2237a95fc5a0?w=300&h=450&fit=crop",
    year: "2021",
    genre: ["Action", "Adventure", "Sci-Fi"],
    rating: 9.0,
    reviews: 3200,
    description: "Spider-Man's identity is revealed, bringing his superhero duties into conflict with his normal life.",
    director: "Jon Watts",
    cast: ["Tom Holland", "Zendaya", "Benedict Cumberbatch"],
    trending: true
  },
  {
    id: "5",
    title: "Dune",
    poster: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=300&h=450&fit=crop",
    year: "2021",
    genre: ["Action", "Adventure", "Drama"],
    rating: 8.8,
    reviews: 1560,
    description: "Paul Atreides leads nomadic tribes in a revolt against the galactic emperor.",
    director: "Denis Villeneuve", 
    cast: ["Timothée Chalamet", "Rebecca Ferguson", "Oscar Isaac"],
    trending: true
  },
  {
    id: "6",
    title: "The Batman",
    poster: "https://images.unsplash.com/photo-1608889175250-c3b0c1667d3a?w=300&h=450&fit=crop",
    year: "2022",
    genre: ["Action", "Crime", "Drama"],
    rating: 8.5,
    reviews: 1890,
    description: "Batman ventures into Gotham City's underworld when a sadistic killer leaves behind a trail of cryptic clues.",
    director: "Matt Reeves",
    cast: ["Robert Pattinson", "Zoë Kravitz", "Jeffrey Wright"],
    trending: true
  }
];

const movieReviews: MovieReview[] = [
  {
    id: "1",
    movieId: "1",
    user: "MovieFan2023",
    avatar: "https://api.dicebear.com/7.x/adventurer/svg?seed=MovieFan2023",
    rating: 9,
    review: "Absolutely stunning visuals and incredible world-building. Cameron has outdone himself!",
    date: "2023-01-15",
    likes: 234,
    dislikes: 12
  },
  {
    id: "2", 
    movieId: "2",
    user: "TopGunFan",
    avatar: "https://api.dicebear.com/7.x/adventurer/svg?seed=TopGunFan",
    rating: 10,
    review: "Tom Cruise delivers another masterpiece. The aerial scenes are breathtaking!",
    date: "2023-02-08",
    likes: 456,
    dislikes: 8
  },
  {
    id: "3",
    movieId: "4", 
    user: "SpideyLover",
    avatar: "https://api.dicebear.com/7.x/adventurer/svg?seed=SpideyLover",
    rating: 10,
    review: "The multiverse concept was executed perfectly. All three Spider-Men together was epic!",
    date: "2023-01-20",
    likes: 789,
    dislikes: 23
  }
];

const featuredMovies = [
  "Moana", "Spider-Man", "Avengers", "Harry Potter", "The Lion King",
  "Frozen", "Toy Story", "Finding Nemo", "Shrek", "Despicable Me",
  "Fast and Furious", "Marvel", "DC Comics", "Disney", "Pixar"
];

const featuredMusic = [
  "NF", "Drake", "Billie Eilish", "Taylor Swift", "Post Malone",
  "BTS", "Blackpink", "Anime songs", "Demon Slayer soundtrack",
  "Attack on Titan songs", "Naruto soundtrack", "Your Lie in April"
];

export default function MoviesPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchType, setSearchType] = useState<"movies" | "music">("movies");
  const [selectedItem, setSelectedItem] = useState<MovieResult | null>(null);
  const [selectedMovie, setSelectedMovie] = useState<TrendingMovie | null>(null);
  const [lyrics, setLyrics] = useState("");
  const [showLyrics, setShowLyrics] = useState(false);
  const [showMovieDetails, setShowMovieDetails] = useState(false);
  const [showReviewModal, setShowReviewModal] = useState(false);
  const [newReview, setNewReview] = useState("");
  const [newRating, setNewRating] = useState(5);
  const [downloadQuality, setDownloadQuality] = useState<DownloadQuality[]>([]);
  const { toast } = useToast();

  const searchMovies = async (query: string): Promise<MovieResult[]> => {
    if (!query.trim()) return [];
    
    const response = await fetch(`${SEARCH_API}?q=${encodeURIComponent(query)}&key=${MOVIE_API_KEY}`);
    if (!response.ok) throw new Error('Search failed');
    
    const data = await response.json();
    return data.results || [];
  };

  const downloadMovie = async (movieName: string, episode = "") => {
    const response = await fetch(`${MOVIE_DL_API}?moviename=${encodeURIComponent(movieName)}&episode=${episode}`);
    if (!response.ok) throw new Error('Download failed');
    const data = await response.json();
    return data;
  };

  const getLyrics = async (songTitle: string) => {
    const response = await fetch(`${LYRICS_API}?q=${encodeURIComponent(songTitle)}&key=${MOVIE_API_KEY}`);
    if (!response.ok) throw new Error('Lyrics not found');
    return response.json();
  };

  const getDownloadLinks = async (videoUrl: string, type: 'mp3' | 'mp4') => {
    const api = type === 'mp3' ? MP3_API : VIDEO_API;
    const response = await fetch(`${api}?url=${encodeURIComponent(videoUrl)}&key=${MOVIE_API_KEY}`);
    if (!response.ok) throw new Error('Download links failed');
    return response.json();
  };

  const { data: searchResults, isLoading: searchLoading, refetch } = useQuery({
    queryKey: ['search', searchQuery, searchType],
    queryFn: () => searchMovies(searchQuery),
    enabled: false
  });

  const downloadMutation = useMutation({
    mutationFn: ({ name, episode }: { name: string; episode?: string }) => 
      downloadMovie(name, episode || ""),
    onSuccess: (data) => {
      if (data.downloadUrl || data.download_url) {
        const downloadUrl = data.downloadUrl || data.download_url;
        window.open(downloadUrl, '_blank');
        toast({ title: "Download started!", description: "Your movie download has begun." });
      } else if (data.message) {
        toast({ title: "Movie found", description: data.message });
      } else {
        toast({ title: "Download ready", description: "Movie processing complete." });
      }
    },
    onError: (error) => {
      toast({ 
        title: "Download failed", 
        description: error instanceof Error ? error.message : "Could not process movie download.", 
        variant: "destructive" 
      });
    }
  });

  const lyricsMutation = useMutation({
    mutationFn: (songTitle: string) => getLyrics(songTitle),
    onSuccess: (data) => {
      setLyrics(data.lyrics || "Lyrics not found");
      setShowLyrics(true);
    },
    onError: () => {
      toast({ title: "Lyrics not found", description: "Could not find lyrics for this song.", variant: "destructive" });
    }
  });

  const downloadLinksMutation = useMutation({
    mutationFn: ({ url, type }: { url: string; type: 'mp3' | 'mp4' }) => 
      getDownloadLinks(url, type),
    onSuccess: (data) => {
      if (data.downloadUrl) {
        window.open(data.downloadUrl, '_blank');
        toast({ title: "Download started!", description: "Your file download has begun." });
      }
    },
    onError: () => {
      toast({ title: "Download failed", description: "Could not generate download link.", variant: "destructive" });
    }
  });

  const handleSearch = () => {
    if (searchQuery.trim()) {
      refetch();
    }
  };

  const handleFeaturedClick = (item: string) => {
    setSearchQuery(item);
    setSearchType("movies");
    setTimeout(() => refetch(), 100);
  };

  const handleMusicClick = (item: string) => {
    setSearchQuery(item);
    setSearchType("music");
    setTimeout(() => refetch(), 100);
  };

  const handleDownload = (item: MovieResult, type: 'movie' | 'mp3' | 'mp4') => {
    if (type === 'movie') {
      downloadMutation.mutate({ name: item.title });
    } else {
      downloadLinksMutation.mutate({ url: item.url, type: type as 'mp3' | 'mp4' });
    }
  };

  const handleLyrics = (item: MovieResult) => {
    lyricsMutation.mutate(item.title);
  };

  const handleMovieClick = (movie: TrendingMovie) => {
    setSelectedMovie(movie);
    setShowMovieDetails(true);
  };

  const handleReviewSubmit = () => {
    if (newReview.trim() && selectedMovie) {
      toast({ 
        title: "Review submitted!", 
        description: "Thank you for your feedback." 
      });
      setShowReviewModal(false);
      setNewReview("");
      setNewRating(5);
    }
  };

  const renderStars = (rating: number, interactive = false, onRatingChange?: (rating: number) => void) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <Star
            key={star}
            className={`h-4 w-4 ${
              star <= rating ? "fill-yellow-400 text-yellow-400" : "text-gray-400"
            } ${interactive ? "cursor-pointer hover:fill-yellow-300" : ""}`}
            onClick={interactive && onRatingChange ? () => onRatingChange(star) : undefined}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white">
      <NavigationHeader title="Movies & Music Hub" />
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
            🎬 Movies & Music Hub
          </h1>
          <p className="text-gray-300 text-lg">
            Search, stream, and download your favorite movies and music
          </p>
        </div>

        {/* Search Section */}
        <div className="bg-black/30 rounded-xl p-6 mb-8 border border-purple-500/20">
          <Tabs value={searchType} onValueChange={(value) => setSearchType(value as "movies" | "music")} className="mb-4">
            <TabsList className="grid w-full grid-cols-2 bg-purple-900/50">
              <TabsTrigger value="movies" className="data-[state=active]:bg-purple-600">Movies</TabsTrigger>
              <TabsTrigger value="music" className="data-[state=active]:bg-purple-600">Music</TabsTrigger>
            </TabsList>
          </Tabs>

          <div className="flex gap-2">
            <Input
              placeholder={searchType === "movies" ? "Search for movies..." : "Search for music..."}
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              className="flex-1 bg-black/50 border-purple-500/30 text-white placeholder-gray-400"
            />
            <Button 
              onClick={handleSearch} 
              className="bg-purple-600 hover:bg-purple-700"
              disabled={searchLoading}
            >
              <Search className="h-4 w-4" />
            </Button>
          </div>
        </div>

        {/* Featured Content */}
        <div className="mb-8">
          <Tabs defaultValue="trending" className="w-full">
            <TabsList className="grid w-full grid-cols-3 bg-purple-900/50 mb-6">
              <TabsTrigger value="trending" className="data-[state=active]:bg-purple-600">Trending Movies</TabsTrigger>
              <TabsTrigger value="movies" className="data-[state=active]:bg-purple-600">Featured Movies</TabsTrigger>
              <TabsTrigger value="music" className="data-[state=active]:bg-purple-600">Popular Music</TabsTrigger>
            </TabsList>

            <TabsContent value="trending" className="space-y-4">
              <div className="flex items-center gap-2 mb-4">
                <TrendingUp className="h-6 w-6 text-yellow-500" />
                <h2 className="text-2xl font-bold">Trending Movies</h2>
                <Badge className="bg-red-600">Hot</Badge>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {trendingMovies.map((movie) => (
                  <Card key={movie.id} className="bg-black/40 border-purple-500/20 hover:border-purple-500/40 transition-all cursor-pointer group">
                    <div className="relative">
                      <img 
                        src={movie.poster} 
                        alt={movie.title}
                        className="w-full h-64 object-cover rounded-t-lg"
                      />
                      <div className="absolute top-3 right-3">
                        <Badge className="bg-yellow-600">
                          <Star className="h-3 w-3 mr-1" />
                          {movie.rating}
                        </Badge>
                      </div>
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                        <Play className="h-12 w-12 text-white" />
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-bold text-white mb-2 line-clamp-1">{movie.title}</h3>
                      <div className="flex items-center gap-2 text-sm text-gray-400 mb-2">
                        <Calendar className="h-4 w-4" />
                        <span>{movie.year}</span>
                        <Award className="h-4 w-4 ml-2" />
                        <span>{movie.reviews} reviews</span>
                      </div>
                      <div className="flex flex-wrap gap-1 mb-3">
                        {movie.genre.slice(0, 2).map((g) => (
                          <Badge key={g} variant="outline" className="text-xs border-purple-500/30 text-purple-300">
                            {g}
                          </Badge>
                        ))}
                      </div>
                      <p className="text-gray-300 text-sm mb-3 line-clamp-2">{movie.description}</p>
                      
                      <div className="space-y-2">
                        <Button 
                          className="w-full bg-purple-600 hover:bg-purple-700" 
                          onClick={() => handleMovieClick(movie)}
                        >
                          View Details
                        </Button>
                        <div className="grid grid-cols-2 gap-2">
                          <Button 
                            size="sm"
                            variant="outline"
                            className="border-purple-500/30 text-purple-400 hover:bg-purple-600 hover:text-white"
                            onClick={() => downloadMutation.mutate({ name: movie.title })}
                          >
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                          <Button 
                            size="sm"
                            variant="outline"
                            className="border-pink-500/30 text-pink-400 hover:bg-pink-600 hover:text-white"
                            onClick={() => {
                              setSelectedMovie(movie);
                              setShowReviewModal(true);
                            }}
                          >
                            <MessageCircle className="h-4 w-4 mr-1" />
                            Review
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="movies" className="space-y-4">
              <h2 className="text-2xl font-bold mb-4">Featured Movies</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                {featuredMovies.map((movie, index) => (
                  <Card key={index} className="bg-black/40 border-purple-500/20 hover:border-purple-500/40 transition-all cursor-pointer group">
                    <CardContent className="p-4 text-center">
                      <div className="bg-gradient-to-br from-purple-600 to-pink-600 h-24 rounded-lg mb-3 flex items-center justify-center group-hover:scale-105 transition-transform">
                        <Play className="h-8 w-8 text-white" />
                      </div>
                      <h3 className="font-semibold text-sm text-white mb-2">{movie}</h3>
                      <Button 
                        size="sm" 
                        className="w-full bg-purple-600 hover:bg-purple-700"
                        onClick={() => handleFeaturedClick(movie)}
                      >
                        Search
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="music" className="space-y-4">
              <h2 className="text-2xl font-bold mb-4">Popular Music</h2>
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {featuredMusic.map((artist, index) => (
                  <Card key={index} className="bg-black/40 border-purple-500/20 hover:border-purple-500/40 transition-all cursor-pointer group">
                    <CardContent className="p-4 text-center">
                      <div className="bg-gradient-to-br from-pink-600 to-purple-600 h-24 rounded-lg mb-3 flex items-center justify-center group-hover:scale-105 transition-transform">
                        <Music className="h-8 w-8 text-white" />
                      </div>
                      <h3 className="font-semibold text-sm text-white mb-2">{artist}</h3>
                      <Button 
                        size="sm" 
                        className="w-full bg-pink-600 hover:bg-pink-700"
                        onClick={() => handleMusicClick(artist)}
                      >
                        Search
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Search Results */}
        {searchLoading && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="bg-black/40 border-purple-500/20">
                <CardContent className="p-4">
                  <Skeleton className="h-48 w-full mb-4 bg-gray-700" />
                  <Skeleton className="h-4 w-3/4 mb-2 bg-gray-700" />
                  <Skeleton className="h-4 w-1/2 bg-gray-700" />
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {searchResults && searchResults.length > 0 && (
          <div className="space-y-6">
            <h2 className="text-2xl font-bold">Search Results for "{searchQuery}"</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {searchResults.map((item, index) => (
                <Card key={index} className="bg-black/40 border-purple-500/20 hover:border-purple-500/40 transition-all group">
                  <div className="relative">
                    <img 
                      src={item.thumbnail} 
                      alt={item.title}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Play className="h-12 w-12 text-white" />
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <h3 className="font-bold text-white mb-2 line-clamp-2">{item.title}</h3>
                    <div className="flex items-center gap-2 text-sm text-gray-400 mb-3">
                      <Clock className="h-4 w-4" />
                      <span>{item.duration}</span>
                      <Eye className="h-4 w-4 ml-2" />
                      <span>{item.views}</span>
                    </div>
                    <p className="text-gray-300 text-sm mb-3">{item.channel}</p>
                    
                    <div className="space-y-2">
                      {searchType === "movies" ? (
                        <Button 
                          className="w-full bg-purple-600 hover:bg-purple-700" 
                          onClick={() => handleDownload(item, 'movie')}
                          disabled={downloadMutation.isPending}
                        >
                          <Download className="h-4 w-4 mr-2" />
                          Download Movie
                        </Button>
                      ) : (
                        <div className="grid grid-cols-2 gap-2">
                          <Button 
                            size="sm"
                            className="bg-pink-600 hover:bg-pink-700" 
                            onClick={() => handleDownload(item, 'mp3')}
                            disabled={downloadLinksMutation.isPending}
                          >
                            <Music className="h-4 w-4 mr-1" />
                            MP3
                          </Button>
                          <Button 
                            size="sm"
                            className="bg-blue-600 hover:bg-blue-700" 
                            onClick={() => handleDownload(item, 'mp4')}
                            disabled={downloadLinksMutation.isPending}
                          >
                            <Download className="h-4 w-4 mr-1" />
                            MP4
                          </Button>
                        </div>
                      )}
                      
                      {searchType === "music" && (
                        <Button 
                          variant="outline" 
                          className="w-full border-purple-500/30 text-purple-400 hover:bg-purple-600 hover:text-white"
                          onClick={() => handleLyrics(item)}
                          disabled={lyricsMutation.isPending}
                        >
                          <FileText className="h-4 w-4 mr-2" />
                          View Lyrics
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Lyrics Modal */}
        <Dialog open={showLyrics} onOpenChange={setShowLyrics}>
          <DialogContent className="bg-black/90 border-purple-500/30 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-purple-400">Lyrics</DialogTitle>
            </DialogHeader>
            <div className="whitespace-pre-line text-gray-300 leading-relaxed">
              {lyrics}
            </div>
          </DialogContent>
        </Dialog>

        {/* Movie Details Modal */}
        <Dialog open={showMovieDetails} onOpenChange={setShowMovieDetails}>
          <DialogContent className="bg-black/90 border-purple-500/30 text-white max-w-4xl max-h-[90vh] overflow-y-auto">
            {selectedMovie && (
              <>
                <DialogHeader>
                  <DialogTitle className="text-2xl text-purple-400">{selectedMovie.title}</DialogTitle>
                </DialogHeader>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="md:col-span-1">
                    <img 
                      src={selectedMovie.poster} 
                      alt={selectedMovie.title}
                      className="w-full rounded-lg"
                    />
                    <div className="mt-4 space-y-2">
                      <Button className="w-full bg-purple-600 hover:bg-purple-700">
                        <Play className="h-4 w-4 mr-2" />
                        Watch Trailer
                      </Button>
                      <Button 
                        variant="outline" 
                        className="w-full border-purple-500/30"
                        onClick={() => downloadMutation.mutate({ name: selectedMovie.title })}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download Movie
                      </Button>
                    </div>
                  </div>
                  <div className="md:col-span-2 space-y-4">
                    <div className="flex items-center gap-4">
                      {renderStars(Math.floor(selectedMovie.rating))}
                      <span className="text-yellow-400 font-bold">{selectedMovie.rating}/10</span>
                      <Badge className="bg-green-600">{selectedMovie.year}</Badge>
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                      {selectedMovie.genre.map((g) => (
                        <Badge key={g} className="bg-purple-600">{g}</Badge>
                      ))}
                    </div>

                    <p className="text-gray-300 leading-relaxed">{selectedMovie.description}</p>

                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <User className="h-4 w-4 text-purple-400" />
                        <span className="text-gray-400">Director:</span>
                        <span className="text-white">{selectedMovie.director}</span>
                      </div>
                      <div className="flex items-start gap-2">
                        <Award className="h-4 w-4 text-purple-400 mt-1" />
                        <span className="text-gray-400">Cast:</span>
                        <span className="text-white">{selectedMovie.cast.join(", ")}</span>
                      </div>
                    </div>

                    <div className="border-t border-purple-500/20 pt-4">
                      <h3 className="text-lg font-bold mb-3">Recent Reviews</h3>
                      <div className="space-y-3 max-h-64 overflow-y-auto">
                        {movieReviews
                          .filter(review => review.movieId === selectedMovie.id)
                          .map((review) => (
                          <div key={review.id} className="bg-purple-900/20 rounded-lg p-3">
                            <div className="flex items-center gap-3 mb-2">
                              <img 
                                src={review.avatar} 
                                alt={review.user}
                                className="w-8 h-8 rounded-full"
                              />
                              <div className="flex-1">
                                <div className="flex items-center gap-2">
                                  <span className="font-semibold text-white">{review.user}</span>
                                  {renderStars(review.rating)}
                                </div>
                                <span className="text-xs text-gray-400">{review.date}</span>
                              </div>
                            </div>
                            <p className="text-gray-300 text-sm mb-2">{review.review}</p>
                            <div className="flex items-center gap-4 text-xs text-gray-400">
                              <button className="flex items-center gap-1 hover:text-green-400">
                                <ThumbsUp className="h-3 w-3" />
                                {review.likes}
                              </button>
                              <button className="flex items-center gap-1 hover:text-red-400">
                                <ThumbsDown className="h-3 w-3" />
                                {review.dislikes}
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              </>
            )}
          </DialogContent>
        </Dialog>

        {/* Review Modal */}
        <Dialog open={showReviewModal} onOpenChange={setShowReviewModal}>
          <DialogContent className="bg-black/90 border-purple-500/30 text-white max-w-md">
            <DialogHeader>
              <DialogTitle className="text-purple-400">Write a Review</DialogTitle>
            </DialogHeader>
            {selectedMovie && (
              <div className="space-y-4">
                <div className="text-center">
                  <h3 className="font-bold text-white mb-2">{selectedMovie.title}</h3>
                  <div className="flex items-center justify-center gap-2">
                    <span className="text-gray-400">Your Rating:</span>
                    {renderStars(newRating, true, setNewRating)}
                  </div>
                </div>
                
                <Textarea
                  placeholder="Share your thoughts about this movie..."
                  value={newReview}
                  onChange={(e) => setNewReview(e.target.value)}
                  className="bg-black/50 border-purple-500/30 text-white placeholder-gray-400 min-h-[120px]"
                />
                
                <div className="flex gap-2">
                  <Button 
                    className="flex-1 bg-purple-600 hover:bg-purple-700"
                    onClick={handleReviewSubmit}
                  >
                    Submit Review
                  </Button>
                  <Button 
                    variant="outline" 
                    className="border-purple-500/30"
                    onClick={() => setShowReviewModal(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}