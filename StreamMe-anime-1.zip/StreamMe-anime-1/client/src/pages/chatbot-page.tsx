import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import NavigationHeader from "@/components/navigation-header";
import { 
  Bot, 
  Send, 
  Sparkles, 
  Image as ImageIcon, 
  Copy, 
  Download, 
  Star, 
  Trash2, 
  RefreshCw,
  MessageSquare,
  Zap,
  Brain,
  Palette,
  Clock,
  ChevronDown,
  Settings
} from "lucide-react";

interface ChatMessage {
  id: string;
  type: 'user' | 'bot';
  content: string;
  model?: string;
  timestamp: Date;
  tokens?: number;
  responseTime?: number;
}

interface AIModel {
  id: string;
  name: string;
  description: string;
  free: boolean;
  icon: React.ReactNode;
  color: string;
}

const AI_MODELS: AIModel[] = [
  {
    id: "gpt4",
    name: "GPT-4",
    description: "Advanced AI for conversations and image recognition",
    free: false,
    icon: <Brain className="h-4 w-4" />,
    color: "text-blue-400"
  },
  {
    id: "waifu",
    name: "Waifu Generator",
    description: "Generate anime waifu characters",
    free: false,
    icon: <Sparkles className="h-4 w-4" />,
    color: "text-pink-400"
  },
  {
    id: "pinterest",
    name: "Pinterest Search",
    description: "Search Pinterest for images",
    free: false,
    icon: <ImageIcon className="h-4 w-4" />,
    color: "text-red-400"
  },
  {
    id: "unsplash",
    name: "Unsplash Search",
    description: "Search high-quality photos from Unsplash",
    free: false,
    icon: <ImageIcon className="h-4 w-4" />,
    color: "text-green-400"
  },
  {
    id: "createai",
    name: "AI Art Generator",
    description: "Generate custom AI artwork from text",
    free: false,
    icon: <Palette className="h-4 w-4" />,
    color: "text-purple-400"
  },
  {
    id: "ghibli",
    name: "Ghibli Style Converter",
    description: "Convert images to Studio Ghibli anime style",
    free: false,
    icon: <Sparkles className="h-4 w-4" />,
    color: "text-yellow-400"
  }
];

const SUGGESTED_PROMPTS = [
  "Explain quantum computing in simple terms",
  "Write a short story about space exploration", 
  "Create a workout plan for beginners",
  "Help me debug this JavaScript code",
  "Generate a recipe for chocolate cake",
  "Explain the latest developments in AI",
  "Write a professional email template",
  "Create a study schedule for exams"
];

export default function ChatbotPage() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentMessage, setCurrentMessage] = useState("");
  const [selectedModel, setSelectedModel] = useState("gpt4");
  const [isLoading, setIsLoading] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [conversationMode, setConversationMode] = useState(true);
  const [maxTokens, setMaxTokens] = useState(1000);
  const [showUnlockDialog, setShowUnlockDialog] = useState(false);
  const [unlockCode, setUnlockCode] = useState("");
  const [isSubmittingCode, setIsSubmittingCode] = useState(false);
  
  const { user, token } = useAuth();
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    // Load conversation from localStorage
    const savedMessages = localStorage.getItem('chatbot-messages');
    if (savedMessages) {
      try {
        const parsed = JSON.parse(savedMessages);
        setMessages(parsed.map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp)
        })));
      } catch (error) {
        console.error('Error loading saved messages:', error);
      }
    }
  }, []);

  useEffect(() => {
    // Save conversation to localStorage
    if (messages.length > 0) {
      localStorage.setItem('chatbot-messages', JSON.stringify(messages));
    }
  }, [messages]);

  const handleUnlockCode = async () => {
    if (!unlockCode.trim()) return;
    
    setIsSubmittingCode(true);
    try {
      const response = await fetch('/api/unlock-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ code: unlockCode }),
      });

      const data = await response.json();
      
      if (response.ok) {
        toast({
          title: "Success!",
          description: "Chat access granted! You can now use the AI chatbot.",
        });
        setShowUnlockDialog(false);
        setUnlockCode("");
        // Refresh user data
        window.location.reload();
      } else {
        toast({
          title: "Invalid Code",
          description: data.error || "Please check your unlock code and try again.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to verify unlock code. Please try again.",
        variant: "destructive",
      });
    }
    setIsSubmittingCode(false);
  };

  const sendMessage = async () => {
    if (!currentMessage.trim()) return;
    
    if (!user?.chatAccess) {
      setShowUnlockDialog(true);
      return;
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: currentMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setCurrentMessage("");
    setIsLoading(true);

    const startTime = Date.now();

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          model: selectedModel,
          prompt: currentMessage,
        }),
      });

      const data = await response.json();
      const responseTime = Date.now() - startTime;

      if (response.ok) {
        const botMessage: ChatMessage = {
          id: Date.now().toString(),
          type: 'bot',
          content: data.response,
          model: selectedModel,
          timestamp: new Date(),
          responseTime,
          tokens: data.tokens || 0
        };

        setMessages(prev => [...prev, botMessage]);
        
        toast({
          title: "Response received",
          description: `${AI_MODELS.find(m => m.id === selectedModel)?.name} responded in ${responseTime}ms`
        });
      } else {
        throw new Error(data.error || 'Failed to get AI response');
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send message",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const clearConversation = () => {
    setMessages([]);
    localStorage.removeItem('chatbot-messages');
    toast({ title: "Conversation cleared", description: "All messages have been removed" });
  };

  const copyMessage = async (content: string) => {
    await navigator.clipboard.writeText(content);
    toast({ title: "Copied!", description: "Message copied to clipboard" });
  };

  const exportConversation = () => {
    const conversation = messages.map(msg => 
      `[${msg.timestamp.toLocaleString()}] ${msg.type === 'user' ? 'You' : `AI (${msg.model})`}: ${msg.content}`
    ).join('\n\n');
    
    const blob = new Blob([conversation], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chatbot-conversation-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const useSuggestedPrompt = (prompt: string) => {
    setCurrentMessage(prompt);
    inputRef.current?.focus();
  };

  if (!user?.chatAccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
        <NavigationHeader title="AI Chatbot" />
        <div className="flex items-center justify-center p-4 min-h-[calc(100vh-80px)]">
          <Card className="bg-black/40 border-red-500/50 max-w-md w-full">
            <CardHeader className="text-center">
              <Bot className="h-16 w-16 mx-auto mb-4 text-red-400" />
              <CardTitle className="text-white">AI Chat Access Required</CardTitle>
            </CardHeader>
            <CardContent className="text-center">
              <p className="text-gray-300 mb-4">
                You need chat access to use the AI chatbot. Please contact support for an unlock code.
              </p>
              <Badge variant="outline" className="border-red-500 text-red-400">
                Premium Feature
              </Badge>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const selectedModelData = AI_MODELS.find(m => m.id === selectedModel);

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 text-white">
      <NavigationHeader title="AI Chatbot Hub" />
      <div className="container mx-auto px-4 py-6 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Bot className="h-10 w-10 text-purple-400" />
            <h1 className="text-4xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
              AI Chatbot Hub
            </h1>
          </div>
          <p className="text-gray-300 text-lg">
            Chat with advanced AI models for assistance, creativity, and problem-solving
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-4">
            {/* Model Selection */}
            <Card className="bg-black/40 border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white text-sm flex items-center gap-2">
                  <Zap className="h-4 w-4" />
                  AI Model
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {AI_MODELS.map((model) => (
                  <button
                    key={model.id}
                    onClick={() => setSelectedModel(model.id)}
                    className={`w-full p-3 rounded-lg border transition-all text-left ${
                      selectedModel === model.id
                        ? 'border-purple-500 bg-purple-500/20'
                        : 'border-gray-600 bg-black/30 hover:border-purple-400'
                    }`}
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className={model.color}>{model.icon}</span>
                      <span className="font-semibold text-white">{model.name}</span>
                    </div>
                    <p className="text-xs text-gray-400">{model.description}</p>
                  </button>
                ))}
              </CardContent>
            </Card>

            {/* Stats */}
            <Card className="bg-black/40 border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white text-sm">Session Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Messages:</span>
                  <span className="text-white">{messages.length}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Model:</span>
                  <span className={selectedModelData?.color}>{selectedModelData?.name}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">Trials Left:</span>
                  <span className="text-green-400">{user?.aiTrialsLeft || 0}</span>
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <Card className="bg-black/40 border-purple-500/20">
              <CardHeader>
                <CardTitle className="text-white text-sm">Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={exportConversation}
                  disabled={messages.length === 0}
                  className="w-full text-xs"
                >
                  <Download className="h-3 w-3 mr-2" />
                  Export Chat
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={clearConversation}
                  disabled={messages.length === 0}
                  className="w-full text-xs text-red-400 border-red-400/50 hover:bg-red-400/10"
                >
                  <Trash2 className="h-3 w-3 mr-2" />
                  Clear All
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Main Chat Area */}
          <div className="lg:col-span-3">
            <Card className="bg-black/40 border-purple-500/20 h-[calc(100vh-200px)]">
              <CardHeader className="flex flex-row items-center justify-between pb-4">
                <div className="flex items-center gap-3">
                  <span className={selectedModelData?.color}>{selectedModelData?.icon}</span>
                  <CardTitle className="text-white">{selectedModelData?.name}</CardTitle>
                  <Badge className="bg-green-600/20 text-green-400 border-green-400/30">
                    Online
                  </Badge>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setShowSettings(!showSettings)}>
                  <Settings className="h-4 w-4" />
                </Button>
              </CardHeader>

              <CardContent className="flex flex-col h-full p-0">
                {/* Messages Area */}
                <ScrollArea className="flex-1 px-6">
                  {messages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full text-center py-12">
                      <Bot className="h-16 w-16 text-purple-400 mb-4" />
                      <h3 className="text-xl font-semibold text-white mb-2">Ready to Chat!</h3>
                      <p className="text-gray-400 mb-6">Start a conversation with AI or try a suggested prompt below.</p>
                      
                      {/* Suggested Prompts */}
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-2 max-w-2xl">
                        {SUGGESTED_PROMPTS.slice(0, 6).map((prompt, index) => (
                          <button
                            key={index}
                            onClick={() => useSuggestedPrompt(prompt)}
                            className="p-3 text-sm text-left bg-purple-900/30 hover:bg-purple-900/50 border border-purple-500/20 rounded-lg transition-colors"
                          >
                            {prompt}
                          </button>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="space-y-4 py-4">
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex gap-3 ${
                            message.type === 'user' ? 'justify-end' : 'justify-start'
                          }`}
                        >
                          {message.type === 'bot' && (
                            <Avatar className="h-8 w-8">
                              <AvatarFallback className="bg-purple-600">
                                {selectedModelData?.icon}
                              </AvatarFallback>
                            </Avatar>
                          )}
                          
                          <div className={`max-w-[70%] ${
                            message.type === 'user' ? 'order-last' : ''
                          }`}>
                            <div className={`p-3 rounded-lg ${
                              message.type === 'user' 
                                ? 'bg-purple-600 text-white' 
                                : 'bg-gray-800 text-gray-100'
                            }`}>
                              <p className="whitespace-pre-wrap">{message.content}</p>
                            </div>
                            
                            <div className="flex items-center gap-2 mt-1">
                              <span className="text-xs text-gray-500">
                                {message.timestamp.toLocaleTimeString()}
                              </span>
                              {message.responseTime && (
                                <span className="text-xs text-gray-500">
                                  • {message.responseTime}ms
                                </span>
                              )}
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => copyMessage(message.content)}
                                className="h-6 w-6 p-0 text-gray-500 hover:text-white"
                              >
                                <Copy className="h-3 w-3" />
                              </Button>
                            </div>
                          </div>

                          {message.type === 'user' && (
                            <Avatar className="h-8 w-8">
                              <AvatarFallback className="bg-blue-600">
                                {user?.username?.[0]?.toUpperCase() || 'U'}
                              </AvatarFallback>
                            </Avatar>
                          )}
                        </div>
                      ))}
                      
                      {isLoading && (
                        <div className="flex gap-3 justify-start">
                          <Avatar className="h-8 w-8">
                            <AvatarFallback className="bg-purple-600">
                              {selectedModelData?.icon}
                            </AvatarFallback>
                          </Avatar>
                          <div className="bg-gray-800 p-3 rounded-lg">
                            <div className="flex items-center gap-2">
                              <RefreshCw className="h-4 w-4 animate-spin" />
                              <span className="text-gray-400">Thinking...</span>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      <div ref={messagesEndRef} />
                    </div>
                  )}
                </ScrollArea>

                {/* Input Area */}
                <div className="p-6 border-t border-purple-500/20">
                  <div className="flex gap-2">
                    <Input
                      ref={inputRef}
                      placeholder={`Message ${selectedModelData?.name}...`}
                      value={currentMessage}
                      onChange={(e) => setCurrentMessage(e.target.value)}
                      onKeyPress={handleKeyPress}
                      className="flex-1 bg-black/50 border-purple-500/30 text-white placeholder-gray-400"
                      disabled={isLoading}
                    />
                    <Button
                      onClick={sendMessage}
                      disabled={isLoading || !currentMessage.trim()}
                      className="bg-purple-600 hover:bg-purple-700"
                    >
                      {isLoading ? (
                        <RefreshCw className="h-4 w-4 animate-spin" />
                      ) : (
                        <Send className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  
                  <div className="flex items-center justify-between mt-2 text-xs text-gray-500">
                    <span>Press Enter to send, Shift+Enter for new line</span>
                    <span>{user?.aiTrialsLeft || 0} trials remaining</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Unlock Code Dialog */}
      <Dialog open={showUnlockDialog} onOpenChange={setShowUnlockDialog}>
        <DialogContent className="bg-black border border-purple-500/30 text-white">
          <DialogHeader>
            <DialogTitle className="text-purple-400">Enter Unlock Code</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <p className="text-gray-300 text-sm">
              You need an unlock code to access the AI chatbot. Contact WhatsApp +2348039896597 to purchase unlock codes.
            </p>
            <Input
              placeholder="Enter your unlock code"
              value={unlockCode}
              onChange={(e) => setUnlockCode(e.target.value)}
              className="bg-black/50 border-purple-500/30 text-white placeholder-gray-400"
              onKeyPress={(e) => e.key === 'Enter' && handleUnlockCode()}
            />
            <div className="flex gap-2 justify-end">
              <Button
                variant="outline"
                onClick={() => setShowUnlockDialog(false)}
                className="border-purple-500/30 text-gray-300 hover:text-white"
              >
                Cancel
              </Button>
              <Button
                onClick={handleUnlockCode}
                disabled={isSubmittingCode || !unlockCode.trim()}
                className="bg-purple-600 hover:bg-purple-700"
              >
                {isSubmittingCode ? (
                  <RefreshCw className="h-4 w-4 animate-spin" />
                ) : (
                  "Verify Code"
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}