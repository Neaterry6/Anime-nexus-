import { useState } from "react";
import NavigationHeader from "../components/navigation-header";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useAuth } from "@/hooks/use-auth";
import {
  ChevronDown,
  ChevronUp,
  User,
  Mail,
  Calendar,
  Star,
  Download,
  BookOpen,
  MessageCircle,
  ExternalLink,
  Phone,
  MapPin,
  Github,
  Linkedin,
  Globe,
  Music,
  Send
} from "lucide-react";

interface FAQItem {
  question: string;
  answer: string;
  category: 'app' | 'account' | 'manga' | 'anime' | 'support';
}

const faqData: FAQItem[] = [
  {
    question: "What is StreamMe Anime?",
    answer: "StreamMe Anime is a comprehensive anime and manga streaming platform that offers anime browsing, manga reading, real-time chat, AI chatbots, and download capabilities. It features a modern interface with dark mode support and responsive design.",
    category: 'app'
  },
  {
    question: "How do I download anime episodes?",
    answer: "Browse to the anime section, search for your desired anime, click on the anime card to view details, select the episode you want, and choose your preferred download quality (360p, 720p, or 1080p).",
    category: 'anime'
  },
  {
    question: "How do I read manga on the platform?",
    answer: "Go to the manga section, search for your favorite manga, click on the manga card, select a chapter, and click 'Read Manga'. You can use fullscreen mode, bookmark chapters, and track your reading progress.",
    category: 'manga'
  },
  {
    question: "What AI chatbots are available?",
    answer: "We offer multiple AI models including Gemini for general conversations, Grok for creative discussions, and specialized image generation capabilities. Access them through the AI Chat section.",
    category: 'app'
  },
  {
    question: "How do unlock codes work?",
    answer: "Unlock codes provide access to premium features like advanced chat functionality. Contact our WhatsApp support at +2348039896597 to purchase unlock codes.",
    category: 'account'
  },
  {
    question: "Can I track my reading progress?",
    answer: "Yes! The platform automatically tracks your manga reading history, bookmarks, completion rates, and provides personalized recommendations based on your preferences.",
    category: 'manga'
  },
  {
    question: "Is the platform mobile-friendly?",
    answer: "Absolutely! StreamMe Anime is fully responsive and works seamlessly on desktop, tablet, and mobile devices with an optimized touch-friendly interface.",
    category: 'app'
  },
  {
    question: "How do I get support?",
    answer: "For technical issues, use the contact form below. For unlock codes and billing questions, contact us on WhatsApp at +2348039896597. You can also check our GitHub repository for updates.",
    category: 'support'
  }
];

const developerInfo = {
  name: "Akewushola Abdulbakri",
  role: "Full-Stack Developer & Creative Writer",
  email: "support@streamme.anime",
  phone: "+2348039896597",
  location: "Nigeria",
  bio: "I'm a passionate developer with expertise in modern web technologies. I also write captivating stories and poetry, blending creativity with logic. My work bridges the gap between code and art, crafting experiences that inspire.",
  skills: ["React.js", "Node.js", "TypeScript", "Next.js", "Express.js", "Tailwind CSS", "Creative Writing", "Poetry"],
  portfolio: "https://portfolio-neaterry6s-projects.vercel.app/",
  social: {
    github: "https://github.com/Neaterry6",
    linkedin: "https://www.linkedin.com/in/akewushola-abdulbakri-659458365",
    telegram: "https://t.me/Heartbreak798453",
    facebook: "https://www.facebook.com/profile.php?id=61575627958849",
    website: "https://portfolio-neaterry6s-projects.vercel.app/",
    whatsapp: "https://wa.me/2348039896597",
    channel: "https://whatsapp.com/channel/0029Vb63QCJ9Gv7Q5ec5rt3e",
    music_platform: "https://streame-id.vercel.app/"
  }
};

export default function FAQPage() {
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);
  const { user } = useAuth();

  const categories = [
    { id: 'all', name: 'All Questions', icon: null },
    { id: 'app', name: 'App Features', icon: Star },
    { id: 'anime', name: 'Anime Downloads', icon: Download },
    { id: 'manga', name: 'Manga Reading', icon: BookOpen },
    { id: 'account', name: 'Account & Premium', icon: User },
    { id: 'support', name: 'Support', icon: MessageCircle }
  ];

  const filteredFAQs = activeCategory === 'all' 
    ? faqData 
    : faqData.filter(faq => faq.category === activeCategory);

  const toggleFAQ = (index: number) => {
    setExpandedFAQ(expandedFAQ === index ? null : index);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-pink-900">
      <NavigationHeader />
      
      <div className="container mx-auto px-4 py-8 max-w-6xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-white mb-4">
            Frequently Asked Questions
          </h1>
          <p className="text-gray-300 text-lg">
            Everything you need to know about StreamMe Anime
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <Card className="bg-black/40 border-purple-500/30 sticky top-8">
              <CardHeader>
                <CardTitle className="text-white">Categories</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {categories.map((category) => {
                  const Icon = category.icon;
                  return (
                    <Button
                      key={category.id}
                      onClick={() => setActiveCategory(category.id)}
                      variant={activeCategory === category.id ? "default" : "ghost"}
                      className={`w-full justify-start ${
                        activeCategory === category.id
                          ? "bg-purple-600 text-white"
                          : "text-gray-300 hover:text-white hover:bg-purple-500/20"
                      }`}
                    >
                      {Icon && <Icon className="h-4 w-4 mr-2" />}
                      {category.name}
                    </Button>
                  );
                })}
              </CardContent>
            </Card>

            {/* User Info Card */}
            {user && (
              <Card className="bg-black/40 border-purple-500/30 mt-6">
                <CardHeader>
                  <CardTitle className="text-white flex items-center">
                    <User className="h-5 w-5 mr-2" />
                    Your Account
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center text-gray-300">
                    <Mail className="h-4 w-4 mr-2" />
                    <span className="text-sm">{user.email}</span>
                  </div>
                  <div className="flex items-center text-gray-300">
                    <Calendar className="h-4 w-4 mr-2" />
                    <span className="text-sm">Member since {new Date().toLocaleDateString()}</span>
                  </div>
                  <Badge className="bg-purple-600/20 text-purple-300 border-purple-500/50">
                    {user.chatAccess ? 'Premium Member' : 'Free Member'}
                  </Badge>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3 space-y-6">
            {/* FAQ Items */}
            <div className="space-y-4">
              {filteredFAQs.map((faq, index) => (
                <Card key={index} className="bg-black/40 border-purple-500/30 hover:border-purple-500/50 transition-colors">
                  <CardHeader 
                    className="cursor-pointer"
                    onClick={() => toggleFAQ(index)}
                  >
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white text-lg">{faq.question}</CardTitle>
                      {expandedFAQ === index ? (
                        <ChevronUp className="h-5 w-5 text-purple-400" />
                      ) : (
                        <ChevronDown className="h-5 w-5 text-purple-400" />
                      )}
                    </div>
                  </CardHeader>
                  {expandedFAQ === index && (
                    <CardContent>
                      <p className="text-gray-300 leading-relaxed">{faq.answer}</p>
                    </CardContent>
                  )}
                </Card>
              ))}
            </div>

            {/* Developer Information */}
            <Card className="bg-black/40 border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white text-2xl">About the Developer</CardTitle>
                <CardDescription className="text-gray-400">
                  Meet the creator behind StreamMe Anime
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex flex-col md:flex-row gap-6">
                  <div className="flex-shrink-0">
                    <div className="w-32 h-32 bg-gradient-to-br from-purple-500 to-pink-500 rounded-full flex items-center justify-center">
                      <User className="h-16 w-16 text-white" />
                    </div>
                  </div>
                  <div className="flex-1 space-y-4">
                    <div>
                      <h3 className="text-2xl font-bold text-white">{developerInfo.name}</h3>
                      <p className="text-purple-300 font-medium">{developerInfo.role}</p>
                    </div>
                    <p className="text-gray-300">{developerInfo.bio}</p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div className="flex items-center text-gray-300">
                        <Mail className="h-4 w-4 mr-2" />
                        {developerInfo.email}
                      </div>
                      <div className="flex items-center text-gray-300">
                        <Phone className="h-4 w-4 mr-2" />
                        {developerInfo.phone}
                      </div>
                      <div className="flex items-center text-gray-300">
                        <MapPin className="h-4 w-4 mr-2" />
                        {developerInfo.location}
                      </div>
                      <div className="flex items-center text-gray-300">
                        <Globe className="h-4 w-4 mr-2" />
                        <a href={developerInfo.portfolio} target="_blank" rel="noopener noreferrer" 
                           className="hover:text-purple-400 transition-colors">
                          Portfolio
                        </a>
                      </div>
                    </div>
                  </div>
                </div>

                <Separator className="bg-purple-500/30" />

                <div>
                  <h4 className="text-lg font-semibold text-white mb-3">Technical Skills</h4>
                  <div className="flex flex-wrap gap-2">
                    {developerInfo.skills.map((skill) => (
                      <Badge 
                        key={skill} 
                        className="bg-purple-600/20 text-purple-300 border-purple-500/50"
                      >
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="text-lg font-semibold text-white mb-3">Connect & Explore</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    <a href={developerInfo.social.github} target="_blank" rel="noopener noreferrer"
                       className="flex items-center text-gray-300 hover:text-purple-400 transition-colors p-2 rounded-lg hover:bg-purple-500/20">
                      <Github className="h-4 w-4 mr-2" />
                      GitHub
                      <ExternalLink className="h-3 w-3 ml-1" />
                    </a>
                    <a href={developerInfo.social.linkedin} target="_blank" rel="noopener noreferrer"
                       className="flex items-center text-gray-300 hover:text-purple-400 transition-colors p-2 rounded-lg hover:bg-purple-500/20">
                      <Linkedin className="h-4 w-4 mr-2" />
                      LinkedIn
                      <ExternalLink className="h-3 w-3 ml-1" />
                    </a>
                    <a href={developerInfo.social.telegram} target="_blank" rel="noopener noreferrer"
                       className="flex items-center text-gray-300 hover:text-purple-400 transition-colors p-2 rounded-lg hover:bg-purple-500/20">
                      <Send className="h-4 w-4 mr-2" />
                      Telegram
                      <ExternalLink className="h-3 w-3 ml-1" />
                    </a>
                    <a href={developerInfo.social.facebook} target="_blank" rel="noopener noreferrer"
                       className="flex items-center text-gray-300 hover:text-purple-400 transition-colors p-2 rounded-lg hover:bg-purple-500/20">
                      <User className="h-4 w-4 mr-2" />
                      Facebook
                      <ExternalLink className="h-3 w-3 ml-1" />
                    </a>
                    <a href={developerInfo.social.music_platform} target="_blank" rel="noopener noreferrer"
                       className="flex items-center text-gray-300 hover:text-purple-400 transition-colors p-2 rounded-lg hover:bg-purple-500/20">
                      <Music className="h-4 w-4 mr-2" />
                      Streame ID
                      <ExternalLink className="h-3 w-3 ml-1" />
                    </a>
                    <a href={developerInfo.social.channel} target="_blank" rel="noopener noreferrer"
                       className="flex items-center text-gray-300 hover:text-purple-400 transition-colors p-2 rounded-lg hover:bg-purple-500/20">
                      <MessageCircle className="h-4 w-4 mr-2" />
                      Channel
                      <ExternalLink className="h-3 w-3 ml-1" />
                    </a>
                  </div>
                </div>

                <Separator className="bg-purple-500/30" />

                <div className="bg-purple-600/10 p-4 rounded-lg border border-purple-500/30">
                  <h4 className="text-lg font-semibold text-white mb-2">Need Help?</h4>
                  <p className="text-gray-300 mb-3">
                    For technical support, feature requests, or unlock codes, feel free to reach out:
                  </p>
                  <div className="flex flex-wrap gap-3">
                    <Button 
                      onClick={() => window.open(`https://wa.me/${developerInfo.phone.replace('+', '')}`, '_blank')}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      <Phone className="h-4 w-4 mr-2" />
                      WhatsApp Support
                    </Button>
                    <Button 
                      onClick={() => window.open(`mailto:${developerInfo.email}`, '_blank')}
                      variant="outline"
                      className="border-purple-500/50 text-purple-300 hover:bg-purple-500/20"
                    >
                      <Mail className="h-4 w-4 mr-2" />
                      Email Support
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}