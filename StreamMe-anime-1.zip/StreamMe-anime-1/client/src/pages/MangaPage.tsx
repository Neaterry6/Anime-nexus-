import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Search, ArrowLeft, BookOpen, Heart, Bookmark, Share, ChevronLeft, ChevronRight, X, Maximize, Minimize, Star, Filter, Grid, List } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { VisuallyHidden } from "@radix-ui/react-visually-hidden";

interface MangaItem {
  id: string;
  title: string;
  description: string;
  coverUrl: string;
  status: string;
  author: string;
  year: number;
  tags: string[];
  rating?: number;
}

interface Chapter {
  id: string;
  number: string;
  title: string;
  pages: number;
}

interface ChapterPages {
  title: string;
  pages: string[];
  hash: string;
  baseUrl: string;
}

export default function MangaPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  
  // State for manga list and pagination
  const [mangaList, setMangaList] = useState<MangaItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("all");
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid");
  
  // State for manga details modal
  const [selectedManga, setSelectedManga] = useState<MangaItem | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [chapters, setChapters] = useState<Chapter[]>([]);
  
  // State for reader
  const [showReader, setShowReader] = useState(false);
  const [selectedChapter, setSelectedChapter] = useState<Chapter | null>(null);
  const [chapterPages, setChapterPages] = useState<ChapterPages | null>(null);
  const [currentPageImages, setCurrentPageImages] = useState(0);
  const [isFullscreen, setIsFullscreen] = useState(false);
  
  // State for favorites and bookmarks
  const [favorites, setFavorites] = useState<string[]>([]);
  const [bookmarks, setBookmarks] = useState<string[]>([]);

  // Load favorites and bookmarks from localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('favorites');
    const savedBookmarks = localStorage.getItem('bookmarks');
    
    if (savedFavorites) setFavorites(JSON.parse(savedFavorites));
    if (savedBookmarks) setBookmarks(JSON.parse(savedBookmarks));
    
    // Initial fetch
    fetchTrendingManga();
  }, []);

  // Fetch manga using backend proxy
  const fetchTrendingManga = async (page = 1) => {
    if (isLoading) return;
    setIsLoading(true);
    if (page > 1) setLoadingMore(true);
    
    try {
      let url = `/api/manga/trending?page=${page}`;
      
      if (selectedGenre !== 'all') {
        url += `&genre=${encodeURIComponent(selectedGenre)}`;
      }
      
      if (searchQuery.trim()) {
        url += `&search=${encodeURIComponent(searchQuery.trim())}`;
      }

      const response = await fetch(url);
      if (!response.ok) throw new Error(`API error: ${response.status}`);
      
      const data = await response.json();
      
      if (!data.data || data.data.length === 0) {
        if (page === 1) setMangaList([]);
        return;
      }

      const mangaItems: MangaItem[] = data.data;

      if (page === 1) {
        setMangaList(mangaItems);
      } else {
        setMangaList(prev => [...prev, ...mangaItems]);
      }
      
      setCurrentPage(page);
      
    } catch (error) {
      console.error('Error fetching manga:', error);
      toast({
        title: "Error",
        description: "Failed to load manga. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
      setLoadingMore(false);
    }
  };

  // Fetch chapters using backend proxy
  const fetchChapters = async (mangaId: string) => {
    try {
      const response = await fetch(`/api/manga/${mangaId}/chapters`);
      if (!response.ok) throw new Error(`Chapter API error: ${response.status}`);
      
      const data = await response.json();
      setChapters(data.chapters || []);
    } catch (error) {
      console.error('Error fetching chapters:', error);
      toast({
        title: "Error",
        description: "Failed to load chapters.",
        variant: "destructive"
      });
    }
  };

  // Open manga details modal
  const openMangaModal = (manga: MangaItem) => {
    setSelectedManga(manga);
    setShowModal(true);
    fetchChapters(manga.id);
  };

  // Read chapter using backend proxy
  const readChapter = async (chapter: Chapter) => {
    setSelectedChapter(chapter);
    setIsLoading(true);
    
    try {
      const response = await fetch(`/api/manga/chapter/${chapter.id}/pages`);
      if (!response.ok) throw new Error(`Pages API error: ${response.status}`);
      
      const data = await response.json();
      console.log('Chapter pages data:', data);
      
      // Handle different API response formats
      const pages = data.data || data.pages || [];
      
      if (!pages || pages.length === 0) {
        // Create demo pages for testing if no real pages are available
        const demoPages = Array.from({ length: 5 }, (_, i) => 
          `https://via.placeholder.com/800x1200/1a1a1a/ffffff?text=Page+${i + 1}+Loading...`
        );
        
        setChapterPages({
          title: chapter.title || `Chapter ${chapter.number}`,
          pages: demoPages,
          hash: data.hash || '',
          baseUrl: data.baseUrl || ''
        });
        
        toast({
          title: "Demo Mode",
          description: "This chapter's pages are not available. Showing demo pages to test the reader.",
          variant: "default"
        });
      } else {
        setChapterPages({
          title: chapter.title || `Chapter ${chapter.number}`,
          pages,
          hash: data.hash || '',
          baseUrl: data.baseUrl || ''
        });
      }
      
      setChapterPages({
        title: chapter.title || `Chapter ${chapter.number}`,
        pages,
        hash: data.hash || '',
        baseUrl: data.baseUrl || ''
      });
      
      setCurrentPageImages(0);
      setShowModal(false);
      setShowReader(true);
      
    } catch (error) {
      console.error('Error loading chapter:', error);
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to load chapter pages.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Toggle favorite
  const toggleFavorite = (mangaId: string) => {
    const isFavorite = favorites.includes(mangaId);
    const newFavorites = isFavorite 
      ? favorites.filter(id => id !== mangaId)
      : [...favorites, mangaId];
    
    setFavorites(newFavorites);
    localStorage.setItem('favorites', JSON.stringify(newFavorites));
    
    toast({
      title: isFavorite ? "Removed from favorites" : "Added to favorites",
      description: selectedManga?.title
    });
  };

  // Save bookmark
  const saveBookmark = () => {
    if (!selectedManga || !selectedChapter) return;
    
    const bookmarkId = `${selectedManga.id}-${selectedChapter.id}-${currentPageImages}`;
    const bookmark = {
      id: bookmarkId,
      mangaId: selectedManga.id,
      mangaTitle: selectedManga.title,
      chapterId: selectedChapter.id,
      chapterTitle: selectedChapter.title,
      chapterNumber: selectedChapter.number,
      pageNumber: currentPageImages + 1
    };
    
    const newBookmarks = [...bookmarks, bookmarkId];
    setBookmarks(newBookmarks);
    localStorage.setItem('bookmarks', JSON.stringify(newBookmarks));
    
    toast({
      title: "Bookmark saved",
      description: `${selectedManga.title} - Chapter ${selectedChapter.number}, Page ${currentPageImages + 1}`
    });
  };

  // Close reader
  const closeReader = () => {
    setShowReader(false);
    setChapterPages(null);
    setSelectedChapter(null);
  };

  // Navigation functions
  const goToPrevChapter = () => {
    if (!selectedChapter) return;
    const currentIndex = chapters.findIndex(c => c.id === selectedChapter.id);
    if (currentIndex > 0) {
      const prevChapter = chapters[currentIndex - 1];
      readChapter(prevChapter);
    }
  };

  const goToNextChapter = () => {
    if (!selectedChapter) return;
    const currentIndex = chapters.findIndex(c => c.id === selectedChapter.id);
    if (currentIndex < chapters.length - 1) {
      const nextChapter = chapters[currentIndex + 1];
      readChapter(nextChapter);
    }
  };

  // Fullscreen toggle
  const toggleFullscreen = () => {
    setIsFullscreen(!isFullscreen);
  };

  // Load more manga
  const loadMore = () => {
    if (!isLoading && !loadingMore && mangaList.length > 0) {
      fetchTrendingManga(currentPage + 1);
    }
  };

  // Search effect
  useEffect(() => {
    const delayedSearch = setTimeout(() => {
      setCurrentPage(1);
      fetchTrendingManga(1);
    }, 500);

    return () => clearTimeout(delayedSearch);
  }, [searchQuery, selectedGenre]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 -left-20 w-72 h-72 bg-purple-500 rounded-full mix-blend-multiply filter blur-xl animate-blob"></div>
        <div className="absolute top-1/3 -right-20 w-72 h-72 bg-pink-500 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-2000"></div>
        <div className="absolute bottom-1/4 left-1/2 w-72 h-72 bg-indigo-500 rounded-full mix-blend-multiply filter blur-xl animate-blob animation-delay-4000"></div>
      </div>

      {/* Header */}
      <header className="relative z-50 bg-black/30 backdrop-blur-xl border-b border-white/10 sticky top-0">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-6">
              <Button
                variant="ghost"
                onClick={() => setLocation("/")}
                className="text-white hover:bg-white/10 transition-all duration-300 hover:scale-105"
              >
                <ArrowLeft className="h-5 w-5 mr-2" />
                Back to Home
              </Button>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-indigo-400 bg-clip-text text-transparent">
                  📖 Manga Universe
                </h1>
                <p className="text-sm text-gray-400 mt-1">Discover amazing manga from MangaDx</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="text-white"
              >
                <Grid className="h-4 w-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="text-white"
              >
                <List className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Search and Controls */}
      <div className="relative z-40 max-w-7xl mx-auto px-6 py-8">
        <div className="flex flex-col lg:flex-row gap-4 mb-8">
          <div className="flex-1 relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            <Input
              placeholder="Search for your favorite manga..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-12 pr-4 py-3 bg-black/40 backdrop-blur-xl border-white/20 text-white placeholder:text-gray-400 rounded-xl focus:ring-2 focus:ring-purple-500/50 transition-all duration-300"
            />
          </div>
          <div className="flex gap-3">
            <Select value={selectedGenre} onValueChange={setSelectedGenre}>
              <SelectTrigger className="w-48 bg-black/40 backdrop-blur-xl border-white/20 text-white rounded-xl">
                <Filter className="h-4 w-4 mr-2" />
                <SelectValue placeholder="Genre" />
              </SelectTrigger>
              <SelectContent className="bg-black/90 backdrop-blur-xl border-white/20 rounded-xl">
                <SelectItem value="all">All Genres</SelectItem>
                <SelectItem value="Action">Action</SelectItem>
                <SelectItem value="Romance">Romance</SelectItem>
                <SelectItem value="Fantasy">Fantasy</SelectItem>
                <SelectItem value="Comedy">Comedy</SelectItem>
                <SelectItem value="Drama">Drama</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Results Count */}
        {mangaList.length > 0 && (
          <div className="mb-6">
            <p className="text-gray-300">Found {mangaList.length} manga titles</p>
          </div>
        )}

        {/* Manga Grid/List */}
        {viewMode === 'grid' ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-6">
            {mangaList.map((manga) => (
              <Card 
                key={manga.id}
                className="group bg-black/30 backdrop-blur-xl border-white/10 hover:border-purple-500/50 cursor-pointer transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-purple-500/25 rounded-xl overflow-hidden"
                onClick={() => openMangaModal(manga)}
              >
                <CardContent className="p-0">
                  <div className="aspect-[3/4] relative overflow-hidden">
                    <img 
                      src={manga.coverUrl} 
                      alt={manga.title}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                      loading="lazy"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                    <div className="absolute top-3 right-3">
                      <Heart 
                        className={`h-6 w-6 transition-all duration-300 ${
                          favorites.includes(manga.id) 
                            ? 'fill-red-500 text-red-500 scale-110' 
                            : 'text-white/70 hover:text-red-400'
                        }`}
                      />
                    </div>
                    {manga.rating && (
                      <div className="absolute bottom-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                        <Badge className="bg-yellow-500/90 text-black text-xs font-semibold">
                          <Star className="h-3 w-3 mr-1 fill-current" />
                          {manga.rating.toFixed(1)}
                        </Badge>
                      </div>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="text-white font-semibold text-sm mb-2 line-clamp-2 group-hover:text-purple-300 transition-colors">
                      {manga.title}
                    </h3>
                    <p className="text-gray-400 text-xs mb-3">{manga.author}</p>
                    <div className="flex flex-wrap gap-1">
                      {manga.tags?.slice(0, 2).map((tag, index) => (
                        <Badge key={index} variant="outline" className="text-xs border-purple-500/30 text-purple-300 bg-purple-500/10">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {mangaList.map((manga) => (
              <Card 
                key={manga.id}
                className="group bg-black/30 backdrop-blur-xl border-white/10 hover:border-purple-500/50 cursor-pointer transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/20 rounded-xl overflow-hidden"
                onClick={() => openMangaModal(manga)}
              >
                <CardContent className="p-6">
                  <div className="flex gap-6">
                    <div className="w-24 h-32 relative overflow-hidden rounded-lg flex-shrink-0">
                      <img 
                        src={manga.coverUrl} 
                        alt={manga.title}
                        className="w-full h-full object-cover"
                        loading="lazy"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <h3 className="text-white font-bold text-lg group-hover:text-purple-300 transition-colors">
                          {manga.title}
                        </h3>
                        <Heart 
                          className={`h-5 w-5 ${
                            favorites.includes(manga.id) 
                              ? 'fill-red-500 text-red-500' 
                              : 'text-white/70'
                          }`}
                        />
                      </div>
                      <p className="text-gray-400 text-sm mb-2">By {manga.author} • {manga.year}</p>
                      <p className="text-gray-300 text-sm mb-4 line-clamp-2">{manga.description}</p>
                      <div className="flex flex-wrap gap-2">
                        {manga.tags?.slice(0, 4).map((tag, index) => (
                          <Badge key={index} variant="outline" className="text-xs border-purple-500/30 text-purple-300 bg-purple-500/10">
                            {tag}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Loading States */}
        {isLoading && !loadingMore && (
          <div className="text-center py-16">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-4 border-purple-500 border-t-transparent"></div>
            <p className="text-gray-400 mt-4 text-lg">Loading amazing manga...</p>
          </div>
        )}

        {/* Load More Button */}
        {!isLoading && mangaList.length > 0 && (
          <div className="text-center mt-12">
            <Button 
              onClick={loadMore}
              disabled={loadingMore}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 px-8 py-3 rounded-xl font-semibold transition-all duration-300 hover:scale-105"
            >
              {loadingMore ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent mr-2"></div>
                  Loading...
                </>
              ) : (
                'Load More Manga'
              )}
            </Button>
          </div>
        )}
      </div>

      {/* Manga Details Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="max-w-5xl w-[95vw] h-[90vh] p-0 bg-black/95 backdrop-blur-xl border-white/20 rounded-2xl overflow-hidden">
          <VisuallyHidden>
            <DialogTitle>Manga Details</DialogTitle>
            <DialogDescription>View manga information and chapters</DialogDescription>
          </VisuallyHidden>
          {selectedManga && (
            <div className="flex flex-col h-full">
              {/* Modal Header with Hero Section */}
              <div className="relative">
                {/* Back Button - Top Left */}
                <div className="absolute top-4 left-4 z-30">
                  <Button
                    onClick={() => setShowModal(false)}
                    variant="outline"
                    size="sm"
                    className="border-white/20 bg-black/50 backdrop-blur-xl text-white hover:bg-black/70 hover:border-white/40 transition-all duration-300"
                  >
                    <ArrowLeft className="h-4 w-4 mr-2" />
                    Back
                  </Button>
                </div>

                <div className="absolute inset-0 bg-gradient-to-r from-black via-black/50 to-transparent z-10"></div>
                <img 
                  src={selectedManga.coverUrl} 
                  alt={selectedManga.title}
                  className="w-full h-64 object-cover opacity-30"
                />
                <div className="absolute inset-0 z-20 flex items-end p-8">
                  <div className="flex gap-6">
                    <img 
                      src={selectedManga.coverUrl} 
                      alt={selectedManga.title}
                      className="w-32 h-48 object-cover rounded-xl shadow-2xl"
                    />
                    <div className="flex-1">
                      <h2 className="text-3xl font-bold text-white mb-3">{selectedManga.title}</h2>
                      <p className="text-gray-300 mb-2 text-lg">By {selectedManga.author} • {selectedManga.year}</p>
                      <p className="text-gray-200 text-sm mb-4 line-clamp-3 max-w-2xl">{selectedManga.description}</p>
                      
                      <div className="flex flex-wrap gap-2 mb-6">
                        {selectedManga.tags?.map((tag, index) => (
                          <Badge key={index} className="bg-purple-500/20 border-purple-500/50 text-purple-200 backdrop-blur-sm">
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center gap-4">
                        <Button
                          onClick={() => toggleFavorite(selectedManga.id)}
                          variant="outline"
                          className="border-red-500/50 text-red-400 hover:bg-red-500/20 backdrop-blur-sm"
                        >
                          <Heart className={`h-4 w-4 mr-2 ${favorites.includes(selectedManga.id) ? 'fill-current' : ''}`} />
                          {favorites.includes(selectedManga.id) ? 'Favorited' : 'Add to Favorites'}
                        </Button>
                        <Button variant="outline" className="border-blue-500/50 text-blue-400 hover:bg-blue-500/20 backdrop-blur-sm">
                          <Share className="h-4 w-4 mr-2" />
                          Share
                        </Button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Chapters List */}
              <div className="flex-1 p-8 overflow-hidden relative">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-2xl font-bold text-white">Chapters</h3>
                  {chapters.length > 5 && (
                    <Button
                      onClick={() => {
                        const chaptersContainer = document.getElementById('chapters-container');
                        chaptersContainer?.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      variant="outline"
                      size="sm"
                      className="border-purple-500/50 text-purple-400 hover:bg-purple-500/20"
                    >
                      <ArrowLeft className="h-4 w-4 mr-2 rotate-90" />
                      Scroll to Top
                    </Button>
                  )}
                </div>
                
                {chapters.length > 0 ? (
                  <div 
                    id="chapters-container"
                    className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto pr-4 scroll-smooth"
                    style={{
                      scrollbarWidth: 'thin',
                      scrollbarColor: '#8B5CF6 #1F2937'
                    }}
                  >
                    {chapters.map((chapter, index) => (
                      <div 
                        key={chapter.id}
                        className="group bg-white/5 backdrop-blur-sm rounded-xl p-4 border border-white/10 hover:border-purple-500/50 transition-all duration-300 hover:bg-white/10 hover:scale-[1.02]"
                      >
                        <div className="flex items-center justify-between">
                          <div>
                            <p className="text-white font-semibold">Chapter {chapter.number}</p>
                            {chapter.title && <p className="text-gray-400 text-sm mt-1 line-clamp-1">{chapter.title}</p>}
                            <p className="text-gray-500 text-xs mt-2">{chapter.pages || 'Unknown'} pages</p>
                          </div>
                          <Button
                            onClick={() => readChapter(chapter)}
                            size="sm"
                            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 opacity-0 group-hover:opacity-100 transition-all duration-300 hover:scale-105"
                          >
                            <BookOpen className="h-4 w-4 mr-1" />
                            Read
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <div className="animate-spin rounded-full h-8 w-8 border-2 border-purple-500 border-t-transparent mx-auto mb-4"></div>
                    <p className="text-gray-400">Loading chapters...</p>
                  </div>
                )}
                
                {/* Scroll Indicator */}
                {chapters.length > 5 && (
                  <div className="absolute bottom-8 right-8 text-gray-500 text-xs">
                    <div className="flex items-center gap-2 bg-black/60 backdrop-blur-sm rounded-full px-3 py-2 border border-white/10">
                      <div className="animate-bounce">↕</div>
                      Scroll for more chapters
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Reader View */}
      <Dialog open={showReader} onOpenChange={closeReader}>
        <DialogContent className="max-w-7xl w-[98vw] h-[98vh] p-0 bg-black border-white/20 rounded-2xl">
          <VisuallyHidden>
            <DialogTitle>Manga Reader</DialogTitle>
            <DialogDescription>Read manga chapters</DialogDescription>
          </VisuallyHidden>
          <div className="h-full flex flex-col">
            {/* Reader Header */}
            <div className="flex items-center justify-between p-4 bg-black/90 backdrop-blur-xl border-b border-white/10">
              <div className="flex items-center gap-4">
                <Button onClick={closeReader} variant="outline" size="sm" className="border-red-500/50 text-red-400 hover:bg-red-500/20">
                  <ArrowLeft className="h-4 w-4 mr-2" />
                  Back
                </Button>
                <Button onClick={closeReader} variant="outline" size="sm" className="border-gray-500/50 text-gray-400 hover:bg-gray-500/20">
                  <X className="h-4 w-4 mr-2" />
                  Close
                </Button>
                <div className="text-white">
                  <h3 className="font-bold text-lg">{selectedManga?.title}</h3>
                  <p className="text-sm text-gray-400">
                    {chapterPages?.title} - Page {currentPageImages + 1} of {chapterPages?.pages.length || 0}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <Button
                  onClick={saveBookmark}
                  variant="outline"
                  size="sm"
                  className="border-yellow-500/50 text-yellow-400 hover:bg-yellow-500/20"
                >
                  <Bookmark className="h-4 w-4 mr-2" />
                  Bookmark
                </Button>
                <Button
                  onClick={toggleFullscreen}
                  variant="outline"
                  size="sm"
                  className="border-purple-500/50 text-purple-400 hover:bg-purple-500/20"
                >
                  {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
                </Button>
                <Button
                  onClick={goToPrevChapter}
                  variant="outline"
                  size="sm"
                  className="border-purple-500/50 text-purple-400 hover:bg-purple-500/20"
                  disabled={!selectedChapter || chapters.findIndex(c => c.id === selectedChapter.id) === 0}
                >
                  <ChevronLeft className="h-4 w-4 mr-1" />
                  Prev Chapter
                </Button>
                <Button
                  onClick={goToNextChapter}
                  variant="outline"
                  size="sm"
                  className="border-purple-500/50 text-purple-400 hover:bg-purple-500/20"
                  disabled={!selectedChapter || chapters.findIndex(c => c.id === selectedChapter.id) === chapters.length - 1}
                >
                  Next Chapter
                  <ChevronRight className="h-4 w-4 ml-1" />
                </Button>
              </div>
            </div>

            {/* Reader Content */}
            <div className="flex-1 bg-gray-950 relative overflow-hidden">
              {chapterPages && chapterPages.pages.length > 0 ? (
                <div className="h-full flex flex-col">
                  {/* Current Page Display with Navigation */}
                  <div className="flex-1 flex items-center justify-center p-4 relative">
                    {/* Left Navigation Button */}
                    {currentPageImages > 0 && (
                      <Button
                        onClick={() => setCurrentPageImages(currentPageImages - 1)}
                        className="absolute left-8 top-1/2 transform -translate-y-1/2 z-20 bg-black/80 hover:bg-black/90 backdrop-blur-xl border-2 border-purple-500/50 text-white w-16 h-16 rounded-full shadow-2xl hover:scale-110 transition-all duration-300"
                        size="lg"
                      >
                        <ChevronLeft className="h-8 w-8" />
                      </Button>
                    )}
                    
                    {/* Manga Page Image */}
                    <div className="relative max-w-full max-h-full">
                      <img
                        src={chapterPages.pages[currentPageImages]}
                        alt={`Page ${currentPageImages + 1}`}
                        className="max-w-full max-h-full object-contain shadow-2xl rounded-lg"
                        onError={(e) => {
                          console.error(`Failed to load page ${currentPageImages + 1}`);
                          e.currentTarget.src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjNDQ0Ii8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCIgZm9udC1zaXplPSIxOCIgZmlsbD0iI2ZmZiIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZG9taW5hbnQtYmFzZWxpbmU9Im1pZGRsZSI+UGFnZSBDb3VsZG4ndCBMb2FkPC90ZXh0Pjwvc3ZnPg==';
                        }}
                      />
                    </div>

                    {/* Right Navigation Button */}
                    {currentPageImages < chapterPages.pages.length - 1 && (
                      <Button
                        onClick={() => setCurrentPageImages(currentPageImages + 1)}
                        className="absolute right-8 top-1/2 transform -translate-y-1/2 z-20 bg-black/80 hover:bg-black/90 backdrop-blur-xl border-2 border-purple-500/50 text-white w-16 h-16 rounded-full shadow-2xl hover:scale-110 transition-all duration-300"
                        size="lg"
                      >
                        <ChevronRight className="h-8 w-8" />
                      </Button>
                    )}
                    
                    {/* Page Indicator (Top Right) */}
                    <div className="absolute top-4 right-4 bg-black/80 backdrop-blur-xl rounded-full px-4 py-2 border border-purple-500/50">
                      <p className="text-white font-semibold text-sm">
                        {currentPageImages + 1} / {chapterPages.pages.length}
                      </p>
                    </div>
                  </div>
                  
                  {/* Page Navigation Controls */}
                  <div className="bg-black/95 backdrop-blur-xl border-t border-purple-500/30 p-6">
                    {/* Page Progress Bar - Top */}
                    <div className="mb-6">
                      <div className="w-full bg-gray-800 rounded-full h-3 shadow-inner">
                        <div 
                          className="bg-gradient-to-r from-purple-500 via-pink-500 to-purple-600 h-3 rounded-full transition-all duration-500 shadow-lg"
                          style={{ 
                            width: `${((currentPageImages + 1) / chapterPages.pages.length) * 100}%` 
                          }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-gray-400 mt-2">
                        <span>Start</span>
                        <span className="text-white font-semibold">
                          Page {currentPageImages + 1} of {chapterPages.pages.length}
                        </span>
                        <span>End</span>
                      </div>
                    </div>

                    {/* Main Navigation Buttons */}
                    <div className="flex items-center justify-between gap-6">
                      {/* Previous Page Button */}
                      <Button
                        onClick={() => setCurrentPageImages(Math.max(0, currentPageImages - 1))}
                        disabled={currentPageImages === 0}
                        className="flex-1 bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-4 px-6 rounded-xl shadow-lg hover:shadow-purple-500/25 transition-all duration-300 hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:scale-100"
                        size="lg"
                      >
                        <ChevronLeft className="h-6 w-6 mr-3" />
                        Previous Page
                      </Button>
                      
                      {/* Chapter Info */}
                      <div className="text-center px-6 py-2 bg-purple-500/20 rounded-xl border border-purple-500/30 backdrop-blur-sm min-w-[200px]">
                        <div className="text-white text-lg font-bold">
                          {chapterPages.title}
                        </div>
                        <div className="text-purple-200 text-sm mt-1">
                          {selectedManga?.title}
                        </div>
                      </div>
                      
                      {/* Next Page Button */}
                      <Button
                        onClick={() => setCurrentPageImages(Math.min(chapterPages.pages.length - 1, currentPageImages + 1))}
                        disabled={currentPageImages >= chapterPages.pages.length - 1}
                        className="flex-1 bg-gradient-to-r from-pink-600 to-pink-700 hover:from-pink-700 hover:to-pink-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold py-4 px-6 rounded-xl shadow-lg hover:shadow-pink-500/25 transition-all duration-300 hover:scale-[1.02] disabled:opacity-50 disabled:cursor-not-allowed disabled:scale-100"
                        size="lg"
                      >
                        Next Page
                        <ChevronRight className="h-6 w-6 ml-3" />
                      </Button>
                    </div>
                    
                    {/* Keyboard Shortcuts Hint */}
                    <div className="text-center mt-4">
                      <p className="text-gray-500 text-xs">
                        💡 Tip: Click on the left/right sides of the image to navigate, or use the arrow buttons
                      </p>
                    </div>
                  </div>
                  
                  {/* Left/Right Click Areas for Navigation */}
                  <div 
                    className="absolute left-0 top-0 w-1/3 h-full cursor-pointer z-10 bg-transparent hover:bg-black/10 transition-colors"
                    onClick={() => setCurrentPageImages(Math.max(0, currentPageImages - 1))}
                    title="Previous page"
                  />
                  <div 
                    className="absolute right-0 top-0 w-1/3 h-full cursor-pointer z-10 bg-transparent hover:bg-black/10 transition-colors"
                    onClick={() => setCurrentPageImages(Math.min(chapterPages.pages.length - 1, currentPageImages + 1))}
                    title="Next page"
                  />
                </div>
              ) : (
                <div className="flex items-center justify-center h-full">
                  <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-4 border-purple-500 border-t-transparent mx-auto mb-4"></div>
                    <p className="text-gray-400 text-lg">Loading chapter pages...</p>
                    <p className="text-gray-500 text-sm mt-2">Please wait while we fetch the manga pages</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>


    </div>
  );
}