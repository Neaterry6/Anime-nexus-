import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Users, Shield, Settings, BarChart3, Database, Eye, EyeOff, LogIn, UserCheck, Trash2, Edit, Plus, AlertTriangle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import NavigationHeader from "@/components/navigation-header";

interface AdminUser {
  id: string;
  username: string;
  email: string;
  isPremium: boolean;
  chatAccess: boolean;
  aiTrialsLeft: number;
  joinDate: string;
  lastActive: string;
}

interface SystemStats {
  totalUsers: number;
  activeUsers: number;
  premiumUsers: number;
  totalAnime: number;
  totalManga: number;
  downloadsToday: number;
}

export default function AdminPanel() {
  const [, setLocation] = useLocation();
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [stats, setStats] = useState<SystemStats>({
    totalUsers: 0,
    activeUsers: 0,
    premiumUsers: 0,
    totalAnime: 0,
    totalManga: 0,
    downloadsToday: 0
  });
  const [selectedUser, setSelectedUser] = useState<AdminUser | null>(null);
  const [showUserModal, setShowUserModal] = useState(false);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [userToDelete, setUserToDelete] = useState<AdminUser | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);
  const [uploadType, setUploadType] = useState<'anime' | 'manga' | 'movie'>('anime');
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  // Mock data for demonstration
  const mockUsers: AdminUser[] = [
    {
      id: "1",
      username: "anime_lover_01",
      email: "user1@example.com",
      isPremium: true,
      chatAccess: true,
      aiTrialsLeft: 10,
      joinDate: "2024-01-15",
      lastActive: "2 hours ago"
    },
    {
      id: "2", 
      username: "manga_reader_pro",
      email: "user2@example.com",
      isPremium: false,
      chatAccess: false,
      aiTrialsLeft: 3,
      joinDate: "2024-02-20",
      lastActive: "1 day ago"
    },
    {
      id: "3",
      username: "otaku_supreme",
      email: "user3@example.com", 
      isPremium: true,
      chatAccess: true,
      aiTrialsLeft: 15,
      joinDate: "2024-01-10",
      lastActive: "30 minutes ago"
    }
  ];

  useEffect(() => {
    // Check if admin is already logged in
    const adminAuth = localStorage.getItem('adminAuth');
    const adminToken = localStorage.getItem('adminToken');
    if (adminAuth === 'true' && adminToken) {
      setIsAuthenticated(true);
      loadAdminData();
    } else {
      // Redirect to admin login if not authenticated
      setTimeout(() => {
        setLocation("/admin-login");
      }, 100);
    }
  }, [setLocation]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate login delay
    setTimeout(() => {
      if (email === "akewusholaabdulbakri101@gmail.com" && password === "Makemoney@11") {
        setIsAuthenticated(true);
        localStorage.setItem('adminAuthenticated', 'true');
        loadAdminData();
        toast({
          title: "Admin Login Successful",
          description: "Welcome to the admin panel!",
        });
      } else {
        toast({
          title: "Login Failed",
          description: "Invalid admin credentials. Access denied.",
          variant: "destructive"
        });
      }
      setIsLoading(false);
    }, 1000);
  };

  const loadAdminData = () => {
    // Load mock data
    setUsers(mockUsers);
    setStats({
      totalUsers: 1250,
      activeUsers: 450,
      premiumUsers: 280,
      totalAnime: 4500,
      totalManga: 3200,
      downloadsToday: 1850
    });
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    localStorage.removeItem('adminAuth');
    localStorage.removeItem('adminToken');
    setEmail("");
    setPassword("");
    setLocation("/admin-login");
    toast({
      title: "Logged Out",
      description: "Admin session ended.",
    });
  };

  const toggleUserPremium = (userId: string) => {
    setUsers(users.map(user => 
      user.id === userId 
        ? { ...user, isPremium: !user.isPremium, chatAccess: !user.isPremium }
        : user
    ));
    toast({
      title: "User Updated",
      description: "User premium status changed.",
    });
  };

  const confirmDeleteUser = (user: AdminUser) => {
    setUserToDelete(user);
    setShowDeleteConfirm(true);
  };

  const handleDeleteUser = async () => {
    if (!userToDelete) return;
    
    try {
      // In a real app, this would call the API to delete the user
      setUsers(users.filter(u => u.id !== userToDelete.id));
      setShowDeleteConfirm(false);
      setUserToDelete(null);
      
      toast({
        title: "User Account Permanently Deleted",
        description: `Account "${userToDelete.username}" (${userToDelete.email}) has been removed from the system.`,
        variant: "destructive"
      });
    } catch (error) {
      toast({
        title: "Delete Failed",
        description: "Unable to delete user account. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleUpload = (type: 'anime' | 'manga' | 'movie') => {
    setUploadType(type);
    setShowUploadModal(true);
  };

  const handleUploadSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    try {
      setIsLoading(true);
      
      // In a real app, this would upload to your backend
      const uploadData = {
        type: uploadType,
        title: formData.get('title'),
        description: formData.get('description'),
        genre: formData.get('genre'),
        year: formData.get('year'),
        file: formData.get('file')
      };

      // Simulate upload
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setShowUploadModal(false);
      toast({
        title: "Upload Successful",
        description: `${uploadType.charAt(0).toUpperCase() + uploadType.slice(1)} "${uploadData.title}" has been uploaded successfully.`,
      });
      
      // Refresh admin data
      loadAdminData();
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "Failed to upload content. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const viewUserDetails = (user: AdminUser) => {
    setSelectedUser(user);
    setShowUserModal(true);
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-pink-900 flex items-center justify-center">
        <div className="text-center text-white">
          <div className="animate-spin w-8 h-8 border-2 border-white border-t-transparent rounded-full mx-auto mb-4"></div>
          <p>Checking admin authentication...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-black to-pink-900">
      <NavigationHeader title="Admin Panel" />
      
      <div className="container mx-auto px-4 py-8">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white">Admin Dashboard</h1>
            <p className="text-gray-400">StreamMe Anime Administration Panel</p>
          </div>
          <div className="flex items-center gap-4">
            <Badge className="bg-green-600/20 text-green-300 border-green-500/50">
              <Shield className="h-3 w-3 mr-1" />
              Administrator
            </Badge>
            <Button onClick={handleLogout} variant="destructive">
              Logout
            </Button>
          </div>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="bg-black/40 border-purple-500/30">
            <TabsTrigger value="overview" className="text-white">Overview</TabsTrigger>
            <TabsTrigger value="users" className="text-white">Users</TabsTrigger>
            <TabsTrigger value="content" className="text-white">Content</TabsTrigger>
            <TabsTrigger value="settings" className="text-white">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
              <Card className="bg-black/40 border-purple-500/30">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-purple-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{stats.totalUsers.toLocaleString()}</div>
                  <p className="text-xs text-gray-400">+12% from last month</p>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-purple-500/30">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white">Active Users</CardTitle>
                  <UserCheck className="h-4 w-4 text-green-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{stats.activeUsers.toLocaleString()}</div>
                  <p className="text-xs text-gray-400">Last 24 hours</p>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-purple-500/30">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white">Premium Users</CardTitle>
                  <Shield className="h-4 w-4 text-yellow-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{stats.premiumUsers.toLocaleString()}</div>
                  <p className="text-xs text-gray-400">22% conversion rate</p>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-purple-500/30">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white">Total Anime</CardTitle>
                  <BarChart3 className="h-4 w-4 text-blue-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{stats.totalAnime.toLocaleString()}</div>
                  <p className="text-xs text-gray-400">Updated daily</p>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-purple-500/30">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white">Total Manga</CardTitle>
                  <Database className="h-4 w-4 text-pink-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{stats.totalManga.toLocaleString()}</div>
                  <p className="text-xs text-gray-400">Growing collection</p>
                </CardContent>
              </Card>

              <Card className="bg-black/40 border-purple-500/30">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-white">Downloads Today</CardTitle>
                  <BarChart3 className="h-4 w-4 text-red-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">{stats.downloadsToday.toLocaleString()}</div>
                  <p className="text-xs text-gray-400">+5% from yesterday</p>
                </CardContent>
              </Card>
            </div>

            <Alert className="bg-black/40 border-purple-500/30">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription className="text-white">
                System Status: All services operational. Server uptime: 99.9%
              </AlertDescription>
            </Alert>
          </TabsContent>

          <TabsContent value="users">
            <Card className="bg-black/40 border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white">User Management</CardTitle>
                <CardDescription className="text-gray-400">
                  Manage user accounts and permissions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-medium text-white">Registered Users</h3>
                    <Button className="bg-purple-600 hover:bg-purple-700">
                      <Plus className="h-4 w-4 mr-2" />
                      Add User
                    </Button>
                  </div>
                  
                  <Table>
                    <TableHeader>
                      <TableRow className="border-purple-500/30">
                        <TableHead className="text-purple-300">Username</TableHead>
                        <TableHead className="text-purple-300">Email</TableHead>
                        <TableHead className="text-purple-300">Status</TableHead>
                        <TableHead className="text-purple-300">Trials Left</TableHead>
                        <TableHead className="text-purple-300">Last Active</TableHead>
                        <TableHead className="text-purple-300">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.map((user) => (
                        <TableRow key={user.id} className="border-purple-500/20">
                          <TableCell className="text-white">{user.username}</TableCell>
                          <TableCell className="text-gray-400">{user.email}</TableCell>
                          <TableCell>
                            <Badge className={user.isPremium ? "bg-yellow-600/20 text-yellow-300" : "bg-gray-600/20 text-gray-300"}>
                              {user.isPremium ? "Premium" : "Free"}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-white">{user.aiTrialsLeft}</TableCell>
                          <TableCell className="text-gray-400">{user.lastActive}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              <Button
                                onClick={() => viewUserDetails(user)}
                                size="sm"
                                variant="outline"
                                className="border-blue-500/50 text-blue-400"
                              >
                                View
                              </Button>
                              <Button
                                onClick={() => toggleUserPremium(user.id)}
                                size="sm"
                                variant="outline"
                                className="border-yellow-500/50 text-yellow-400"
                              >
                                <Edit className="h-3 w-3" />
                              </Button>
                              <Button
                                onClick={() => confirmDeleteUser(user)}
                                size="sm"
                                variant="destructive"
                                title="Delete user account permanently"
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="content">
            <div className="grid gap-6">
              <Card className="bg-black/40 border-purple-500/30">
                <CardHeader>
                  <CardTitle className="text-white">Content Management</CardTitle>
                  <CardDescription className="text-gray-400">
                    Upload and manage anime, manga, and media content
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Upload Section */}
                  <div className="bg-gradient-to-r from-purple-900/20 to-pink-900/20 border border-purple-500/30 rounded-lg p-6">
                    <h4 className="font-semibold text-white mb-4 flex items-center">
                      <Plus className="h-5 w-5 mr-2" />
                      Upload New Content
                    </h4>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <Button 
                        onClick={() => handleUpload('anime')}
                        className="bg-blue-600 hover:bg-blue-700 h-20 flex-col"
                      >
                        <Plus className="h-6 w-6 mb-2" />
                        Upload Anime
                      </Button>
                      <Button 
                        onClick={() => handleUpload('manga')}
                        className="bg-pink-600 hover:bg-pink-700 h-20 flex-col"
                      >
                        <Plus className="h-6 w-6 mb-2" />
                        Upload Manga
                      </Button>
                      <Button 
                        onClick={() => handleUpload('movie')}
                        className="bg-green-600 hover:bg-green-700 h-20 flex-col"
                      >
                        <Plus className="h-6 w-6 mb-2" />
                        Upload Movie
                      </Button>
                    </div>
                  </div>

                  {/* Content Statistics */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <h4 className="font-medium text-white">Anime Collection</h4>
                      <p className="text-gray-400">Total: {stats.totalAnime} titles</p>
                      <div className="flex gap-2">
                        <Button className="bg-blue-600 hover:bg-blue-700">
                          Manage Anime
                        </Button>
                        <Button variant="outline" className="border-blue-500/50 text-blue-400">
                          View Library
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <h4 className="font-medium text-white">Manga Collection</h4>
                      <p className="text-gray-400">Total: {stats.totalManga} titles</p>
                      <div className="flex gap-2">
                        <Button className="bg-pink-600 hover:bg-pink-700">
                          Manage Manga
                        </Button>
                        <Button variant="outline" className="border-pink-500/50 text-pink-400">
                          View Library
                        </Button>
                      </div>
                    </div>
                  </div>

                  {/* Recent Uploads */}
                  <div className="space-y-4">
                    <h4 className="font-medium text-white">Recent Uploads</h4>
                    <div className="bg-black/20 rounded-lg p-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between py-2 border-b border-gray-700/50">
                          <div className="flex items-center gap-3">
                            <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                            <span className="text-white">Demon Slayer Season 4</span>
                            <Badge className="bg-blue-600/20 text-blue-300">Anime</Badge>
                          </div>
                          <span className="text-gray-400 text-sm">2 hours ago</span>
                        </div>
                        <div className="flex items-center justify-between py-2 border-b border-gray-700/50">
                          <div className="flex items-center gap-3">
                            <div className="w-2 h-2 bg-pink-500 rounded-full"></div>
                            <span className="text-white">One Piece Chapter 1100</span>
                            <Badge className="bg-pink-600/20 text-pink-300">Manga</Badge>
                          </div>
                          <span className="text-gray-400 text-sm">1 day ago</span>
                        </div>
                        <div className="flex items-center justify-between py-2">
                          <div className="flex items-center gap-3">
                            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                            <span className="text-white">Your Name (2016)</span>
                            <Badge className="bg-green-600/20 text-green-300">Movie</Badge>
                          </div>
                          <span className="text-gray-400 text-sm">3 days ago</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="settings">
            <Card className="bg-black/40 border-purple-500/30">
              <CardHeader>
                <CardTitle className="text-white">System Settings</CardTitle>
                <CardDescription className="text-gray-400">
                  Configure application settings
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <h4 className="font-medium text-white">API Configuration</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-white mb-2">
                        Zetsu API Key
                      </label>
                      <Input
                        value="dbcbb1d2cd6121874d41b092f4d93a61"
                        className="bg-black/50 border-purple-500/30 text-white"
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-white mb-2">
                        Rate Limit (requests/min)
                      </label>
                      <Input
                        value="100"
                        className="bg-black/50 border-purple-500/30 text-white"
                      />
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-medium text-white">User Settings</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-white mb-2">
                        Default AI Trials
                      </label>
                      <Input
                        value="5"
                        className="bg-black/50 border-purple-500/30 text-white"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-white mb-2">
                        Premium Trial Days
                      </label>
                      <Input
                        value="7"
                        className="bg-black/50 border-purple-500/30 text-white"
                      />
                    </div>
                  </div>
                </div>

                <Button className="bg-green-600 hover:bg-green-700">
                  <Settings className="h-4 w-4 mr-2" />
                  Save Settings
                </Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* User Details Modal */}
      <Dialog open={showUserModal} onOpenChange={setShowUserModal}>
        <DialogContent className="bg-black/90 border-purple-500/30 text-white">
          <DialogHeader>
            <DialogTitle>User Details</DialogTitle>
            <DialogDescription className="text-gray-400">
              Detailed user account information
            </DialogDescription>
          </DialogHeader>
          
          {selectedUser && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium text-purple-300">Username</label>
                  <p className="text-white">{selectedUser.username}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-purple-300">Email</label>
                  <p className="text-white">{selectedUser.email}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-purple-300">Account Type</label>
                  <Badge className={selectedUser.isPremium ? "bg-yellow-600/20 text-yellow-300" : "bg-gray-600/20 text-gray-300"}>
                    {selectedUser.isPremium ? "Premium" : "Free"}
                  </Badge>
                </div>
                <div>
                  <label className="text-sm font-medium text-purple-300">AI Trials Left</label>
                  <p className="text-white">{selectedUser.aiTrialsLeft}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-purple-300">Join Date</label>
                  <p className="text-white">{selectedUser.joinDate}</p>
                </div>
                <div>
                  <label className="text-sm font-medium text-purple-300">Last Active</label>
                  <p className="text-white">{selectedUser.lastActive}</p>
                </div>
              </div>
              
              <div className="flex gap-2 pt-4">
                <Button
                  onClick={() => toggleUserPremium(selectedUser.id)}
                  className="bg-yellow-600 hover:bg-yellow-700"
                >
                  {selectedUser.isPremium ? "Remove Premium" : "Grant Premium"}
                </Button>
                <Button
                  onClick={() => setShowUserModal(false)}
                  variant="outline"
                  className="border-gray-500/30 text-gray-400"
                >
                  Close
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={showDeleteConfirm} onOpenChange={setShowDeleteConfirm}>
        <DialogContent className="bg-black/90 border-red-500/50 text-white">
          <DialogHeader>
            <DialogTitle className="text-red-400">⚠️ Permanent Account Deletion</DialogTitle>
            <DialogDescription className="text-gray-400">
              This action cannot be undone. This will permanently delete the user account and remove all associated data.
            </DialogDescription>
          </DialogHeader>
          
          {userToDelete && (
            <div className="space-y-4">
              <div className="bg-red-900/20 border border-red-500/30 rounded p-4">
                <h4 className="font-semibold text-red-300 mb-2">Account to be deleted:</h4>
                <div className="space-y-1 text-sm">
                  <p><span className="text-gray-400">Username:</span> <span className="text-white">{userToDelete.username}</span></p>
                  <p><span className="text-gray-400">Email:</span> <span className="text-white">{userToDelete.email}</span></p>
                  <p><span className="text-gray-400">Status:</span> <span className="text-white">{userToDelete.isPremium ? "Premium" : "Free"}</span></p>
                  <p><span className="text-gray-400">Join Date:</span> <span className="text-white">{userToDelete.joinDate}</span></p>
                </div>
              </div>
              
              <div className="flex items-center justify-end gap-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowDeleteConfirm(false);
                    setUserToDelete(null);
                  }}
                  className="border-gray-500/50 text-gray-300"
                >
                  Cancel
                </Button>
                <Button
                  variant="destructive"
                  onClick={handleDeleteUser}
                  className="bg-red-600 hover:bg-red-700"
                >
                  <Trash2 className="h-4 w-4 mr-2" />
                  Delete Permanently
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Upload Modal */}
      <Dialog open={showUploadModal} onOpenChange={setShowUploadModal}>
        <DialogContent className="bg-black/90 border-purple-500/50 text-white max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-purple-400">
              Upload {uploadType.charAt(0).toUpperCase() + uploadType.slice(1)}
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Add new {uploadType} content to the platform
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleUploadSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-white">Title</label>
                <Input
                  name="title"
                  placeholder={`Enter ${uploadType} title`}
                  className="bg-black/50 border-purple-500/30 text-white"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-white">Genre</label>
                <Input
                  name="genre"
                  placeholder="Action, Adventure, Comedy"
                  className="bg-black/50 border-purple-500/30 text-white"
                  required
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">Description</label>
              <textarea
                name="description"
                placeholder={`Enter ${uploadType} description`}
                className="w-full h-24 px-3 py-2 bg-black/50 border border-purple-500/30 rounded-md text-white placeholder:text-gray-400 resize-none"
                required
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-white">Year</label>
                <Input
                  name="year"
                  type="number"
                  placeholder="2024"
                  className="bg-black/50 border-purple-500/30 text-white"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-white">Rating</label>
                <Input
                  name="rating"
                  type="number"
                  step="0.1"
                  max="10"
                  min="0"
                  placeholder="8.5"
                  className="bg-black/50 border-purple-500/30 text-white"
                />
              </div>
            </div>
            
            <div className="space-y-2">
              <label className="text-sm font-medium text-white">
                {uploadType === 'anime' ? 'Video File' : uploadType === 'manga' ? 'Archive File' : 'Movie File'}
              </label>
              <input
                name="file"
                type="file"
                accept={uploadType === 'anime' ? 'video/*' : uploadType === 'manga' ? '.zip,.rar,.cbz,.cbr' : 'video/*'}
                className="w-full px-3 py-2 bg-black/50 border border-purple-500/30 rounded-md text-white file:mr-4 file:py-2 file:px-4 file:rounded-md file:border-0 file:text-sm file:font-medium file:bg-purple-600 file:text-white hover:file:bg-purple-700"
                required
              />
            </div>
            
            <div className="flex items-center justify-end gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowUploadModal(false)}
                className="border-gray-500/50 text-gray-300"
                disabled={isLoading}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className={`${
                  uploadType === 'anime' ? 'bg-blue-600 hover:bg-blue-700' :
                  uploadType === 'manga' ? 'bg-pink-600 hover:bg-pink-700' :
                  'bg-green-600 hover:bg-green-700'
                }`}
                disabled={isLoading}
              >
                {isLoading ? (
                  <div className="flex items-center">
                    <div className="animate-spin w-4 h-4 border-2 border-white border-t-transparent rounded-full mr-2"></div>
                    Uploading...
                  </div>
                ) : (
                  <>
                    <Plus className="h-4 w-4 mr-2" />
                    Upload {uploadType.charAt(0).toUpperCase() + uploadType.slice(1)}
                  </>
                )}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}