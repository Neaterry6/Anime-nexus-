import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";
import EnhancedChatRoom from "@/components/enhanced-chat-room";
import { 
  Search, 
  Download, 
  Play, 
  Star, 
  Calendar, 
  Filter,
  MessageCircle,
  Users,
  TrendingUp,
  Bot,
  Send,
  Settings,
  User,
  LogOut,
  LogIn,
  Sparkles,
  X,
  ChevronRight,
  BookOpen
} from "lucide-react";

interface Anime {
  id: string;
  title: string;
  description: string;
  genre: string;
  year: number;
  rating: number;
  episodes: number;
  imageUrl: string;
  downloadUrl: string;
  status: string;
}

interface Stats {
  totalAnime: number;
  activeUsers: number;
  downloadsToday: number;
  onlineNow: number;
}

export default function Home() {
  const [anime, setAnime] = useState<Anime[]>([]);
  const [trending, setTrending] = useState<Anime[]>([]);
  const [stats, setStats] = useState<Stats | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("All Genres");
  const [activeTab, setActiveTab] = useState("home");
  const [isLoading, setIsLoading] = useState(true);
  const [selectedAnime, setSelectedAnime] = useState<Anime | null>(null);
  const [showEpisodeModal, setShowEpisodeModal] = useState(false);
  
  const { user, logout, isLoading: authLoading } = useAuth();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  useEffect(() => {
    fetchAnime();
    fetchTrending();
    fetchStats();
  }, []);

  const fetchAnime = async () => {
    try {
      const url = new URL("/api/anime", window.location.origin);
      if (searchQuery) url.searchParams.append("search", searchQuery);
      if (selectedGenre !== "All Genres") url.searchParams.append("genre", selectedGenre);

      const response = await fetch(url.toString());
      if (response.ok) {
        const data = await response.json();
        setAnime(data);
      }
    } catch (error) {
      console.error("Error fetching anime:", error);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchTrending = async () => {
    try {
      const response = await fetch("/api/anime/trending");
      if (response.ok) {
        const data = await response.json();
        // Handle the new API response structure with result array
        if (data.result && Array.isArray(data.result)) {
          setTrending(data.result);
        } else if (Array.isArray(data)) {
          setTrending(data);
        } else {
          console.error("Unexpected trending data format:", data);
          setTrending([]);
        }
      }
    } catch (error) {
      console.error("Error fetching trending:", error);
      setTrending([]);
    }
  };

  const fetchStats = async () => {
    try {
      const response = await fetch("/api/stats");
      if (response.ok) {
        const data = await response.json();
        setStats(data);
      }
    } catch (error) {
      console.error("Error fetching stats:", error);
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchAnime();
  };

  const handleDownload = (anime: Anime) => {
    setSelectedAnime(anime);
    setShowEpisodeModal(true);
  };

  const handleEpisodeDownload = (episodeNumber: number) => {
    if (!selectedAnime) return;
    
    toast({
      title: "Download Started",
      description: `Starting download for ${selectedAnime.title} Episode ${episodeNumber}`,
    });
    
    // In a real app, this would call the movie download API with episode number
    // Example: downloadMovie(selectedAnime.title, episodeNumber.toString())
    window.open(`${selectedAnime.downloadUrl}?episode=${episodeNumber}`, '_blank');
    
    setShowEpisodeModal(false);
    setSelectedAnime(null);
  };

  const handleLogout = () => {
    logout();
    toast({
      title: "Logged Out",
      description: "You have been successfully logged out.",
    });
  };

  const genres = ["All Genres", "Action", "Romance", "Comedy", "Drama", "Fantasy", "Thriller", "Slice of Life"];

  if (authLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-anime-dark">
        <div className="text-center space-y-4">
          <div className="animate-spin w-12 h-12 border-4 border-purple-500 border-t-transparent rounded-full mx-auto"></div>
          <p className="text-white text-lg">Loading StreamMe Anime...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-anime-dark relative">
      {/* Background Animation */}
      <div className="bg-animation">
        <div className="bg-circle circle-1"></div>
        <div className="bg-circle circle-2"></div>
      </div>
      
      {/* Header */}
      <header className="bg-black/20 backdrop-blur-md border-b border-purple-500/20 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img 
                src="https://files.catbox.moe/d15q3r.png" 
                alt="StreamMe Logo" 
                className="w-10 h-10 logo-pulse"
              />
              <div>
                <div className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  StreamMe Zone
                </div>
                <Badge variant="outline" className="text-xs border-purple-500/30 text-purple-300 mt-1">
                  heisbroken vzn
                </Badge>
              </div>
            </div>
            
            <nav className="hidden md:flex items-center space-x-1">
              <Button
                variant={activeTab === "home" ? "default" : "ghost"}
                onClick={() => setActiveTab("home")}
                className="text-white hover:bg-purple-600/20"
                data-testid="nav-home"
              >
                🏠 Home
              </Button>
              <Button
                variant={activeTab === "catalog" ? "default" : "ghost"}
                onClick={() => setActiveTab("catalog")}
                className="text-white hover:bg-purple-600/20"
                data-testid="nav-catalog"
              >
                📚 Catalog
              </Button>
              <Button
                variant={activeTab === "chat" ? "default" : "ghost"}
                onClick={() => setActiveTab("chat")}
                className="text-white hover:bg-purple-600/20"
                data-testid="nav-chat"
              >
                💬 Chat
              </Button>
              <Button
                variant={activeTab === "trending" ? "default" : "ghost"}
                onClick={() => setActiveTab("trending")}
                className="text-white hover:bg-purple-600/20"
                data-testid="nav-trending"
              >
                🔥 Trending
              </Button>
              <Button
                variant="ghost"
                onClick={() => setLocation("/chatbot")}
                className="text-white hover:bg-purple-600/20"
                data-testid="nav-chatbot"
              >
                💬 Community Chat
              </Button>
              <Button
                variant="ghost"
                onClick={() => setLocation("/anime")}
                className="text-white hover:bg-purple-600/20"
                data-testid="nav-anime"
              >
                📺 Anime
              </Button>
              <Button
                variant="ghost"
                onClick={() => setLocation("/manga")}
                className="text-white hover:bg-purple-600/20"
                data-testid="nav-manga"
              >
                📖 Manga
              </Button>
              <Button
                variant="ghost"
                onClick={() => setLocation("/movies")}
                className="text-white hover:bg-purple-600/20"
                data-testid="nav-movies"
              >
                🎬 Movies
              </Button>
              <Button
                variant="ghost"
                onClick={() => setLocation("/faq")}
                className="text-white hover:bg-purple-600/20"
                data-testid="nav-faq"
              >
                ❓ FAQ
              </Button>
            </nav>

            <div className="flex items-center space-x-3">
              {user ? (
                <>
                  <div className="flex items-center space-x-2 text-white">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={user.avatar || undefined} />
                      <AvatarFallback className="bg-purple-600">
                        {user.username[0].toUpperCase()}
                      </AvatarFallback>
                    </Avatar>
                    <div className="hidden md:block">
                      <p className="text-sm font-medium">{user.username}</p>
                      <p className="text-xs text-purple-400">
                        {user.isPremium ? "Premium" : `${user.aiTrialsLeft} trials left`}
                      </p>
                    </div>
                  </div>
                  <Button 
                    variant="ghost" 
                    onClick={() => setLocation("/settings")} 
                    className="text-white hover:bg-purple-600/20" 
                    data-testid="button-settings"
                  >
                    <Settings className="h-4 w-4" />
                  </Button>
                  {/* Admin Access Button */}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setLocation("/admin")}
                    className="bg-black/30 border-red-500/50 text-red-400 hover:bg-red-900/20 hover:border-red-400 text-xs"
                    title="Admin Access"
                  >
                    🔐
                  </Button>
                  <Button variant="ghost" onClick={handleLogout} className="text-white hover:bg-red-600/20" data-testid="button-logout">
                    <LogOut className="h-4 w-4" />
                  </Button>
                </>
              ) : (
                <div className="flex items-center space-x-3">
                  <Button onClick={() => setLocation("/auth")} className="bg-gradient-to-r from-purple-600 to-pink-600" data-testid="button-login">
                    <LogIn className="mr-2 h-4 w-4" />
                    Login
                  </Button>
                  {/* Admin Access for non-logged users */}
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setLocation("/admin")}
                    className="bg-black/30 border-red-500/50 text-red-400 hover:bg-red-900/20 hover:border-red-400 text-xs"
                    title="Admin Access"
                  >
                    🔐
                  </Button>
                </div>
              )}
            </div>
          </div>
          
          {/* Mobile Navigation */}
          <div className="md:hidden mt-4">
            <div className="flex space-x-1 overflow-x-auto">
              {["home", "catalog", "chat", "trending"].map((tab) => (
                <Button
                  key={tab}
                  variant={activeTab === tab ? "default" : "ghost"}
                  onClick={() => setActiveTab(tab)}
                  className="text-white hover:bg-purple-600/20 whitespace-nowrap"
                  data-testid={`nav-mobile-${tab}`}
                >
                  {tab === "home" && "🏠"}
                  {tab === "catalog" && "📚"}
                  {tab === "chat" && "💬"}
                  {tab === "trending" && "🔥"}
                  {" "}
                  {tab.charAt(0).toUpperCase() + tab.slice(1)}
                </Button>
              ))}
              <Button
                variant="ghost"
                onClick={() => setLocation("/chatbot")}
                className="text-white hover:bg-purple-600/20 whitespace-nowrap"
              >
                🤖 AI Chat
              </Button>
              <Button
                variant="ghost"
                onClick={() => setLocation("/anime")}
                className="text-white hover:bg-purple-600/20 whitespace-nowrap"
              >
                📺 Anime
              </Button>
              <Button
                variant="ghost"
                onClick={() => setLocation("/manga")}
                className="text-white hover:bg-purple-600/20 whitespace-nowrap"
              >
                📖 Manga
              </Button>
              <Button
                variant="ghost"
                onClick={() => setLocation("/movies")}
                className="text-white hover:bg-purple-600/20 whitespace-nowrap"
              >
                🎬 Movies
              </Button>
              <Button
                variant="ghost"
                onClick={() => setLocation("/faq")}
                className="text-white hover:bg-purple-600/20 whitespace-nowrap"
              >
                ❓ FAQ
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Home Section */}
        {activeTab === "home" && (
          <div className="space-y-8">
            {/* Hero Section */}
            <div className="text-center space-y-6 mb-12">
              <h1 className="text-6xl md:text-8xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
                StreamMe Anime
              </h1>
              <p className="text-xl text-gray-300 max-w-2xl mx-auto">
                Discover, stream, and download your favorite anime content. Join our community for real-time discussions and AI-powered recommendations.
              </p>
              <div className="flex flex-wrap justify-center gap-4 mt-6">
                {!user ? (
                  <Button 
                    onClick={() => setLocation("/auth")} 
                    size="lg" 
                    className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                    data-testid="hero-signup"
                  >
                    Get Started Free
                  </Button>
                ) : (
                  <>
                    <Button
                      onClick={() => setLocation("/ai-chat")}
                      size="lg"
                      className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                    >
                      <Bot className="mr-2 h-5 w-5" />
                      AI Chatbot
                    </Button>
                    <Button
                      onClick={() => setLocation("/anime")}
                      size="lg"
                      className="bg-gradient-to-r from-pink-600 to-red-600 hover:from-pink-700 hover:to-red-700"
                    >
                      <Play className="mr-2 h-5 w-5" />
                      Anime Collection
                    </Button>
                    <Button
                      onClick={() => setLocation("/manga")}
                      size="lg"
                      className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
                    >
                      <BookOpen className="mr-2 h-5 w-5" />
                      Manga Library
                    </Button>
                  </>
                )}
              </div>
            </div>

            {/* Stats Cards */}
            {stats && (
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-purple-400">{stats.totalAnime}</div>
                    <div className="text-sm text-gray-400">Total Anime</div>
                  </CardContent>
                </Card>
                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-pink-400">{stats.activeUsers.toLocaleString()}</div>
                    <div className="text-sm text-gray-400">Active Users</div>
                  </CardContent>
                </Card>
                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-blue-400">{stats.downloadsToday.toLocaleString()}</div>
                    <div className="text-sm text-gray-400">Downloads Today</div>
                  </CardContent>
                </Card>
                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-green-400">{stats.onlineNow.toLocaleString()}</div>
                    <div className="text-sm text-gray-400">Online Now</div>
                  </CardContent>
                </Card>
              </div>
            )}

            {/* Trending Preview */}
            <div className="space-y-4">
              <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                <TrendingUp className="h-6 w-6 text-purple-400" />
                Trending Now
              </h2>
              <div className="grid md:grid-cols-3 gap-6">
                {trending.map((item) => (
                  <Card key={item.id} className="bg-black/20 backdrop-blur-md border-purple-500/20 hover:border-purple-400/40 transition-colors group" data-testid={`anime-card-${item.id}`}>
                    <div className="relative">
                      <img 
                        src={item.imageUrl} 
                        alt={item.title}
                        className="w-full h-48 object-cover rounded-t-lg"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent rounded-t-lg" />
                      <div className="absolute top-2 right-2">
                        <Badge className="bg-purple-600/80 text-white">
                          ⭐ {item.rating}
                        </Badge>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <h3 className="font-semibold text-white mb-2 group-hover:text-purple-400 transition-colors">
                        {item.title}
                      </h3>
                      <p className="text-gray-400 text-sm mb-3 line-clamp-2">
                        {item.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2 text-xs text-gray-500">
                          <Calendar className="h-3 w-3" />
                          <span>{item.year}</span>
                          <span>•</span>
                          <span>{item.episodes} eps</span>
                        </div>
                        <Button 
                          size="sm" 
                          onClick={() => handleDownload(item)}
                          className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                          data-testid={`download-${item.id}`}
                        >
                          <Download className="h-3 w-3 mr-1" />
                          Download
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Catalog Section */}
        {activeTab === "catalog" && (
          <div className="space-y-6">
            <div className="flex flex-col md:flex-row gap-4 items-start md:items-center justify-between">
              <h2 className="text-3xl font-bold text-white">Anime Catalog</h2>
              
              <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
                <form onSubmit={handleSearch} className="flex gap-2">
                  <Input
                    placeholder="Search anime..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-black/30 border-purple-500/30 text-white placeholder:text-gray-400"
                    data-testid="search-input"
                  />
                  <Button type="submit" className="bg-purple-600 hover:bg-purple-700" data-testid="search-button">
                    <Search className="h-4 w-4" />
                  </Button>
                </form>
                
                <select
                  value={selectedGenre}
                  onChange={(e) => {
                    setSelectedGenre(e.target.value);
                    setTimeout(fetchAnime, 100);
                  }}
                  className="bg-black/30 border border-purple-500/30 text-white rounded-md px-3 py-2"
                  data-testid="genre-filter"
                >
                  {genres.map((genre) => (
                    <option key={genre} value={genre} className="bg-black">
                      {genre}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {isLoading ? (
              <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-6">
                {[...Array(8)].map((_, i) => (
                  <Card key={i} className="bg-black/20 backdrop-blur-md border-purple-500/20">
                    <div className="animate-pulse">
                      <div className="h-48 bg-gray-700 rounded-t-lg" />
                      <CardContent className="p-4 space-y-2">
                        <div className="h-4 bg-gray-700 rounded" />
                        <div className="h-3 bg-gray-700 rounded w-2/3" />
                        <div className="h-8 bg-gray-700 rounded" />
                      </CardContent>
                    </div>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid md:grid-cols-3 lg:grid-cols-4 gap-6" data-testid="anime-grid">
                {anime.map((item) => (
                  <Card key={item.id} className="anime-card group" data-testid={`anime-card-${item.id}`}>
                    <div className="relative">
                      <img 
                        src={item.imageUrl} 
                        alt={item.title}
                        className="w-full h-36 object-cover rounded-lg mb-2"
                        loading="lazy"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent rounded-lg" />
                      <div className="absolute top-2 right-2">
                        <Badge className="bg-purple-600/80 text-white text-xs">
                          ⭐ {item.rating}
                        </Badge>
                      </div>
                      <div className="absolute top-2 left-2">
                        <Badge variant="outline" className="bg-black/60 text-white border-white/20 text-xs">
                          {item.status}
                        </Badge>
                      </div>
                    </div>
                    <CardContent className="p-3">
                      <h3 className="font-semibold text-sm text-white mb-1 group-hover:text-purple-400 transition-colors truncate">
                        {item.title}
                      </h3>
                      <p className="text-xs text-secondary mb-2">
                        {item.year} | ⭐ {item.rating} | {item.episodes} eps
                      </p>
                      <div className="flex gap-1 mt-2">
                        <Button 
                          size="sm" 
                          variant="outline"
                          className="flex-1 border-purple-500/30 hover:bg-purple-600/20 text-white text-xs py-1 px-2"
                          data-testid={`watch-${item.id}`}
                        >
                          <Play className="h-3 w-3 mr-1" />
                          Watch
                        </Button>
                        <Button 
                          size="sm" 
                          onClick={() => handleDownload(item)}
                          className="flex-1 gradient-btn text-xs py-1 px-2"
                          data-testid={`download-${item.id}`}
                        >
                          <Download className="h-3 w-3 mr-1" />
                          Download
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* Chat Section */}
        {activeTab === "chat" && (
          <div className="space-y-6">
            <div className="text-center space-y-4">
              <h2 className="text-3xl font-bold text-white flex items-center justify-center gap-2">
                <MessageCircle className="h-8 w-8 text-purple-400" />
                Community Chat
              </h2>
              <p className="text-gray-300 max-w-2xl mx-auto">
                Join our real-time community discussions and interact with AI chatbots. Share your thoughts, get recommendations, and connect with fellow anime fans.
              </p>
            </div>
            <EnhancedChatRoom />
          </div>
        )}

        {/* Trending Section */}
        {activeTab === "trending" && (
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-white flex items-center gap-2">
              <TrendingUp className="h-8 w-8 text-purple-400" />
              Trending Anime
            </h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {trending.map((item, index) => (
                <Card key={item.id} className="bg-black/20 backdrop-blur-md border-purple-500/20 hover:border-purple-400/40 transition-colors group" data-testid={`trending-card-${item.id}`}>
                  <div className="relative">
                    <img 
                      src={item.imageUrl} 
                      alt={item.title}
                      className="w-full h-64 object-cover rounded-t-lg"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent rounded-t-lg" />
                    <div className="absolute top-4 left-4">
                      <Badge className="bg-gradient-to-r from-purple-600 to-pink-600 text-white text-lg px-3 py-1">
                        #{index + 1}
                      </Badge>
                    </div>
                    <div className="absolute top-4 right-4">
                      <Badge className="bg-black/60 text-white border-white/20">
                        ⭐ {item.rating}
                      </Badge>
                    </div>
                    <div className="absolute bottom-4 left-4 right-4">
                      <h3 className="text-xl font-bold text-white mb-2">{item.title}</h3>
                      <p className="text-gray-300 text-sm mb-3 line-clamp-2">
                        {item.description}
                      </p>
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-4 text-sm text-gray-400">
                        <span>{item.genre}</span>
                        <span>•</span>
                        <span>{item.year}</span>
                        <span>•</span>
                        <span>{item.episodes} eps</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        className="flex-1 border-purple-500/30 hover:bg-purple-600/20 text-white"
                        data-testid={`trending-watch-${item.id}`}
                      >
                        <Play className="h-4 w-4 mr-2" />
                        Watch Now
                      </Button>
                      <Button 
                        size="sm" 
                        onClick={() => handleDownload(item)}
                        className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                        data-testid={`trending-download-${item.id}`}
                      >
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="bg-black/30 backdrop-blur-md border-t border-purple-500/20 mt-16">
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <div className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent mb-4">
                StreamMe Anime
              </div>
              <p className="text-gray-400 text-sm">
                Your ultimate destination for anime streaming, downloads, and community discussions.
              </p>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Features</h3>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li>• HD Streaming & Downloads</li>
                <li>• Real-time Community Chat</li>
                <li>• AI-Powered Recommendations</li>
                <li>• Premium Unlock Codes</li>
              </ul>
            </div>
            <div>
              <h3 className="text-white font-semibold mb-4">Support</h3>
              <div className="space-y-2 text-gray-400 text-sm">
                <p>Contact WhatsApp for unlock code: <span className="text-purple-400">+2348039896597</span></p>
                <p className="text-xs text-gray-500 mt-4">Developed by heisbroken vzn</p>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Episode Selection Modal */}
      <Dialog open={showEpisodeModal} onOpenChange={setShowEpisodeModal}>
        <DialogContent className="bg-black/90 border-purple-500/30 text-white max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Download className="h-5 w-5 text-purple-400" />
              Select Episode - {selectedAnime?.title}
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="text-sm text-gray-400 bg-purple-900/20 p-3 rounded-lg">
              <p className="mb-2">Choose which episode you'd like to download:</p>
              <div className="flex items-center gap-2 text-xs">
                <Star className="h-3 w-3 text-yellow-400" />
                <span>Rating: {selectedAnime?.rating}</span>
                <span>•</span>
                <span>Total Episodes: {selectedAnime?.episodes}</span>
              </div>
            </div>
            
            <ScrollArea className="h-64 w-full">
              <div className="grid grid-cols-2 gap-2">
                {selectedAnime && Array.from({ length: selectedAnime.episodes }, (_, i) => i + 1).map((episodeNum) => (
                  <Button
                    key={episodeNum}
                    onClick={() => handleEpisodeDownload(episodeNum)}
                    className="bg-purple-900/30 hover:bg-purple-600/50 border border-purple-500/30 text-white justify-between"
                  >
                    <span>Episode {episodeNum}</span>
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                ))}
              </div>
            </ScrollArea>
            
            <div className="flex gap-2">
              <Button
                onClick={() => {
                  if (selectedAnime) {
                    // Download all episodes
                    toast({
                      title: "Batch Download Started",
                      description: `Downloading all ${selectedAnime.episodes} episodes of ${selectedAnime.title}`,
                    });
                    window.open(`${selectedAnime.downloadUrl}?episode=all`, '_blank');
                    setShowEpisodeModal(false);
                    setSelectedAnime(null);
                  }
                }}
                className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              >
                <Download className="h-4 w-4 mr-2" />
                Download All
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setShowEpisodeModal(false);
                  setSelectedAnime(null);
                }}
                className="border-gray-600 text-gray-300 hover:bg-gray-800"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}