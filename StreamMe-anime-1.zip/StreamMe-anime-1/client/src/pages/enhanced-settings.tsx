import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import NavigationHeader from "@/components/navigation-header";
import { Settings, User, Bell, Shield, Palette, Code, Crown, ArrowLeft, Moon, Sun, Monitor, Volume2, Globe, Database, Download, Eye, Trash2, Languages, Smartphone, Mail, MessageSquare, Film, Music, Headphones, Wifi, Lock, LogOut } from "lucide-react";

export default function EnhancedSettingsPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [unlockCode, setUnlockCode] = useState("");
  const [isUnlockDialogOpen, setIsUnlockDialogOpen] = useState(false);
  const { user, token, verifyUnlockCode, logout } = useAuth();
  const { toast } = useToast();
  const [location, setLocation] = useLocation();
  
  // Enhanced settings state
  const [settings, setSettings] = useState({
    theme: 'dark',
    accentColor: 'purple',
    language: 'en',
    autoTheme: false,
    fontSize: 16,
    reducedMotion: false,
    compactMode: false,
    highContrast: false,
    animationsEnabled: true,
    notifications: {
      push: true,
      email: true,
      sound: true,
      chatMentions: true,
      newAnime: true,
      downloads: false,
      weeklyDigest: true,
      promotions: false
    },
    privacy: {
      showOnlineStatus: true,
      allowDirectMessages: true,
      showWatchHistory: false,
      shareStats: true,
      allowAnalytics: true,
      hideProfile: false
    },
    playback: {
      autoplay: true,
      quality: 'auto',
      volume: 80,
      subtitles: true,
      skipIntro: false,
      autoSkipAds: true,
      continuousPlay: true,
      rememberPosition: true
    },
    downloads: {
      quality: '720p',
      location: 'default',
      deleteAfter: 'never',
      limitSpeed: false,
      maxConcurrent: 3,
      wifiOnly: true
    },
    chat: {
      showTyping: true,
      readReceipts: true,
      compactMode: false,
      showTimestamps: true,
      allowGifs: true,
      soundEffects: true
    }
  });

  // Redirect if not logged in
  if (!user) {
    setLocation("/auth");
    return null;
  }

  const updateSetting = (category: string, key: string, value: any) => {
    setSettings(prev => {
      const categorySettings = prev[category as keyof typeof prev];
      if (typeof categorySettings === 'object' && categorySettings !== null) {
        return {
          ...prev,
          [category]: {
            ...categorySettings,
            [key]: value
          }
        };
      }
      return prev;
    });
    
    // Save to localStorage
    const savedSettings = JSON.parse(localStorage.getItem('animeSettings') || '{}');
    savedSettings[category] = { ...savedSettings[category], [key]: value };
    localStorage.setItem('animeSettings', JSON.stringify(savedSettings));
    
    toast({
      title: "Settings Updated",
      description: "Your preferences have been saved.",
    });
  };

  const updateTopLevelSetting = (key: string, value: any) => {
    setSettings(prev => ({ ...prev, [key]: value }));
    
    const savedSettings = JSON.parse(localStorage.getItem('animeSettings') || '{}');
    savedSettings[key] = value;
    localStorage.setItem('animeSettings', JSON.stringify(savedSettings));
    
    toast({
      title: "Settings Updated",
      description: "Your preferences have been saved.",
    });
  };

  const handleProfileUpdate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const username = formData.get("username") as string;
    const email = formData.get("email") as string;

    try {
      const response = await fetch("/api/auth/update-profile", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ username, email }),
      });

      if (response.ok) {
        toast({
          title: "Profile Updated",
          description: "Your profile has been updated successfully.",
        });
      } else {
        throw new Error("Failed to update profile");
      }
    } catch (error) {
      toast({
        title: "Update Failed",
        description: error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUnlockCode = async () => {
    try {
      await verifyUnlockCode(unlockCode);
      setIsUnlockDialogOpen(false);
      setUnlockCode("");
      toast({
        title: "Success!",
        description: "Premium features unlocked! You now have unlimited AI trials.",
      });
    } catch (error) {
      toast({
        title: "Invalid Code",
        description: error instanceof Error ? error.message : "Please check your unlock code.",
        variant: "destructive",
      });
    }
  };

  const handleLogout = () => {
    logout();
    toast({
      title: "Logged Out",
      description: "You have been logged out successfully.",
    });
    setLocation("/auth");
  };

  const resetSettings = () => {
    localStorage.removeItem('animeSettings');
    window.location.reload();
  };

  const exportSettings = () => {
    const dataStr = JSON.stringify(settings, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'anime-settings.json';
    link.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <NavigationHeader title="Enhanced Settings" />
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-600/20 rounded-lg">
              <Settings className="h-6 w-6 text-purple-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Enhanced Settings</h1>
              <p className="text-gray-300">Customize your anime streaming experience</p>
            </div>
          </div>
        </div>

        <div className="max-w-6xl mx-auto">
          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="grid w-full grid-cols-6 bg-black/20 backdrop-blur-md">
              <TabsTrigger value="profile" className="data-[state=active]:bg-purple-600">
                <User className="h-4 w-4 mr-2" />
                Profile
              </TabsTrigger>
              <TabsTrigger value="appearance" className="data-[state=active]:bg-purple-600">
                <Palette className="h-4 w-4 mr-2" />
                Appearance
              </TabsTrigger>
              <TabsTrigger value="notifications" className="data-[state=active]:bg-purple-600">
                <Bell className="h-4 w-4 mr-2" />
                Notifications
              </TabsTrigger>
              <TabsTrigger value="playback" className="data-[state=active]:bg-purple-600">
                <Volume2 className="h-4 w-4 mr-2" />
                Playback
              </TabsTrigger>
              <TabsTrigger value="premium" className="data-[state=active]:bg-purple-600">
                <Crown className="h-4 w-4 mr-2" />
                Premium
              </TabsTrigger>
              <TabsTrigger value="advanced" className="data-[state=active]:bg-purple-600">
                <Database className="h-4 w-4 mr-2" />
                Advanced
              </TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile" className="space-y-6">
              <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <User className="h-5 w-5" />
                    Profile Information
                  </CardTitle>
                  <CardDescription>Update your personal information and preferences</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <form onSubmit={handleProfileUpdate} className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="username" className="text-white">Username</Label>
                        <Input
                          id="username"
                          name="username"
                          defaultValue={user?.username}
                          className="bg-black/30 border-purple-500/30 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-white">Email</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          defaultValue={user?.email}
                          className="bg-black/30 border-purple-500/30 text-white"
                        />
                      </div>
                    </div>
                    <Button type="submit" disabled={isLoading} className="bg-purple-600 hover:bg-purple-700">
                      {isLoading ? "Updating..." : "Update Profile"}
                    </Button>
                  </form>

                  <Separator className="bg-purple-500/20" />

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Account Status</h3>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Premium Access</span>
                      <Badge className={user?.chatAccess ? "bg-green-600" : "bg-gray-600"}>
                        {user?.chatAccess ? "Active" : "Not Active"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Member Since</span>
                      <span className="text-white">January 2025</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Appearance Tab */}
            <TabsContent value="appearance" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Palette className="h-5 w-5" />
                      Theme Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <Label className="text-white">Theme Mode</Label>
                      <Select value={settings.theme} onValueChange={(value) => updateTopLevelSetting('theme', value)}>
                        <SelectTrigger className="bg-black/30 border-purple-500/30 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="light">
                            <div className="flex items-center gap-2">
                              <Sun className="h-4 w-4" />
                              Light
                            </div>
                          </SelectItem>
                          <SelectItem value="dark">
                            <div className="flex items-center gap-2">
                              <Moon className="h-4 w-4" />
                              Dark
                            </div>
                          </SelectItem>
                          <SelectItem value="auto">
                            <div className="flex items-center gap-2">
                              <Monitor className="h-4 w-4" />
                              Auto
                            </div>
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-3">
                      <Label className="text-white">Accent Color</Label>
                      <div className="grid grid-cols-4 gap-3">
                        {[
                          { color: 'purple', hex: '#9333ea' },
                          { color: 'blue', hex: '#2563eb' },
                          { color: 'green', hex: '#16a34a' },
                          { color: 'red', hex: '#dc2626' },
                          { color: 'orange', hex: '#ea580c' },
                          { color: 'pink', hex: '#db2777' },
                          { color: 'indigo', hex: '#4f46e5' },
                          { color: 'teal', hex: '#0d9488' }
                        ].map(({ color, hex }) => (
                          <button
                            key={color}
                            onClick={() => updateTopLevelSetting('accentColor', color)}
                            className={`w-full h-10 rounded-lg border-2 transition-all hover:scale-105 ${
                              settings.accentColor === color ? 'border-white ring-2 ring-white/30' : 'border-gray-600'
                            }`}
                            style={{ backgroundColor: hex }}
                            title={color.charAt(0).toUpperCase() + color.slice(1)}
                          >
                            {settings.accentColor === color && (
                              <div className="text-white text-xs font-bold">✓</div>
                            )}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="space-y-3">
                      <Label className="text-white">Font Size: {settings.fontSize}px</Label>
                      <Slider
                        value={[settings.fontSize]}
                        onValueChange={([value]) => updateTopLevelSetting('fontSize', value)}
                        min={12}
                        max={20}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label className="text-white">Reduce Motion</Label>
                      <Switch
                        checked={settings.reducedMotion}
                        onCheckedChange={(checked) => updateTopLevelSetting('reducedMotion', checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label className="text-white">Compact Mode</Label>
                      <Switch
                        checked={settings.compactMode}
                        onCheckedChange={(checked) => updateTopLevelSetting('compactMode', checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label className="text-white">High Contrast</Label>
                      <Switch
                        checked={settings.highContrast}
                        onCheckedChange={(checked) => updateTopLevelSetting('highContrast', checked)}
                      />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label className="text-white">Animations Enabled</Label>
                      <Switch
                        checked={settings.animationsEnabled}
                        onCheckedChange={(checked) => updateTopLevelSetting('animationsEnabled', checked)}
                      />
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Globe className="h-5 w-5" />
                      Language & Region
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <Label className="text-white">Language</Label>
                      <Select value={settings.language} onValueChange={(value) => updateTopLevelSetting('language', value)}>
                        <SelectTrigger className="bg-black/30 border-purple-500/30 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="en">English</SelectItem>
                          <SelectItem value="es">Español</SelectItem>
                          <SelectItem value="fr">Français</SelectItem>
                          <SelectItem value="de">Deutsch</SelectItem>
                          <SelectItem value="ja">日本語</SelectItem>
                          <SelectItem value="ko">한국어</SelectItem>
                          <SelectItem value="zh">中文</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Smartphone className="h-5 w-5" />
                      Push Notifications
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {Object.entries({
                      push: "Push Notifications",
                      sound: "Sound Effects",
                      chatMentions: "Chat Mentions",
                      newAnime: "New Anime Releases",
                      downloads: "Download Complete",
                      weeklyDigest: "Weekly Digest",
                    }).map(([key, label]) => (
                      <div key={key} className="flex items-center justify-between">
                        <Label className="text-white">{label}</Label>
                        <Switch
                          checked={Boolean(settings.notifications[key as keyof typeof settings.notifications])}
                          onCheckedChange={(checked) => updateSetting('notifications', key, checked)}
                        />
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Mail className="h-5 w-5" />
                      Email Notifications
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {Object.entries({
                      email: "Email Notifications",
                      promotions: "Promotional Emails",
                    }).map(([key, label]) => (
                      <div key={key} className="flex items-center justify-between">
                        <Label className="text-white">{label}</Label>
                        <Switch
                          checked={Boolean(settings.notifications[key as keyof typeof settings.notifications])}
                          onCheckedChange={(checked) => updateSetting('notifications', key, checked)}
                        />
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Playback Tab */}
            <TabsContent value="playback" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Film className="h-5 w-5" />
                      Video Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <Label className="text-white">Default Quality</Label>
                      <Select value={settings.playback.quality} onValueChange={(value) => updateSetting('playback', 'quality', value)}>
                        <SelectTrigger className="bg-black/30 border-purple-500/30 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="auto">Auto</SelectItem>
                          <SelectItem value="1080p">1080p</SelectItem>
                          <SelectItem value="720p">720p</SelectItem>
                          <SelectItem value="480p">480p</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-3">
                      <Label className="text-white">Volume: {settings.playback.volume}%</Label>
                      <Slider
                        value={[settings.playback.volume]}
                        onValueChange={([value]) => updateSetting('playback', 'volume', value)}
                        min={0}
                        max={100}
                        step={5}
                        className="w-full"
                      />
                    </div>

                    {Object.entries({
                      autoplay: "Autoplay",
                      subtitles: "Enable Subtitles",
                      skipIntro: "Skip Intro",
                      continuousPlay: "Continuous Play",
                      rememberPosition: "Remember Position",
                    }).map(([key, label]) => (
                      <div key={key} className="flex items-center justify-between">
                        <Label className="text-white">{label}</Label>
                        <Switch
                          checked={Boolean(settings.playback[key as keyof typeof settings.playback])}
                          onCheckedChange={(checked) => updateSetting('playback', key, checked)}
                        />
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Download className="h-5 w-5" />
                      Download Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <Label className="text-white">Download Quality</Label>
                      <Select value={settings.downloads.quality} onValueChange={(value) => updateSetting('downloads', 'quality', value)}>
                        <SelectTrigger className="bg-black/30 border-purple-500/30 text-white">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1080p">1080p</SelectItem>
                          <SelectItem value="720p">720p</SelectItem>
                          <SelectItem value="480p">480p</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div className="space-y-3">
                      <Label className="text-white">Max Concurrent Downloads: {settings.downloads.maxConcurrent}</Label>
                      <Slider
                        value={[settings.downloads.maxConcurrent]}
                        onValueChange={([value]) => updateSetting('downloads', 'maxConcurrent', value)}
                        min={1}
                        max={5}
                        step={1}
                        className="w-full"
                      />
                    </div>

                    {Object.entries({
                      wifiOnly: "WiFi Only",
                      limitSpeed: "Limit Speed",
                    }).map(([key, label]) => (
                      <div key={key} className="flex items-center justify-between">
                        <Label className="text-white">{label}</Label>
                        <Switch
                          checked={Boolean(settings.downloads[key as keyof typeof settings.downloads])}
                          onCheckedChange={(checked) => updateSetting('downloads', key, checked)}
                        />
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Premium Tab */}
            <TabsContent value="premium" className="space-y-6">
              <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Crown className="h-5 w-5" />
                    Premium Features
                  </CardTitle>
                  <CardDescription>
                    {user?.chatAccess ? "You have premium access!" : "Unlock premium features with a code"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {!user?.chatAccess ? (
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-white">Unlock Premium</h3>
                      <ul className="space-y-2 text-gray-300">
                        <li>• Unlimited AI chat trials</li>
                        <li>• Access to exclusive chat rooms</li>
                        <li>• Priority download speeds</li>
                        <li>• Advanced customization options</li>
                      </ul>
                      
                      <Dialog open={isUnlockDialogOpen} onOpenChange={setIsUnlockDialogOpen}>
                        <DialogTrigger asChild>
                          <Button className="bg-gradient-to-r from-purple-600 to-pink-600">
                            <Code className="mr-2 h-4 w-4" />
                            Enter Unlock Code
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-black/90 border-purple-500/20">
                          <DialogHeader>
                            <DialogTitle className="text-white">Enter Unlock Code</DialogTitle>
                            <DialogDescription className="text-gray-300">
                              Enter your unlock code to gain chat access. Contact WhatsApp +2348039896597 to get your code.
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <Input
                              placeholder="Enter unlock code"
                              value={unlockCode}
                              onChange={(e) => setUnlockCode(e.target.value)}
                              className="bg-black/30 border-purple-500/30 text-white"
                            />
                            <Button onClick={handleUnlockCode} className="w-full bg-gradient-to-r from-purple-600 to-pink-600">
                              Verify Code
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      <div className="flex items-center gap-2">
                        <Crown className="h-6 w-6 text-yellow-500" />
                        <span className="text-xl font-bold text-white">Premium Active</span>
                        <Badge className="bg-green-600">Premium</Badge>
                      </div>
                      <p className="text-gray-300">You have access to all premium features!</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Advanced Tab */}
            <TabsContent value="advanced" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Database className="h-5 w-5" />
                      Data & Privacy
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {Object.entries({
                      showOnlineStatus: "Show Online Status",
                      allowDirectMessages: "Allow Direct Messages",
                      shareStats: "Share Statistics",
                      allowAnalytics: "Allow Analytics",
                    }).map(([key, label]) => (
                      <div key={key} className="flex items-center justify-between">
                        <Label className="text-white">{label}</Label>
                        <Switch
                          checked={Boolean(settings.privacy[key as keyof typeof settings.privacy])}
                          onCheckedChange={(checked) => updateSetting('privacy', key, checked)}
                        />
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardHeader>
                    <CardTitle className="text-white flex items-center gap-2">
                      <Settings className="h-5 w-5" />
                      System Settings
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <Button
                      onClick={exportSettings}
                      variant="outline"
                      className="w-full border-purple-500/30 text-white hover:bg-purple-600"
                    >
                      <Download className="mr-2 h-4 w-4" />
                      Export Settings
                    </Button>
                    
                    <Button
                      onClick={resetSettings}
                      variant="outline"
                      className="w-full border-red-500/30 text-red-400 hover:bg-red-600 hover:text-white"
                    >
                      <Trash2 className="mr-2 h-4 w-4" />
                      Reset All Settings
                    </Button>
                    
                    <Separator className="bg-purple-500/20" />
                    
                    <Button
                      onClick={handleLogout}
                      variant="outline"
                      className="w-full border-red-500/30 text-red-400 hover:bg-red-600 hover:text-white"
                    >
                      <LogOut className="mr-2 h-4 w-4" />
                      Logout
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}