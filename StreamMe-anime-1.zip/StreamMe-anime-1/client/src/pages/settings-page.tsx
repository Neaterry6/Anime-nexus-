import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import NavigationHeader from "@/components/navigation-header";
import { Settings, User, Bell, Shield, Palette, Code, Crown, ArrowLeft, Moon, Sun, Monitor, Volume2, Globe, Database, Download, Eye, Trash2, Languages } from "lucide-react";

export default function SettingsPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [unlockCode, setUnlockCode] = useState("");
  const [isUnlockDialogOpen, setIsUnlockDialogOpen] = useState(false);
  const { user, token, verifyUnlockCode, logout } = useAuth();
  const { toast } = useToast();
  const [location, setLocation] = useLocation();
  
  // Settings state
  const [settings, setSettings] = useState({
    theme: 'dark',
    language: 'en',
    notifications: {
      push: true,
      email: true,
      sound: true,
      chatMentions: true,
      newAnime: true,
      downloads: false
    },
    privacy: {
      showOnlineStatus: true,
      allowDirectMessages: true,
      showWatchHistory: false,
      shareStats: true
    },
    playback: {
      autoplay: true,
      quality: 'auto',
      volume: 80,
      subtitles: true,
      skipIntro: false
    },
    downloads: {
      quality: '720p',
      location: 'default',
      deleteAfter: 'never',
      limitSpeed: false
    }
  });

  // Redirect if not logged in
  if (!user) {
    setLocation("/auth");
    return null;
  }

  const handleProfileUpdate = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const username = formData.get("username") as string;
    const email = formData.get("email") as string;

    try {
      const response = await fetch("/api/auth/update-profile", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ username, email }),
      });

      if (response.ok) {
        toast({
          title: "Profile Updated",
          description: "Your profile has been updated successfully.",
        });
      } else {
        throw new Error("Failed to update profile");
      }
    } catch (error) {
      toast({
        title: "Update Failed",
        description: error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handlePasswordChange = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const currentPassword = formData.get("currentPassword") as string;
    const newPassword = formData.get("newPassword") as string;
    const confirmPassword = formData.get("confirmPassword") as string;

    if (newPassword !== confirmPassword) {
      toast({
        title: "Password Mismatch",
        description: "New passwords do not match.",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }

    try {
      const response = await fetch("/api/auth/change-password", {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      });

      if (response.ok) {
        toast({
          title: "Password Changed",
          description: "Your password has been updated successfully.",
        });
        (e.target as HTMLFormElement).reset();
      } else {
        throw new Error("Failed to change password");
      }
    } catch (error) {
      toast({
        title: "Password Change Failed",
        description: error instanceof Error ? error.message : "Please check your current password.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleUnlockCode = async () => {
    try {
      await verifyUnlockCode(unlockCode);
      setIsUnlockDialogOpen(false);
      setUnlockCode("");
      toast({
        title: "Success!",
        description: "Premium features unlocked! You now have unlimited AI trials.",
      });
    } catch (error) {
      toast({
        title: "Invalid Code",
        description: error instanceof Error ? error.message : "Please check your unlock code.",
        variant: "destructive",
      });
    }
  };

  const handleLogout = () => {
    logout();
    toast({
      title: "Logged Out",
      description: "You have been logged out successfully.",
    });
    setLocation("/auth");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <NavigationHeader title="Settings" />
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-purple-600/20 rounded-lg">
              <Settings className="h-6 w-6 text-purple-400" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-white">Settings</h1>
              <p className="text-gray-300">Manage your account and preferences</p>
            </div>
          </div>
        </div>

        <div className="max-w-4xl mx-auto">
          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4 bg-black/20 backdrop-blur-md">
              <TabsTrigger value="profile" className="data-[state=active]:bg-purple-600">
                <User className="h-4 w-4 mr-2" />
                Profile
              </TabsTrigger>
              <TabsTrigger value="premium" className="data-[state=active]:bg-purple-600">
                <Crown className="h-4 w-4 mr-2" />
                Premium
              </TabsTrigger>
              <TabsTrigger value="notifications" className="data-[state=active]:bg-purple-600">
                <Bell className="h-4 w-4 mr-2" />
                Notifications
              </TabsTrigger>
              <TabsTrigger value="security" className="data-[state=active]:bg-purple-600">
                <Shield className="h-4 w-4 mr-2" />
                Security
              </TabsTrigger>
            </TabsList>

            {/* Profile Tab */}
            <TabsContent value="profile" className="space-y-6">
              <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Profile Information</CardTitle>
                  <CardDescription className="text-gray-300">
                    Update your personal information and account details.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <form onSubmit={handleProfileUpdate} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="username" className="text-gray-200">Username</Label>
                        <Input
                          id="username"
                          name="username"
                          defaultValue={user.username}
                          className="bg-black/30 border-purple-500/30 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="email" className="text-gray-200">Email</Label>
                        <Input
                          id="email"
                          name="email"
                          type="email"
                          defaultValue={user.email}
                          className="bg-black/30 border-purple-500/30 text-white"
                        />
                      </div>
                    </div>
                    <Button 
                      type="submit" 
                      disabled={isLoading}
                      className="bg-gradient-to-r from-purple-600 to-pink-600"
                    >
                      {isLoading ? "Updating..." : "Update Profile"}
                    </Button>
                  </form>

                  <Separator className="bg-purple-500/20" />

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Account Status</h3>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
                        <div className="flex items-center justify-between">
                          <span className="text-gray-300">Chat Access</span>
                          <Badge variant={user.chatAccess ? "default" : "destructive"}>
                            {user.chatAccess ? "Enabled" : "Disabled"}
                          </Badge>
                        </div>
                      </div>
                      <div className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
                        <div className="flex items-center justify-between">
                          <span className="text-gray-300">AI Trials</span>
                          <Badge variant="outline" className="border-purple-500/30 text-purple-300">
                            {user.aiTrialsLeft || 5}
                          </Badge>
                        </div>
                      </div>
                      <div className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
                        <div className="flex items-center justify-between">
                          <span className="text-gray-300">Member Since</span>
                          <span className="text-sm text-gray-400">
                            {new Date((user as any).createdAt || new Date()).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Premium Tab */}
            <TabsContent value="premium" className="space-y-6">
              <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Crown className="h-5 w-5 text-yellow-400" />
                    Premium Features
                  </CardTitle>
                  <CardDescription className="text-gray-300">
                    Unlock premium features and unlimited AI access.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-white">Current Plan</h3>
                      <div className="bg-black/30 rounded-lg p-4 border border-purple-500/20">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium text-white">
                            {user.chatAccess ? "Premium" : "Free"}
                          </span>
                          <Badge variant={user.chatAccess ? "default" : "secondary"}>
                            {user.chatAccess ? "Active" : "Basic"}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-400">
                          {user.chatAccess 
                            ? "Unlimited AI trials, chat access, premium features"
                            : "Limited features, no chat access"
                          }
                        </p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold text-white">Unlock Premium</h3>
                      <Dialog open={isUnlockDialogOpen} onOpenChange={setIsUnlockDialogOpen}>
                        <DialogTrigger asChild>
                          <Button className="w-full bg-gradient-to-r from-yellow-600 to-orange-600">
                            <Code className="mr-2 h-4 w-4" />
                            Enter Unlock Code
                          </Button>
                        </DialogTrigger>
                        <DialogContent className="bg-black/90 border-purple-500/20">
                          <DialogHeader>
                            <DialogTitle className="text-white">Premium Unlock Code</DialogTitle>
                            <DialogDescription className="text-gray-300">
                              Enter your premium unlock code to access all features.
                            </DialogDescription>
                          </DialogHeader>
                          <div className="space-y-4">
                            <Input
                              placeholder="Enter unlock code (e.g., 0814880)"
                              value={unlockCode}
                              onChange={(e) => setUnlockCode(e.target.value)}
                              className="bg-black/30 border-purple-500/30 text-white"
                            />
                            <Button onClick={handleUnlockCode} className="w-full bg-gradient-to-r from-purple-600 to-pink-600">
                              Unlock Premium
                            </Button>
                          </div>
                        </DialogContent>
                      </Dialog>
                      <p className="text-xs text-gray-500 text-center">
                        Contact WhatsApp: <span className="text-pink-400">+2348039896597</span> for codes
                      </p>
                    </div>
                  </div>

                  <Separator className="bg-purple-500/20" />

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Premium Benefits</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {[
                        "Unlimited AI chat trials",
                        "Real-time chat access",
                        "Priority support",
                        "Early access to new features",
                        "HD anime streaming",
                        "Download permissions",
                        "Custom themes",
                        "Advanced filters"
                      ].map((benefit, index) => (
                        <div key={index} className="flex items-center gap-3 text-gray-300">
                          <div className="w-2 h-2 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full" />
                          {benefit}
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications Tab */}
            <TabsContent value="notifications" className="space-y-6">
              <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Notification Preferences</CardTitle>
                  <CardDescription className="text-gray-300">
                    Choose what notifications you want to receive.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {[
                    { id: "new-episodes", label: "New Episode Releases", description: "Get notified when new episodes are available" },
                    { id: "chat-mentions", label: "Chat Mentions", description: "Notifications when someone mentions you in chat" },
                    { id: "ai-responses", label: "AI Responses", description: "Get notified when AI responds to your messages" },
                    { id: "system-updates", label: "System Updates", description: "Important updates and maintenance notifications" },
                    { id: "promotional", label: "Promotional", description: "Special offers and new feature announcements" }
                  ].map((notification) => (
                    <div key={notification.id} className="flex items-center justify-between p-4 bg-black/30 rounded-lg border border-purple-500/20">
                      <div className="space-y-1">
                        <div className="font-medium text-white">{notification.label}</div>
                        <div className="text-sm text-gray-400">{notification.description}</div>
                      </div>
                      <Switch />
                    </div>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Security Tab */}
            <TabsContent value="security" className="space-y-6">
              <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Security Settings</CardTitle>
                  <CardDescription className="text-gray-300">
                    Manage your account security and password.
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <form onSubmit={handlePasswordChange} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="currentPassword" className="text-gray-200">Current Password</Label>
                      <Input
                        id="currentPassword"
                        name="currentPassword"
                        type="password"
                        required
                        className="bg-black/30 border-purple-500/30 text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="newPassword" className="text-gray-200">New Password</Label>
                      <Input
                        id="newPassword"
                        name="newPassword"
                        type="password"
                        required
                        className="bg-black/30 border-purple-500/30 text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="confirmPassword" className="text-gray-200">Confirm New Password</Label>
                      <Input
                        id="confirmPassword"
                        name="confirmPassword"
                        type="password"
                        required
                        className="bg-black/30 border-purple-500/30 text-white"
                      />
                    </div>
                    <Button 
                      type="submit" 
                      disabled={isLoading}
                      className="bg-gradient-to-r from-purple-600 to-pink-600"
                    >
                      {isLoading ? "Changing..." : "Change Password"}
                    </Button>
                  </form>

                  <Separator className="bg-purple-500/20" />

                  <div className="space-y-4">
                    <h3 className="text-lg font-semibold text-white">Account Actions</h3>
                    <div className="space-y-3">
                      <Button
                        variant="outline"
                        onClick={handleLogout}
                        className="w-full bg-black/30 border-red-500/30 text-red-400 hover:bg-red-500/10"
                      >
                        Logout from All Devices
                      </Button>
                      <Button
                        variant="outline"
                        className="w-full bg-black/30 border-gray-500/30 text-gray-400 hover:bg-gray-500/10"
                        disabled
                      >
                        Delete Account (Coming Soon)
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}