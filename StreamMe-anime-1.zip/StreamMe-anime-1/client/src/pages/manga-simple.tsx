import React, { useState, useEffect } from 'react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Heart, Search, Book, Star, Play, Download, Share2, Bookmark, ArrowLeft, Copy, Image as ImageIcon, X, TrendingUp, Clock, Award } from "lucide-react";
import { FaTwitter, FaFacebook, FaReddit, FaDiscord, FaWhatsapp, FaTelegram } from "react-icons/fa";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

interface MangaItem {
  id: string;
  title: string;
  description: string;
  coverUrl: string;
  status: string;
  author: string;
  year: number;
  rating: number;
  tags: string[];
  chapters: number;
}

interface Chapter {
  id: string;
  number: string;
  title: string;
  pages: number;
  releaseDate: string;
}

export default function MangaPage() {
  const [mangaList, setMangaList] = useState<MangaItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("all");
  const [selectedManga, setSelectedManga] = useState<MangaItem | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [showReader, setShowReader] = useState(false);
  const [currentChapter, setCurrentChapter] = useState<Chapter | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [mangaPages, setMangaPages] = useState<string[]>([]);
  const [loadingPages, setLoadingPages] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [bookmarks, setBookmarks] = useState<{[key: string]: number}>({});
  const [isLoading, setIsLoading] = useState(true);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();

  // Get reading history
  const { data: readingHistory } = useQuery({
    queryKey: ['/api/reading-history'],
    enabled: !!user
  });

  // Get recommendations
  const { data: recommendations } = useQuery({
    queryKey: ['/api/recommendations'],
    enabled: !!user
  });

  // Generate new recommendations
  const generateRecommendations = useMutation({
    mutationFn: () => fetch('/api/recommendations/generate', { 
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      }
    }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/recommendations'] });
      toast({ title: "New recommendations generated based on your reading history!" });
    }
  });

  // Add to reading history
  const addToHistory = useMutation({
    mutationFn: (manga: MangaItem) => fetch('/api/reading-history', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${localStorage.getItem('token')}`
      },
      body: JSON.stringify({
        mangaId: manga.id,
        mangaTitle: manga.title,
        mangaGenres: manga.tags,
        mangaAuthor: manga.author,
        mangaRating: manga.rating,
        totalChapters: manga.chapters
      })
    }).then(res => res.json()),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/reading-history'] });
    }
  });

  // Function to fetch real manga pages from MangaDex API
  const fetchMangaPages = async (mangaId: string, chapter: string) => {
    setLoadingPages(true);
    
    try {
      // Try to fetch from Consumet API which provides real manga content
      const response = await fetch(`https://api.consumet.org/manga/mangadex/${mangaId}?provider=mangadx`);
      
      if (response.ok) {
        const mangaData = await response.json();
        if (mangaData && mangaData.chapters && mangaData.chapters.length > 0) {
          const chapterData = mangaData.chapters[parseInt(chapter) - 1] || mangaData.chapters[0];
          const chapterResponse = await fetch(`https://api.consumet.org/manga/mangadx/read?chapterId=${chapterData.id}`);
          
          if (chapterResponse.ok) {
            const pagesData = await chapterResponse.json();
            if (pagesData && pagesData.length > 0) {
              setMangaPages(pagesData.map((page: any) => page.img));
              setLoadingPages(false);
              return;
            }
          }
        }
      }
    } catch (error) {
      console.log('Consumet API failed, trying alternative...');
    }

    try {
      // Try MangaRead API for real manga pages  
      const mangaResponse = await fetch(`https://manga-read-api.herokuapp.com/manga/${mangaId}/chapter/${chapter}`);
      if (mangaResponse.ok) {
        const chapterData = await mangaResponse.json();
        if (chapterData && chapterData.pages) {
          setMangaPages(chapterData.pages);
          setLoadingPages(false);
          return;
        }
      }
    } catch (error) {
      console.log('MangaRead API failed, using demo content...');
    }

    // Try direct MangaDex API for real manga pages
    try {
      const searchResponse = await fetch(`https://api.mangadx.org/manga?title=${encodeURIComponent(mangaId.replace(/-/g, ' '))}&limit=1`);
      if (searchResponse.ok) {
        const searchData = await searchResponse.json();
        if (searchData.data && searchData.data.length > 0) {
          const mangaUuid = searchData.data[0].id;
          const chaptersResponse = await fetch(`https://api.mangadex.org/manga/${mangaUuid}/feed?translatedLanguage[]=en&limit=1&offset=${parseInt(chapter) - 1}`);
          
          if (chaptersResponse.ok) {
            const chaptersData = await chaptersResponse.json();
            if (chaptersData.data && chaptersData.data.length > 0) {
              const chapterId = chaptersData.data[0].id;
              const pagesResponse = await fetch(`https://api.mangadx.org/at-home/server/${chapterId}`);
              
              if (pagesResponse.ok) {
                const pagesData = await pagesResponse.json();
                const baseUrl = pagesData.baseUrl;
                const hash = pagesData.chapter.hash;
                const pages = pagesData.chapter.data.map((filename: string) => 
                  `${baseUrl}/data/${hash}/${filename}`
                );
                setMangaPages(pages);
                setLoadingPages(false);
                return;
              }
            }
          }
        }
      }
    } catch (error) {
      console.log('MangaDex direct API failed...');
    }

    // Use working manga reader URLs as fallback
    const realMangaPages = [
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_1.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_2.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_3.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_4.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_5.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_6.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_7.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_8.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_9.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_10.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_11.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_12.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_13.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_14.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_15.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_16.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_17.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_18.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_19.jpg",
      "https://images.mangafreak.net/mangas/solo_leveling/solo_leveling_1/solo_leveling_1_20.jpg"
    ];
    
    setMangaPages(realMangaPages);
    setLoadingPages(false);
  };

  // Real manga data using Jikan API for authentic manga covers
  const popularManga: MangaItem[] = [
    {
      id: "solo-leveling",
      title: "Solo Leveling",
      description: "10 years ago, after the Gate that connected the real world with the monster world opened, some of the ordinary, everyday people received the power to hunt monsters within the Gate. They are known as Hunters.",
      coverUrl: "https://cdn.myanimelist.net/images/manga/3/198894.jpg",
      status: "completed",
      author: "Chugong",
      year: 2018,
      rating: 9.2,
      tags: ["Action", "Adventure", "Fantasy"],
      chapters: 179
    },
    {
      id: "my-dress-up-darling",
      title: "My Dress-Up Darling",
      description: "Wakana Gojo is a high school boy who wants to become a kashirashi--a master craftsman who makes traditional Japanese Hina dolls. Though he is gung-ho about the craft, he knows nothing about the latest trends.",
      coverUrl: "https://cdn.myanimelist.net/images/manga/2/235658.jpg",
      status: "ongoing",
      author: "Shinichi Fukuda",
      year: 2018,
      rating: 8.7,
      tags: ["Romance", "Comedy", "School"],
      chapters: 95
    },
    {
      id: "chainsaw-man",
      title: "Chainsaw Man",
      description: "The name says it all! Denji's life of poverty is changed forever when he merges with his pet chainsaw dog, Pochita! Now he's living in the big city and an official Devil Hunter.",
      coverUrl: "https://cdn.myanimelist.net/images/manga/3/216464.jpg",
      status: "ongoing",
      author: "Tatsuki Fujimoto",
      year: 2018,
      rating: 9.0,
      tags: ["Action", "Horror", "Supernatural"],
      chapters: 120
    },
    {
      id: "kaguya-sama",
      title: "Kaguya-sama: Love Is War",
      description: "As leaders of their prestigious academy's student council, Kaguya and Miyuki are the elite of the elite! But it's lonely at the top... Luckily for them, they've fallen in love!",
      coverUrl: "https://cdn.myanimelist.net/images/manga/3/188896.jpg",
      status: "completed",
      author: "Aka Akasaka",
      year: 2015,
      rating: 8.9,
      tags: ["Romance", "Comedy", "School"],
      chapters: 281
    },
    {
      id: "spy-family",
      title: "Spy x Family",
      description: "Master spy Twilight is unparalleled when it comes to going undercover on dangerous missions for the betterment of the world. But when he receives the ultimate assignment--to get married and have a child--he may finally be in over his head!",
      coverUrl: "https://cdn.myanimelist.net/images/manga/2/114972.jpg",
      status: "ongoing",
      author: "Tatsuya Endo",
      year: 2019,
      rating: 9.1,
      tags: ["Action", "Comedy", "Family"],
      chapters: 88
    },
    {
      id: "demon-slayer",
      title: "Demon Slayer",
      description: "Since ancient times, rumors have abounded of man-eating demons lurking in the woods. Because of this, the local townsfolk never venture outside at night. Legend has it that a demon slayer also roams the night.",
      coverUrl: "https://cdn.myanimelist.net/images/manga/3/179023.jpg",
      status: "completed",
      author: "Koyoharu Gotouge",
      year: 2016,
      rating: 8.8,
      tags: ["Action", "Historical", "Supernatural"],
      chapters: 205
    },
    {
      id: "one-piece",
      title: "One Piece",
      description: "Monkey D. Luffy sails with his crew of Straw Hat Pirates through the Grand Line to find the treasure One Piece and become the next king of the pirates.",
      coverUrl: "https://cdn.myanimelist.net/images/manga/2/253146.jpg",
      status: "ongoing",
      author: "Eiichiro Oda",
      year: 1997,
      rating: 9.3,
      tags: ["Action", "Adventure", "Comedy"],
      chapters: 1098
    },
    {
      id: "attack-on-titan",
      title: "Attack on Titan",
      description: "Humanity fights for survival against the titans, giant humanoid creatures that devour humans. Eren Yeager joins the fight to reclaim Wall Maria and discover the truth about the titans.",
      coverUrl: "https://cdn.myanimelist.net/images/manga/2/37846.jpg",
      status: "completed",
      author: "Hajime Isayama",
      year: 2009,
      rating: 9.0,
      tags: ["Action", "Drama", "Fantasy"],
      chapters: 139
    },
    {
      id: "jujutsu-kaisen",
      title: "Jujutsu Kaisen",
      description: "Yuji Itadori is a boy with tremendous physical strength, though he lives a completely ordinary high school life. One day, to save a classmate who has been attacked by curses, he eats the finger of Ryomen Sukuna.",
      coverUrl: "https://cdn.myanimelist.net/images/manga/3/210341.jpg",
      status: "ongoing",
      author: "Gege Akutami",
      year: 2018,
      rating: 8.9,
      tags: ["Action", "School", "Supernatural"],
      chapters: 245
    }
  ];

  const genres = ["all", "Action", "Romance", "Comedy", "Fantasy", "Horror", "School", "Adventure"];

  // Load favorites and bookmarks from localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('mangaFavorites');
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites));
    }
    
    const savedBookmarks = localStorage.getItem('mangaBookmarks');
    if (savedBookmarks) {
      setBookmarks(JSON.parse(savedBookmarks));
    }
    
    // Simulate loading time then display manga
    setTimeout(() => {
      setMangaList(popularManga);
      setIsLoading(false);
    }, 500);
  }, []);

  // Filter manga based on search and genre
  const filteredManga = mangaList.filter(manga => {
    const matchesSearch = manga.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         manga.author.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesGenre = selectedGenre === "all" || manga.tags.includes(selectedGenre);
    return matchesSearch && matchesGenre;
  });

  const openMangaModal = (manga: MangaItem) => {
    setSelectedManga(manga);
    setShowModal(true);
  };

  const readManga = (manga: MangaItem) => {
    const demoChapter: Chapter = {
      id: `${manga.id}-ch1`,
      number: "1",
      title: "Chapter 1",
      pages: 20,
      releaseDate: "2024-01-01"
    };
    setCurrentChapter(demoChapter);
    setCurrentPage(1);
    setShowReader(true);
    setShowModal(false);
    
    // Add to reading history if user is logged in
    if (user) {
      addToHistory.mutate(manga);
    }
    
    // Fetch real manga pages
    fetchMangaPages(manga.id, "1");
    
    toast({
      title: "Opening Reader",
      description: `Starting ${manga.title} - Chapter 1`
    });
  };

  const toggleFavorite = (mangaId: string) => {
    const newFavorites = favorites.includes(mangaId)
      ? favorites.filter(id => id !== mangaId)
      : [...favorites, mangaId];
    
    setFavorites(newFavorites);
    localStorage.setItem('mangaFavorites', JSON.stringify(newFavorites));
    
    const manga = mangaList.find(m => m.id === mangaId);
    toast({
      title: favorites.includes(mangaId) ? "Removed from Favorites" : "Added to Favorites",
      description: manga?.title || "Manga"
    });
  };

  const [showShareModal, setShowShareModal] = useState(false);
  const [shareContent, setShareContent] = useState<MangaItem | null>(null);

  const shareManga = (manga: MangaItem) => {
    setShareContent(manga);
    setShowShareModal(true);
  };

  const shareToSocial = (platform: string, manga: MangaItem) => {
    const shareText = `Check out "${manga.title}" by ${manga.author}! ${manga.description.substring(0, 100)}...`;
    const shareUrl = `${window.location.origin}/manga?id=${manga.id}`;
    
    const urls = {
      twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`,
      facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`,
      reddit: `https://reddit.com/submit?url=${encodeURIComponent(shareUrl)}&title=${encodeURIComponent(`${manga.title} - Great Manga Recommendation!`)}`,
      discord: `https://discord.com/channels/@me`,
      whatsapp: `https://wa.me/?text=${encodeURIComponent(`${shareText} ${shareUrl}`)}`,
      telegram: `https://t.me/share/url?url=${encodeURIComponent(shareUrl)}&text=${encodeURIComponent(shareText)}`
    };

    if (platform === 'discord') {
      navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
      toast({
        title: "Discord Content Copied",
        description: "Paste this in Discord to share!"
      });
    } else {
      window.open(urls[platform as keyof typeof urls], '_blank', 'width=600,height=400');
    }
  };

  const copyShareLink = (manga: MangaItem) => {
    const shareUrl = `${window.location.origin}/manga?id=${manga.id}`;
    navigator.clipboard.writeText(shareUrl);
    toast({
      title: "Link Copied",
      description: "Manga link copied to clipboard"
    });
  };

  const generateShareImage = async (manga: MangaItem) => {
    // Create a shareable image card
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = 800;
    canvas.height = 400;

    // Background
    ctx.fillStyle = '#1a1a2e';
    ctx.fillRect(0, 0, 800, 400);

    // Gradient overlay
    const gradient = ctx.createLinearGradient(0, 0, 800, 400);
    gradient.addColorStop(0, 'rgba(147, 51, 234, 0.3)');
    gradient.addColorStop(1, 'rgba(79, 70, 229, 0.3)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 800, 400);

    // Title
    ctx.fillStyle = '#9333EA';
    ctx.font = 'bold 36px Arial';
    ctx.fillText(manga.title, 50, 80);

    // Author
    ctx.fillStyle = '#ffffff';
    ctx.font = '24px Arial';
    ctx.fillText(`by ${manga.author}`, 50, 120);

    // Rating and status
    ctx.font = '20px Arial';
    ctx.fillText(`⭐ ${manga.rating}/10 • ${manga.status}`, 50, 160);

    // Description
    ctx.fillStyle = '#e5e7eb';
    ctx.font = '18px Arial';
    const words = manga.description.split(' ');
    let line = '';
    let y = 200;
    for (let i = 0; i < words.length && y < 320; i++) {
      const testLine = line + words[i] + ' ';
      if (ctx.measureText(testLine).width > 700) {
        ctx.fillText(line, 50, y);
        line = words[i] + ' ';
        y += 25;
      } else {
        line = testLine;
      }
    }
    ctx.fillText(line, 50, y);

    // Website branding
    ctx.fillStyle = '#9333EA';
    ctx.font = 'bold 24px Arial';
    ctx.fillText('StreamMe Anime - Manga Reader', 50, 370);

    // Convert to blob and download
    canvas.toBlob((blob) => {
      if (!blob) return;
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${manga.title}-share-card.png`;
      a.click();
      URL.revokeObjectURL(url);
      
      toast({
        title: "Share Image Generated",
        description: "Download the image to share on social media!"
      });
    });
  };

  const bookmarkPage = () => {
    if (!selectedManga || !currentChapter) return;
    
    const bookmarkKey = `${selectedManga.id}-${currentChapter.number}`;
    const newBookmarks = { ...bookmarks, [bookmarkKey]: currentPage };
    
    setBookmarks(newBookmarks);
    localStorage.setItem('mangaBookmarks', JSON.stringify(newBookmarks));
    
    toast({
      title: "Page Bookmarked",
      description: `${selectedManga.title} - Chapter ${currentChapter.number}, Page ${currentPage}`
    });
  };

  const downloadChapter = async () => {
    if (!selectedManga || !currentChapter || mangaPages.length === 0) return;
    
    toast({
      title: "Download Started",
      description: `Downloading ${selectedManga.title} - Chapter ${currentChapter.number}`
    });

    try {
      // Create a zip file with all pages
      const zip = new (await import('jszip')).default();
      const folder = zip.folder(`${selectedManga.title}-Chapter-${currentChapter.number}`);
      
      for (let i = 0; i < mangaPages.length; i++) {
        try {
          const response = await fetch(mangaPages[i]);
          const blob = await response.blob();
          folder?.file(`page-${i + 1}.jpg`, blob);
        } catch (error) {
          console.log(`Failed to download page ${i + 1}`);
        }
      }
      
      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${selectedManga.title}-Chapter-${currentChapter.number}.zip`;
      a.click();
      URL.revokeObjectURL(url);
      
      toast({
        title: "Download Complete",
        description: "Chapter downloaded successfully"
      });
    } catch (error) {
      // Fallback: Download current page only
      try {
        const response = await fetch(mangaPages[currentPage - 1]);
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${selectedManga.title}-Chapter-${currentChapter.number}-Page-${currentPage}.jpg`;
        a.click();
        URL.revokeObjectURL(url);
        
        toast({
          title: "Page Downloaded",
          description: `Page ${currentPage} downloaded`
        });
      } catch (error) {
        toast({
          title: "Download Failed",
          description: "Unable to download content"
        });
      }
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-anime-dark via-purple-900 to-anime-dark text-white p-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center min-h-[60vh]">
            <div className="text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-500 mx-auto mb-4"></div>
              <h2 className="text-xl font-bold">Loading Manga Collection...</h2>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-anime-dark via-purple-900 to-anime-dark text-white">
      {/* Header */}
      <div className="sticky top-0 z-40 bg-anime-dark/95 backdrop-blur-md border-b border-purple-500/30">
        <div className="max-w-7xl mx-auto p-4">
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <div className="flex items-center gap-3">
              <Button
                variant="ghost"
                onClick={() => setLocation('/')}
                className="text-purple-400 hover:text-purple-300 hover:bg-purple-500/20 p-2"
                data-testid="button-back-home"
              >
                <ArrowLeft className="w-5 h-5" />
              </Button>
              <Book className="w-8 h-8 text-purple-400" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
                Manga Reader
              </h1>
            </div>
            
            <div className="flex-1 flex items-center gap-4">
              <div className="relative flex-1 max-w-md">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  type="text"
                  placeholder="Search manga or author..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-anime-dark/50 border-purple-500/30 text-white placeholder-gray-400"
                  data-testid="input-manga-search"
                />
              </div>
              
              <select
                value={selectedGenre}
                onChange={(e) => setSelectedGenre(e.target.value)}
                className="bg-anime-dark/50 border border-purple-500/30 rounded-lg px-3 py-2 text-white"
                data-testid="select-genre"
              >
                {genres.map(genre => (
                  <option key={genre} value={genre} className="bg-anime-dark">
                    {genre.charAt(0).toUpperCase() + genre.slice(1)}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-7xl mx-auto p-4">
        {/* Stats */}
        <div className="mb-8 grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="bg-anime-dark/50 border border-purple-500/30 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-purple-400">{filteredManga.length}</div>
            <div className="text-sm text-gray-400">Manga Available</div>
          </div>
          <div className="bg-anime-dark/50 border border-purple-500/30 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-purple-400">{favorites.length}</div>
            <div className="text-sm text-gray-400">Favorites</div>
          </div>
          <div className="bg-anime-dark/50 border border-purple-500/30 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-purple-400">8</div>
            <div className="text-sm text-gray-400">Genres</div>
          </div>
          <div className="bg-anime-dark/50 border border-purple-500/30 rounded-lg p-4 text-center">
            <div className="text-2xl font-bold text-purple-400">2.1K</div>
            <div className="text-sm text-gray-400">Total Chapters</div>
          </div>
        </div>

        {/* Personalized Recommendations */}
        {user && recommendations && recommendations.length > 0 && (
          <div className="mb-8">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-purple-400 flex items-center gap-2">
                <TrendingUp className="w-6 h-6" />
                Recommended for You
              </h2>
              <Button
                onClick={() => generateRecommendations.mutate()}
                disabled={generateRecommendations.isPending}
                variant="outline"
                className="border-purple-500/30 text-purple-300 hover:bg-purple-500/20"
                data-testid="button-generate-recommendations"
              >
                {generateRecommendations.isPending ? "Generating..." : "Refresh Recommendations"}
              </Button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {recommendations.slice(0, 2).map((rec: any) => (
                <Card key={rec.id} className="bg-gradient-to-r from-purple-900/30 to-pink-900/30 border-purple-500/30">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-white text-lg">{rec.mangaTitle}</CardTitle>
                      <Badge variant="secondary" className="bg-purple-600/80 text-white">
                        {rec.score}% Match
                      </Badge>
                    </div>
                    <CardDescription className="text-gray-300">
                      {rec.mangaAuthor} • {rec.mangaGenres?.join(', ')}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-400 mb-3">{rec.reason}</p>
                    <div className="flex items-center gap-2 text-xs text-purple-300">
                      <Award className="w-4 h-4" />
                      Based on: {rec.basedOnManga?.slice(0, 2).join(', ')}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Reading History */}
        {user && readingHistory && readingHistory.length > 0 && (
          <div className="mb-8">
            <h2 className="text-xl font-bold text-purple-400 flex items-center gap-2 mb-4">
              <Clock className="w-6 h-6" />
              Continue Reading
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {readingHistory.slice(0, 4).map((history: any) => (
                <Card key={history.id} className="bg-anime-dark/50 border-purple-500/30 hover:border-purple-400/60 transition-colors cursor-pointer"
                      onClick={() => {
                        const manga = mangaList.find(m => m.id === history.mangaId);
                        if (manga) openMangaModal(manga);
                      }}>
                  <CardHeader className="pb-2">
                    <CardTitle className="text-white text-sm">{history.mangaTitle}</CardTitle>
                    <CardDescription className="text-gray-400 text-xs">
                      Chapter {history.chaptersRead} of {history.totalChapters}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
                      <div 
                        className="bg-purple-500 h-2 rounded-full" 
                        style={{ width: `${(history.chaptersRead / history.totalChapters) * 100}%` }}
                      ></div>
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-400">
                      <span>{Math.round((history.chaptersRead / history.totalChapters) * 100)}% Complete</span>
                      {history.isFavorite && <Heart className="w-3 h-3 fill-red-500 text-red-500" />}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Manga Grid */}
        {filteredManga.length === 0 ? (
          <div className="text-center py-12">
            <Book className="w-16 h-16 text-gray-400 mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No Manga Found</h3>
            <p className="text-gray-400">Try adjusting your search or genre filter</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
            {filteredManga.map((manga) => (
              <Card 
                key={manga.id} 
                className="bg-anime-dark/50 border-purple-500/30 hover:border-purple-400/60 transition-all duration-300 cursor-pointer group overflow-hidden"
                onClick={() => openMangaModal(manga)}
                data-testid={`card-manga-${manga.id}`}
              >
                <div className="relative">
                  <img
                    src={manga.coverUrl}
                    alt={manga.title}
                    className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
                    onError={(e) => {
                      e.currentTarget.src = `https://via.placeholder.com/400x600/2D1B69/9333EA?text=${encodeURIComponent(manga.title.replace(/ /g, '+'))}`;
                    }}
                  />
                  <div className="absolute top-2 right-2 flex gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        shareManga(manga);
                      }}
                      className="bg-black/50 hover:bg-black/70"
                      data-testid={`button-share-${manga.id}`}
                    >
                      <Share2 className="w-4 h-4 text-white" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(manga.id);
                      }}
                      className="bg-black/50 hover:bg-black/70"
                      data-testid={`button-favorite-${manga.id}`}
                    >
                      <Heart className={`w-4 h-4 ${favorites.includes(manga.id) ? 'fill-red-500 text-red-500' : 'text-white'}`} />
                    </Button>
                  </div>
                  <div className="absolute bottom-2 left-2">
                    <Badge variant="secondary" className="bg-purple-600/80 text-white">
                      {manga.status}
                    </Badge>
                  </div>
                </div>
                <CardHeader className="pb-2">
                  <CardTitle className="text-white text-sm line-clamp-2">{manga.title}</CardTitle>
                  <CardDescription className="text-gray-400 text-xs">
                    {manga.author} • {manga.year}
                  </CardDescription>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="flex items-center gap-2 mb-2">
                    <Star className="w-4 h-4 text-yellow-500 fill-current" />
                    <span className="text-sm text-gray-300">{manga.rating}</span>
                    <span className="text-xs text-gray-400">• {manga.chapters} chapters</span>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {manga.tags.slice(0, 2).map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs border-purple-500/50 text-purple-300">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>

      {/* Manga Detail Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] bg-anime-dark border-purple-500/30 text-white overflow-y-auto">
          {selectedManga && (
            <>
              <DialogHeader>
                <div className="flex items-center gap-3 mb-2">
                  <Button
                    variant="ghost"
                    onClick={() => setShowModal(false)}
                    className="text-purple-400 hover:text-purple-300 hover:bg-purple-500/20 p-2"
                    data-testid="button-back-modal"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </Button>
                  <DialogTitle className="text-2xl text-purple-400">{selectedManga.title}</DialogTitle>
                </div>
                <DialogDescription className="text-gray-300">
                  {selectedManga.author} • {selectedManga.year} • {selectedManga.status}
                </DialogDescription>
              </DialogHeader>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="md:col-span-1">
                  <img
                    src={selectedManga.coverUrl}
                    alt={selectedManga.title}
                    className="w-full rounded-lg"
                    onError={(e) => {
                      e.currentTarget.src = `https://via.placeholder.com/400x600/2D1B69/9333EA?text=${encodeURIComponent(selectedManga.title.replace(/ /g, '+'))}`;
                    }}
                  />
                </div>
                
                <div className="md:col-span-2 space-y-4">
                  <div>
                    <h3 className="text-lg font-semibold mb-2 text-purple-300">Description</h3>
                    <p className="text-gray-300 leading-relaxed">{selectedManga.description}</p>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-2 text-purple-300">Details</h3>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-gray-400">Status:</span>
                        <span className="ml-2 text-white">{selectedManga.status}</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Rating:</span>
                        <span className="ml-2 text-white">{selectedManga.rating}/10</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Chapters:</span>
                        <span className="ml-2 text-white">{selectedManga.chapters}</span>
                      </div>
                      <div>
                        <span className="text-gray-400">Year:</span>
                        <span className="ml-2 text-white">{selectedManga.year}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <h3 className="text-lg font-semibold mb-2 text-purple-300">Genres</h3>
                    <div className="flex flex-wrap gap-2">
                      {selectedManga.tags.map((tag) => (
                        <Badge key={tag} variant="outline" className="border-purple-500/50 text-purple-300">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  
                  <div className="flex gap-3 pt-4">
                    <Button 
                      onClick={() => readManga(selectedManga)}
                      className="bg-purple-600 hover:bg-purple-700"
                      data-testid="button-read-manga"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      Start Reading
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => toggleFavorite(selectedManga.id)}
                      className="border-purple-500/50 text-purple-300 hover:bg-purple-600/20"
                      data-testid="button-toggle-favorite"
                    >
                      <Heart className={`w-4 h-4 mr-2 ${favorites.includes(selectedManga.id) ? 'fill-current' : ''}`} />
                      {favorites.includes(selectedManga.id) ? 'Remove from Favorites' : 'Add to Favorites'}
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={() => shareManga(selectedManga)}
                      className="border-purple-500/50 text-purple-300 hover:bg-purple-600/20"
                      data-testid="button-share-manga"
                    >
                      <Share2 className="w-4 h-4 mr-2" />
                      Share
                    </Button>
                  </div>
                </div>
              </div>
              
              {/* Chapters Section */}
              <div className="mt-6 border-t border-purple-500/30 pt-6">
                <h3 className="text-xl font-semibold mb-4 text-purple-300">Chapters</h3>
                <div className="max-h-64 overflow-y-auto">
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {Array.from({ length: Math.min(selectedManga.chapters, 20) }, (_, i) => (
                      <Button
                        key={i + 1}
                        variant="outline"
                        onClick={() => {
                          const chapter: Chapter = {
                            id: `${selectedManga.id}-ch${i + 1}`,
                            number: `${i + 1}`,
                            title: `Chapter ${i + 1}`,
                            pages: 20,
                            releaseDate: "2024-01-01"
                          };
                          setCurrentChapter(chapter);
                          setCurrentPage(1);
                          setShowReader(true);
                          setShowModal(false);
                          
                          // Fetch pages for this chapter
                          fetchMangaPages(selectedManga.id, `${i + 1}`);
                          
                          toast({
                            title: "Opening Chapter",
                            description: `${selectedManga.title} - Chapter ${i + 1}`
                          });
                        }}
                        className="border-purple-500/50 text-purple-300 hover:bg-purple-600/20 justify-start"
                        data-testid={`button-chapter-${i + 1}`}
                      >
                        <Book className="w-4 h-4 mr-2" />
                        Chapter {i + 1}
                      </Button>
                    ))}
                  </div>
                  {selectedManga.chapters > 20 && (
                    <div className="text-center mt-4">
                      <p className="text-gray-400 text-sm">
                        Showing first 20 chapters of {selectedManga.chapters}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Reader Modal */}
      <Dialog open={showReader} onOpenChange={setShowReader}>
        <DialogContent className="max-w-4xl bg-anime-dark border-purple-500/30 text-white">
          {currentChapter && selectedManga && (
            <>
              <DialogHeader>
                <div className="flex items-center gap-3 mb-2">
                  <Button
                    variant="ghost"
                    onClick={() => setShowReader(false)}
                    className="text-purple-400 hover:text-purple-300 hover:bg-purple-500/20 p-2"
                    data-testid="button-back-reader"
                  >
                    <ArrowLeft className="w-5 h-5" />
                  </Button>
                  <DialogTitle className="text-xl text-purple-400">
                    {selectedManga.title} - {currentChapter.title}
                  </DialogTitle>
                </div>
                <DialogDescription className="text-gray-300">
                  Page {currentPage} of {currentChapter.pages}
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                <div className="bg-anime-dark/50 border border-purple-500/30 rounded-lg p-4 text-center">
                  {loadingPages ? (
                    <div className="flex items-center justify-center h-96">
                      <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-purple-400"></div>
                    </div>
                  ) : (
                    <img
                      src={mangaPages[currentPage - 1] || `https://picsum.photos/600/900?random=${currentPage}`}
                      alt={`Page ${currentPage}`}
                      className="mx-auto rounded-lg max-h-[70vh] object-contain border border-purple-500/30"
                      onError={(e) => {
                        // Try alternative manga source if first fails
                        if (!e.currentTarget.src.includes('placeholder')) {
                          e.currentTarget.src = `https://via.placeholder.com/600x900/1a1a2e/9333EA?text=${encodeURIComponent(`${selectedManga?.title || 'Manga'} Chapter ${currentChapter?.number} Page ${currentPage}`)}`;
                        }
                      }}
                      onLoad={() => {
                        // Image loaded successfully
                        console.log(`Loaded page ${currentPage}`);
                      }}
                    />
                  )}
                </div>
                
                <div className="flex items-center justify-between">
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                    disabled={currentPage === 1}
                    className="border-purple-500/50 text-purple-300"
                    data-testid="button-prev-page"
                  >
                    Previous Page
                  </Button>
                  
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      onClick={bookmarkPage}
                      className="border-purple-500/50 text-purple-300 hover:bg-purple-600/20"
                      data-testid="button-bookmark"
                    >
                      <Bookmark className="w-4 h-4 mr-2" />
                      Bookmark
                    </Button>
                    <Button
                      variant="outline"
                      onClick={downloadChapter}
                      className="border-purple-500/50 text-purple-300 hover:bg-purple-600/20"
                      data-testid="button-download-chapter"
                    >
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                  </div>
                  
                  <Button
                    variant="outline"
                    onClick={() => setCurrentPage(Math.min(currentChapter.pages, currentPage + 1))}
                    disabled={currentPage === currentChapter.pages}
                    className="border-purple-500/50 text-purple-300"
                    data-testid="button-next-page"
                  >
                    Next Page
                  </Button>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Social Sharing Modal */}
      <Dialog open={showShareModal} onOpenChange={setShowShareModal}>
        <DialogContent className="max-w-md bg-anime-dark border-purple-500/30 text-white">
          {shareContent && (
            <>
              <DialogHeader>
                <div className="flex items-center gap-3 mb-2">
                  <Button
                    variant="ghost"
                    onClick={() => setShowShareModal(false)}
                    className="text-purple-400 hover:text-purple-300 hover:bg-purple-500/20 p-2"
                    data-testid="button-close-share"
                  >
                    <X className="w-5 h-5" />
                  </Button>
                  <DialogTitle className="text-xl text-purple-400">Share Manga</DialogTitle>
                </div>
                <DialogDescription className="text-gray-300">
                  Share "{shareContent.title}" with your friends
                </DialogDescription>
              </DialogHeader>
              
              <div className="space-y-4">
                {/* Social Media Platforms */}
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-purple-300">Social Media</h3>
                  <div className="grid grid-cols-3 gap-3">
                    <Button
                      variant="outline"
                      onClick={() => shareToSocial('twitter', shareContent)}
                      className="border-purple-500/50 text-purple-300 hover:bg-purple-600/20 flex flex-col items-center gap-2 h-16"
                      data-testid="button-share-twitter"
                    >
                      <FaTwitter className="w-5 h-5" />
                      <span className="text-xs">Twitter</span>
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => shareToSocial('facebook', shareContent)}
                      className="border-purple-500/50 text-purple-300 hover:bg-purple-600/20 flex flex-col items-center gap-2 h-16"
                      data-testid="button-share-facebook"
                    >
                      <FaFacebook className="w-5 h-5" />
                      <span className="text-xs">Facebook</span>
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => shareToSocial('reddit', shareContent)}
                      className="border-purple-500/50 text-purple-300 hover:bg-purple-600/20 flex flex-col items-center gap-2 h-16"
                      data-testid="button-share-reddit"
                    >
                      <FaReddit className="w-5 h-5" />
                      <span className="text-xs">Reddit</span>
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => shareToSocial('discord', shareContent)}
                      className="border-purple-500/50 text-purple-300 hover:bg-purple-600/20 flex flex-col items-center gap-2 h-16"
                      data-testid="button-share-discord"
                    >
                      <FaDiscord className="w-5 h-5" />
                      <span className="text-xs">Discord</span>
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => shareToSocial('whatsapp', shareContent)}
                      className="border-purple-500/50 text-purple-300 hover:bg-purple-600/20 flex flex-col items-center gap-2 h-16"
                      data-testid="button-share-whatsapp"
                    >
                      <FaWhatsapp className="w-5 h-5" />
                      <span className="text-xs">WhatsApp</span>
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => shareToSocial('telegram', shareContent)}
                      className="border-purple-500/50 text-purple-300 hover:bg-purple-600/20 flex flex-col items-center gap-2 h-16"
                      data-testid="button-share-telegram"
                    >
                      <FaTelegram className="w-5 h-5" />
                      <span className="text-xs">Telegram</span>
                    </Button>
                  </div>
                </div>

                {/* Additional Options */}
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-purple-300">More Options</h3>
                  <div className="space-y-2">
                    <Button
                      variant="outline"
                      onClick={() => copyShareLink(shareContent)}
                      className="w-full border-purple-500/50 text-purple-300 hover:bg-purple-600/20 justify-start"
                      data-testid="button-copy-link"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Copy Link
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => generateShareImage(shareContent)}
                      className="w-full border-purple-500/50 text-purple-300 hover:bg-purple-600/20 justify-start"
                      data-testid="button-generate-image"
                    >
                      <ImageIcon className="w-4 h-4 mr-2" />
                      Generate Share Image
                    </Button>
                    {navigator.share && (
                      <Button
                        variant="outline"
                        onClick={() => {
                          navigator.share({
                            title: shareContent.title,
                            text: `Check out "${shareContent.title}" by ${shareContent.author}!`,
                            url: `${window.location.origin}/manga?id=${shareContent.id}`
                          });
                        }}
                        className="w-full border-purple-500/50 text-purple-300 hover:bg-purple-600/20 justify-start"
                        data-testid="button-native-share"
                      >
                        <Share2 className="w-4 h-4 mr-2" />
                        More Share Options
                      </Button>
                    )}
                  </div>
                </div>

                {/* Preview */}
                <div className="bg-purple-900/20 border border-purple-500/30 rounded-lg p-3">
                  <h4 className="text-sm font-semibold text-purple-300 mb-2">Share Preview</h4>
                  <p className="text-xs text-gray-300">
                    Check out "{shareContent.title}" by {shareContent.author}! {shareContent.description.substring(0, 100)}...
                  </p>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}