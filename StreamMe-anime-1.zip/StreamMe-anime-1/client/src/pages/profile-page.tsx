import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLocation } from "wouter";
import NavigationHeader from "@/components/navigation-header";
import { ArrowLeft, User, MessageSquare, Bot, Calendar, Crown, Activity, Download, Heart } from "lucide-react";

interface UserStats {
  totalMessages: number;
  aiInteractions: number;
  favoriteAnime: number;
  downloadsCount: number;
  joinDate: string;
  lastActive: string;
}

export default function ProfilePage() {
  const [userStats, setUserStats] = useState<UserStats | null>(null);
  const { user, token } = useAuth();
  const [location, setLocation] = useLocation();

  // Redirect if not logged in
  if (!user) {
    setLocation("/auth");
    return null;
  }

  useEffect(() => {
    fetchUserStats();
  }, []);

  const fetchUserStats = async () => {
    try {
      const response = await fetch("/api/user/stats", {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.ok) {
        const stats = await response.json();
        setUserStats(stats);
      }
    } catch (error) {
      console.error("Error fetching user stats:", error);
      // Set default stats if API fails
      setUserStats({
        totalMessages: 0,
        aiInteractions: 0,
        favoriteAnime: 0,
        downloadsCount: 0,
        joinDate: (user as any).createdAt?.toISOString() || new Date().toISOString(),
        lastActive: new Date().toISOString()
      });
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const getInitials = (username: string) => {
    return username.slice(0, 2).toUpperCase();
  };

  const achievements = [
    { id: 1, name: "First Message", description: "Sent your first chat message", icon: "💬", unlocked: true },
    { id: 2, name: "AI Explorer", description: "Interacted with AI chatbots", icon: "🤖", unlocked: true },
    { id: 3, name: "Anime Fan", description: "Browsed anime catalog", icon: "🎬", unlocked: true },
    { id: 4, name: "Community Member", description: "Joined the chat community", icon: "👥", unlocked: user.chatAccess },
    { id: 5, name: "Premium User", description: "Unlocked premium features", icon: "👑", unlocked: user.chatAccess },
    { id: 6, name: "Active Chatter", description: "Send 100+ messages", icon: "📢", unlocked: false },
    { id: 7, name: "AI Master", description: "100+ AI interactions", icon: "🧠", unlocked: false },
    { id: 8, name: "Otaku", description: "Added 50+ anime to favorites", icon: "❤️", unlocked: false }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <NavigationHeader title="Profile" />
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="flex items-center gap-3">
            <Avatar className="h-12 w-12 border-2 border-purple-500">
              <AvatarImage src={`https://api.dicebear.com/7.x/adventurer/svg?seed=${user.username}`} />
              <AvatarFallback className="bg-purple-600 text-white">
                {getInitials(user.username)}
              </AvatarFallback>
            </Avatar>
            <div>
              <h1 className="text-3xl font-bold text-white">{user.username}</h1>
              <p className="text-gray-300 flex items-center gap-2">
                <span>{user.email}</span>
                {user.chatAccess && (
                  <Badge className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
                    <Crown className="h-3 w-3 mr-1" />
                    Premium
                  </Badge>
                )}
              </p>
            </div>
          </div>
        </div>

        <div className="max-w-6xl mx-auto">
          <Tabs defaultValue="overview" className="space-y-6">
            <TabsList className="grid w-full grid-cols-3 bg-black/20 backdrop-blur-md">
              <TabsTrigger value="overview" className="data-[state=active]:bg-purple-600">
                <User className="h-4 w-4 mr-2" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="activity" className="data-[state=active]:bg-purple-600">
                <Activity className="h-4 w-4 mr-2" />
                Activity
              </TabsTrigger>
              <TabsTrigger value="achievements" className="data-[state=active]:bg-purple-600">
                <Crown className="h-4 w-4 mr-2" />
                Achievements
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-blue-600/20 rounded-lg">
                        <MessageSquare className="h-6 w-6 text-blue-400" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Messages Sent</p>
                        <p className="text-2xl font-bold text-white">{userStats?.totalMessages || 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-purple-600/20 rounded-lg">
                        <Bot className="h-6 w-6 text-purple-400" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">AI Interactions</p>
                        <p className="text-2xl font-bold text-white">{userStats?.aiInteractions || 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-pink-600/20 rounded-lg">
                        <Heart className="h-6 w-6 text-pink-400" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Favorite Anime</p>
                        <p className="text-2xl font-bold text-white">{userStats?.favoriteAnime || 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-4">
                      <div className="p-3 bg-green-600/20 rounded-lg">
                        <Download className="h-6 w-6 text-green-400" />
                      </div>
                      <div>
                        <p className="text-sm text-gray-400">Downloads</p>
                        <p className="text-2xl font-bold text-white">{userStats?.downloadsCount || 0}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardHeader>
                    <CardTitle className="text-white">Account Information</CardTitle>
                    <CardDescription className="text-gray-300">
                      Your account details and membership status
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Member Since</span>
                      <span className="text-white">{formatDate((user as any).createdAt?.toISOString() || new Date().toISOString())}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Account Type</span>
                      <Badge variant={user.chatAccess ? "default" : "secondary"}>
                        {user.chatAccess ? "Premium" : "Free"}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">AI Trials Remaining</span>
                      <Badge variant="outline" className="border-purple-500/30 text-purple-300">
                        {user.chatAccess ? "Unlimited" : (user.aiTrialsLeft || 5)}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-300">Chat Access</span>
                      <Badge variant={user.chatAccess ? "default" : "destructive"}>
                        {user.chatAccess ? "Enabled" : "Disabled"}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                  <CardHeader>
                    <CardTitle className="text-white">Quick Actions</CardTitle>
                    <CardDescription className="text-gray-300">
                      Manage your account and preferences
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button 
                      onClick={() => setLocation("/settings")}
                      className="w-full bg-gradient-to-r from-purple-600 to-pink-600"
                    >
                      Account Settings
                    </Button>
                    <Button 
                      onClick={() => setLocation("/#chat")}
                      variant="outline"
                      className="w-full border-blue-500/30 hover:bg-blue-500/10"
                    >
                      Join Chat Room
                    </Button>
                    <Button 
                      onClick={() => setLocation("/#catalog")}
                      variant="outline"
                      className="w-full border-purple-500/30 hover:bg-purple-500/10"
                    >
                      Browse Anime
                    </Button>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            {/* Activity Tab */}
            <TabsContent value="activity" className="space-y-6">
              <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Recent Activity</CardTitle>
                  <CardDescription className="text-gray-300">
                    Your latest interactions and usage statistics
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 p-3 bg-black/30 rounded-lg">
                      <div className="p-2 bg-blue-600/20 rounded">
                        <Calendar className="h-4 w-4 text-blue-400" />
                      </div>
                      <div className="flex-1">
                        <p className="text-white text-sm">Joined StreamMe Anime</p>
                        <p className="text-gray-400 text-xs">{formatDate((user as any).createdAt?.toISOString() || new Date().toISOString())}</p>
                      </div>
                    </div>

                    {user.chatAccess && (
                      <div className="flex items-center gap-3 p-3 bg-black/30 rounded-lg">
                        <div className="p-2 bg-purple-600/20 rounded">
                          <Crown className="h-4 w-4 text-purple-400" />
                        </div>
                        <div className="flex-1">
                          <p className="text-white text-sm">Unlocked Premium Features</p>
                          <p className="text-gray-400 text-xs">Chat access and unlimited AI trials</p>
                        </div>
                      </div>
                    )}

                    <div className="flex items-center gap-3 p-3 bg-black/30 rounded-lg">
                      <div className="p-2 bg-green-600/20 rounded">
                        <Activity className="h-4 w-4 text-green-400" />
                      </div>
                      <div className="flex-1">
                        <p className="text-white text-sm">Last Active</p>
                        <p className="text-gray-400 text-xs">Just now</p>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Achievements Tab */}
            <TabsContent value="achievements" className="space-y-6">
              <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
                <CardHeader>
                  <CardTitle className="text-white">Achievements</CardTitle>
                  <CardDescription className="text-gray-300">
                    Track your progress and unlock new badges
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    {achievements.map((achievement) => (
                      <div
                        key={achievement.id}
                        className={`p-4 rounded-lg border transition-all ${
                          achievement.unlocked
                            ? "bg-gradient-to-br from-purple-900/50 to-pink-900/50 border-purple-500/30"
                            : "bg-black/30 border-gray-700/30 opacity-60"
                        }`}
                      >
                        <div className="text-center space-y-2">
                          <div className="text-3xl">{achievement.icon}</div>
                          <h3 className={`font-semibold ${achievement.unlocked ? "text-white" : "text-gray-500"}`}>
                            {achievement.name}
                          </h3>
                          <p className={`text-xs ${achievement.unlocked ? "text-gray-300" : "text-gray-600"}`}>
                            {achievement.description}
                          </p>
                          {achievement.unlocked && (
                            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white text-xs">
                              Unlocked
                            </Badge>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
}