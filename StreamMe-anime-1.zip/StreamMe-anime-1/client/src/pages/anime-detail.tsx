import { useState, useEffect } from "react";
import { useLocation, useRoute } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { ArrowLeft, Download, Star, Play, Heart, Share2 } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";

interface AnimeDetail {
  title: string;
  image: string;
  releaseSeason?: string;
  rating?: {
    value: string;
    count: string;
  };
  info?: {
    season: string;
    rating: string;
    voters: string;
    credit: string;
    encode: string;
    genre: string[];
  };
  genres?: string[];
  synopsis: string;
  episodes?: {
    title: string;
    link: string;
  }[];
  downloads?: {
    resolution: string;
    links: {
      source: string;
      url: string;
    }[];
  }[];
  recommendations?: string;
}

interface Episode {
  title: string;
  url: string;
  episodeNumber: number;
}

export default function AnimeDetailPage() {
  const [, setLocation] = useLocation();
  const [match, params] = useRoute("/anime/:animeUrl");
  const [animeDetail, setAnimeDetail] = useState<AnimeDetail | null>(null);
  const [episodes, setEpisodes] = useState<Episode[]>([]);
  const [selectedEpisode, setSelectedEpisode] = useState<Episode | null>(null);
  const [episodeDownloads, setEpisodeDownloads] = useState<any>(null);
  const [showDownloadModal, setShowDownloadModal] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isLoadingEpisode, setIsLoadingEpisode] = useState(false);
  
  const { user } = useAuth();
  const { toast } = useToast();

  useEffect(() => {
    if (params?.animeUrl) {
      loadAnimeDetail(decodeURIComponent(params.animeUrl));
    }
  }, [params?.animeUrl]);

  const loadAnimeDetail = async (animeUrl: string) => {
    if (!user) {
      toast({
        title: "Login Required",
        description: "Please log in to view anime details",
        variant: "destructive"
      });
      setLocation("/anime");
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch(`/api/anime/detail?url=${encodeURIComponent(animeUrl)}`);
      if (!response.ok) throw new Error('Failed to fetch details');
      
      const data = await response.json();
      if (data.status && data.result) {
        setAnimeDetail(data.result);
        
        // Use real episode list from API or generate if not available
        if (data.result.episodes && data.result.episodes.length > 0) {
          const episodeList = data.result.episodes.map((ep: any, index: number) => ({
            title: ep.title,
            url: ep.link,
            episodeNumber: index + 1
          }));
          setEpisodes(episodeList);
        } else {
          // Fallback: generate episode list
          const episodeList = Array.from({ length: 12 }, (_, i) => ({
            title: `Episode ${i + 1}`,
            url: animeUrl.replace('/anime/', '/') + `-episode-${i + 1}/`,
            episodeNumber: i + 1
          }));
          setEpisodes(episodeList);
        }
      }
    } catch (error) {
      console.error('Detail fetch error:', error);
      toast({
        title: "Failed to Load Details",
        description: "Unable to load anime details. Please try again.",
        variant: "destructive"
      });
      setLocation("/anime");
    }
    setIsLoading(false);
  };

  const handleEpisodeDownload = async (episode: Episode) => {
    setSelectedEpisode(episode);
    setIsLoadingEpisode(true);
    
    try {
      const response = await fetch(`/api/anime/download-episode?url=${encodeURIComponent(episode.url)}`);
      if (!response.ok) throw new Error('Failed to fetch episode downloads');
      
      const data = await response.json();
      if (data.status && data.result) {
        setEpisodeDownloads(data.result);
        setShowDownloadModal(true);
      }
    } catch (error) {
      console.error('Episode download error:', error);
      toast({
        title: "Failed to Load Downloads",
        description: "Unable to load episode downloads. Please try again.",
        variant: "destructive"
      });
    }
    setIsLoadingEpisode(false);
  };

  const handleDirectDownload = (downloadLink: any) => {
    window.open(downloadLink.url, '_blank');
    toast({
      title: "Download Started",
      description: `Opening ${downloadLink.source} download link`,
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20 p-4">
        <div className="max-w-7xl mx-auto">
          <div className="flex items-center justify-center h-64">
            <div className="text-white text-xl">Loading anime details...</div>
          </div>
        </div>
      </div>
    );
  }

  if (!animeDetail) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20 p-4">
        <div className="max-w-7xl mx-auto">
          <Button
            onClick={() => setLocation("/anime")}
            className="mb-6 bg-purple-600 hover:bg-purple-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Anime
          </Button>
          <div className="text-center text-white">
            <h2 className="text-2xl font-bold mb-4">Anime Not Found</h2>
            <p>The requested anime could not be loaded.</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900/20 via-black to-pink-900/20">
      <div className="max-w-7xl mx-auto p-4">
        {/* Header */}
        <div className="flex items-center gap-4 mb-6">
          <Button
            onClick={() => setLocation("/anime")}
            className="bg-purple-600 hover:bg-purple-700"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Anime
          </Button>
          <h1 className="text-3xl font-bold text-white">Anime Details</h1>
        </div>

        {/* Anime Info */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          <div className="lg:col-span-1">
            <Card className="bg-black/40 border-purple-500/30">
              <CardContent className="p-6">
                <img
                  src={animeDetail.image}
                  alt={animeDetail.title}
                  className="w-full h-80 object-cover rounded-lg mb-4"
                />
                <div className="space-y-4">
                  <div className="flex items-center gap-2">
                    <Star className="w-5 h-5 text-yellow-400" />
                    <span className="text-white font-semibold">
                      {animeDetail.rating?.value || animeDetail.info?.rating || "N/A"}
                    </span>
                    <span className="text-gray-400">
                      ({animeDetail.rating?.count || animeDetail.info?.voters || "0"} votes)
                    </span>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {(animeDetail.genres || animeDetail.info?.genre || []).map((genre) => (
                      <Badge key={genre} variant="outline" className="border-purple-500/30">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                  <div className="space-y-2 text-sm">
                    <div>
                      <span className="text-gray-400">Season:</span>
                      <span className="text-white ml-2">
                        {animeDetail.releaseSeason || animeDetail.info?.season || "N/A"}
                      </span>
                    </div>
                    {animeDetail.info?.credit && (
                      <div>
                        <span className="text-gray-400">Credit:</span>
                        <span className="text-white ml-2">{animeDetail.info.credit}</span>
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <Button className="flex-1 bg-red-600 hover:bg-red-700">
                      <Heart className="w-4 h-4 mr-2" />
                      Favorite
                    </Button>
                    <Button className="flex-1 bg-green-600 hover:bg-green-700">
                      <Share2 className="w-4 h-4 mr-2" />
                      Share
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-2">
            <Card className="bg-black/40 border-purple-500/30">
              <CardContent className="p-6">
                <h2 className="text-2xl font-bold text-white mb-4">{animeDetail.title}</h2>
                <p className="text-gray-300 mb-6">{animeDetail.synopsis}</p>
                
                <h3 className="text-xl font-semibold text-white mb-4">Episodes</h3>
                <ScrollArea className="h-96">
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {episodes.map((episode) => (
                      <Card
                        key={episode.episodeNumber}
                        className="bg-gray-800/30 border-gray-600/30 hover:border-purple-500/50 transition-all cursor-pointer"
                        onClick={() => handleEpisodeDownload(episode)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center gap-2 mb-2">
                            <Play className="w-4 h-4 text-purple-400" />
                            <span className="text-white font-medium">
                              Episode {episode.episodeNumber}
                            </span>
                          </div>
                          <Button
                            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                            size="sm"
                            disabled={isLoadingEpisode && selectedEpisode?.episodeNumber === episode.episodeNumber}
                          >
                            <Download className="w-3 h-3 mr-1" />
                            {isLoadingEpisode && selectedEpisode?.episodeNumber === episode.episodeNumber
                              ? "Loading..."
                              : "Download"
                            }
                          </Button>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Episode Download Modal */}
        <Dialog open={showDownloadModal} onOpenChange={setShowDownloadModal}>
          <DialogContent className="bg-black/90 border-purple-500/20 max-w-4xl max-h-[90vh] overflow-hidden">
            <DialogHeader>
              <DialogTitle className="text-white flex items-center gap-2">
                <Download className="w-5 h-5" />
                Download {selectedEpisode?.title}
              </DialogTitle>
            </DialogHeader>
            
            {episodeDownloads && (
              <ScrollArea className="h-96">
                <div className="space-y-4">
                  <h5 className="text-white font-semibold">📥 Download Options</h5>
                  {episodeDownloads.downloads?.map((download: any, index: number) => (
                    <Card key={index} className="bg-gray-800/30 border-gray-600/30">
                      <CardContent className="p-4">
                        <h6 className="text-white font-medium mb-3 flex items-center gap-2">
                          <Badge className="bg-green-600">{download.resolution}</Badge>
                          Quality
                        </h6>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                          {download.links?.map((link: any, linkIndex: number) => (
                            <Button
                              key={linkIndex}
                              onClick={() => handleDirectDownload(link)}
                              variant="outline"
                              className="border-gray-600 text-white hover:bg-purple-600/20 justify-start"
                            >
                              <Download className="w-4 h-4 mr-2" />
                              {link.source}
                            </Button>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </ScrollArea>
            )}
          </DialogContent>
        </Dialog>
      </div>
    </div>
  );
}