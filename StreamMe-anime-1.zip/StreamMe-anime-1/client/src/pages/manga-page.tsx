import { useState, useEffect, useRef } from "react";
import { Search, Star, Heart, Share2, Maximize2, ChevronLeft, ChevronRight, Bookmark, X, TrendingUp, BookOpen, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import NavigationHeader from "@/components/navigation-header";

interface MangaItem {
  id: string;
  title: string;
  description: string;
  coverUrl: string;
  status: string;
  author?: string;
  year?: number;
  tags: string[];
}

interface Chapter {
  id: string;
  number: string;
  title?: string;
  pages?: number;
  translatedLanguage: string;
}

interface ChapterPages {
  baseUrl: string;
  hash: string;
  data: string[];
}

export default function MangaPage() {
  const [mangaList, setMangaList] = useState<MangaItem[]>([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("all");
  const [isLoading, setIsLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [selectedManga, setSelectedManga] = useState<MangaItem | null>(null);
  const [mangaChapters, setMangaChapters] = useState<Chapter[]>([]);
  const [selectedChapter, setSelectedChapter] = useState<Chapter | null>(null);
  const [chapterPages, setChapterPages] = useState<ChapterPages | null>(null);
  const [showModal, setShowModal] = useState(false);
  const [showReader, setShowReader] = useState(false);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [bookmarks, setBookmarks] = useState<any[]>([]);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const { toast } = useToast();
  const readerRef = useRef<HTMLDivElement>(null);

  // Load favorites and bookmarks from localStorage
  useEffect(() => {
    const savedFavorites = localStorage.getItem('mangaFavorites');
    const savedBookmarks = localStorage.getItem('mangaBookmarks');
    if (savedFavorites) setFavorites(JSON.parse(savedFavorites));
    if (savedBookmarks) setBookmarks(JSON.parse(savedBookmarks));
  }, []);

  // Infinite scroll
  useEffect(() => {
    const handleScroll = () => {
      if (window.innerHeight + window.scrollY >= document.body.offsetHeight - 100 && !isLoading && !loadingMore) {
        loadMoreManga();
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [isLoading, loadingMore, currentPage]);

  // Initial load
  useEffect(() => {
    fetchTrendingManga(1);
  }, []);

  // Search with debounce
  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchQuery || selectedGenre !== "all") {
        setCurrentPage(1);
        fetchTrendingManga(1, true);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery, selectedGenre]);

  // Fallback manga data for when API fails
  const fallbackManga = [
    {
      id: "1",
      title: "Solo Leveling",
      description: "10 years ago, after 'the Gate' that connected the real world with the monster world opened, some of the ordinary, everyday people received the power to hunt monsters within the Gate. They are known as 'Hunters'. However, not all Hunters are powerful. My name is Sung Jin-Woo, an E-rank Hunter.",
      coverUrl: "https://uploads.mangadex.org/covers/32d76d19-8a05-4db0-9fc2-e0b0648fe79d/4db7c3d5-7e63-42aa-b6e5-4f8abb3a66d3.jpg.256.jpg",
      status: "completed",
      author: "Chugong",
      year: 2018,
      tags: ["Action", "Adventure", "Fantasy"]
    },
    {
      id: "2", 
      title: "Sono Bisque Doll wa Koi wo Suru",
      description: "Wakana Gojo is a high school boy who wants to become a kashirashi--a master craftsman who makes traditional Japanese Hina dolls. Though he's gung-ho about the craft, he knows nothing about the latest trends, and has a hard time fitting in with his class.",
      coverUrl: "https://uploads.mangadex.org/covers/f7972eed-0040-4aac-b8de-fc99c522c25a/2b170419-b4c9-410d-a1c8-6d2bb2e9e7b8.jpg.256.jpg",
      status: "ongoing",
      author: "Shinichi Fukuda",
      year: 2018,
      tags: ["Romance", "Comedy", "School"]
    },
    {
      id: "3",
      title: "Chainsaw Man",
      description: "The name says it all! Denji's life of poverty is changed forever when he merges with his pet chainsaw dog, Pochita! Now he's living in the big city and an official Devil Hunter. But he's got a lot to learn about his new job and chainsaw powers!",
      coverUrl: "https://uploads.mangadex.org/covers/a96676e5-8ae2-425e-b549-7f15dd34a6d8/256bbdbb-0c01-4712-abfc-31ab1ad2f506.jpg.256.jpg",
      status: "ongoing", 
      author: "Tatsuki Fujimoto",
      year: 2018,
      tags: ["Action", "Horror", "Supernatural"]
    },
    {
      id: "4",
      title: "Kaguya-sama wa Kokurasetai",
      description: "As leaders of their prestigious academy's student council, Kaguya and Miyuki are the elite of the elite! But it's lonely at the top... Luckily for them, they've fallen in love! There's just one problem—they both have too much pride to admit it.",
      coverUrl: "https://uploads.mangadex.org/covers/37f5cce0-8070-4ada-96e5-fa24b1bd4ff9/4c7bb926-c9b2-4dd8-b7e4-2a5c536a8e44.jpg.256.jpg",
      status: "completed",
      author: "Aka Akasaka", 
      year: 2015,
      tags: ["Romance", "Comedy", "School"]
    },
    {
      id: "5",
      title: "Spy x Family",
      description: "Master spy Twilight is unparalleled when it comes to going undercover on dangerous missions for the betterment of the world. But when he receives the ultimate assignment—to get married and have a child—he may finally be in over his head!",
      coverUrl: "https://uploads.mangadex.org/covers/746a0cbd-5b38-4b0f-b2d4-7d5c9b0d9a9a/4c7bb926-c9b2-4dd8-b7e4-2a5c536a8e44.jpg.256.jpg",
      status: "ongoing",
      author: "Tatsuya Endo",
      year: 2019,
      tags: ["Action", "Comedy", "Family"]
    },
    {
      id: "6",
      title: "Demon Slayer",
      description: "Since ancient times, rumors have abounded of man-eating demons lurking in the woods. Because of this, the local townsfolk never venture outside at night. Legend has it that a demon slayer also roams the night, hunting down these bloodthirsty demons.",
      coverUrl: "https://uploads.mangadx.org/covers/f5b1e4b1-1c3c-4b0e-8b1e-1c3c4b0e8b1e/cover.jpg.256.jpg",
      status: "completed",
      author: "Koyoharu Gotouge", 
      year: 2016,
      tags: ["Action", "Historical", "Supernatural"]
    }
  ];

  const fetchTrendingManga = async (page = 1, isSearch = false) => {
    if (page === 1) {
      setIsLoading(true);
      setMangaList([]);
    } else {
      setLoadingMore(true);
    }

    try {
      // Try to fetch from MangaDx API first
      let url = `https://api.mangadex.org/manga?limit=20&offset=${(page - 1) * 20}&order[followedCount]=desc&includes[]=cover_art&includes[]=author&contentRating[]=safe&contentRating[]=suggestive`;
      
      if (selectedGenre !== "all") {
        url += `&publicationDemographic[]=${selectedGenre.toLowerCase()}`;
      }

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000); // 10 second timeout

      const response = await fetch(url, {
        signal: controller.signal,
        mode: 'cors',
        headers: {
          'Accept': 'application/json',
        }
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) throw new Error(`API error: ${response.status}`);
      
      const data = await response.json();
      
      if (!data.data || data.data.length === 0) {
        throw new Error('No data received from API');
      }

      const formattedManga = data.data
        .filter((manga: any) => {
          if (!searchQuery) return true;
          const title = manga.attributes.title.en || manga.attributes.title[Object.keys(manga.attributes.title)[0]] || '';
          return title.toLowerCase().includes(searchQuery.toLowerCase());
        })
        .map((manga: any) => {
          const cover = manga.relationships.find((r: any) => r.type === 'cover_art');
          const author = manga.relationships.find((r: any) => r.type === 'author');
          const fileName = cover?.attributes?.fileName;
          
          return {
            id: manga.id,
            title: manga.attributes.title.en || manga.attributes.title[Object.keys(manga.attributes.title)[0]] || 'No Title',
            description: manga.attributes.description.en || manga.attributes.description[Object.keys(manga.attributes.description)[0]] || 'No description available',
            coverUrl: fileName ? `https://uploads.mangadex.org/covers/${manga.id}/${fileName}.256.jpg` : 'https://via.placeholder.com/256x364?text=No+Cover',
            status: manga.attributes.status || 'unknown',
            author: author?.attributes?.name || 'Unknown Author',
            year: manga.attributes.year || new Date().getFullYear(),
            tags: manga.attributes.tags?.map((tag: any) => tag.attributes.name.en).slice(0, 3) || []
          };
        });

      if (page === 1) {
        setMangaList(formattedManga);
      } else {
        setMangaList(prev => [...prev, ...formattedManga]);
      }
      
      setCurrentPage(page);
    } catch (error) {
      console.error('Error fetching manga:', error);
      
      // Use fallback data when API fails
      if (page === 1) {
        const filteredFallback = fallbackManga.filter(manga => {
          if (searchQuery && !manga.title.toLowerCase().includes(searchQuery.toLowerCase())) {
            return false;
          }
          if (selectedGenre !== "all" && !manga.tags.some(tag => tag.toLowerCase().includes(selectedGenre.toLowerCase()))) {
            return false;
          }
          return true;
        });
        
        setMangaList(filteredFallback);
        
        toast({
          title: "Using Offline Data",
          description: "API unavailable, showing sample manga. Try refreshing later.",
        });
      }
    } finally {
      setIsLoading(false);
      setLoadingMore(false);
    }
  };

  const loadMoreManga = () => {
    if (!loadingMore) {
      fetchTrendingManga(currentPage + 1);
    }
  };

  const openMangaModal = async (manga: MangaItem) => {
    setSelectedManga(manga);
    setShowModal(true);
    
    try {
      // Fetch chapters
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);
      
      const chaptersResponse = await fetch(
        `https://api.mangadex.org/chapter?manga=${manga.id}&translatedLanguage[]=en&order[chapter]=asc&limit=100`,
        { signal: controller.signal }
      );
      
      clearTimeout(timeoutId);
      
      if (chaptersResponse.ok) {
        const chaptersData = await chaptersResponse.json();
        const chapters = chaptersData.data.map((chapter: any) => ({
          id: chapter.id,
          number: chapter.attributes.chapter || '0',
          title: chapter.attributes.title || '',
          pages: chapter.attributes.pages || 0,
          translatedLanguage: chapter.attributes.translatedLanguage
        }));
        setMangaChapters(chapters);
      } else {
        throw new Error('Failed to fetch chapters');
      }
    } catch (error) {
      console.error('Error fetching chapters:', error);
      
      // Provide fallback chapters for demo
      const fallbackChapters = Array.from({ length: 10 }, (_, i) => ({
        id: `chapter-${i + 1}`,
        number: `${i + 1}`,
        title: `Chapter ${i + 1}`,
        pages: 20,
        translatedLanguage: 'en'
      }));
      
      setMangaChapters(fallbackChapters);
      
      toast({
        title: "Using Demo Chapters",
        description: "Real chapters unavailable, showing demo content",
      });
    }
  };

  const readChapter = async (chapter: Chapter) => {
    setSelectedChapter(chapter);
    setShowReader(true);
    setShowModal(false);
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 8000);
      
      const response = await fetch(`https://api.mangadex.org/at-home/server/${chapter.id}`, {
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) throw new Error('Failed to fetch chapter pages');
      
      const data = await response.json();
      // Transform API response to match ChapterPages interface
      const transformedPages: ChapterPages = {
        baseUrl: data.baseUrl,
        hash: data.chapter.hash,
        data: data.chapter.data
      };
      setChapterPages(transformedPages);
    } catch (error) {
      console.error('Error fetching chapter pages:', error);
      
      // Provide fallback demo pages with correct structure
      const demoPages: ChapterPages = {
        baseUrl: 'https://via.placeholder.com',
        hash: 'demo-hash',
        data: Array.from({ length: chapter.pages || 20 }, (_, i) => `800x1200/1a1a2e/ffffff?text=Page+${i + 1}`)
      };
      
      setChapterPages(demoPages);
      
      toast({
        title: "Demo Mode", 
        description: "Showing placeholder pages - real images unavailable",
      });
    }
  };

  const toggleFavorite = (mangaId: string) => {
    const newFavorites = favorites.includes(mangaId)
      ? favorites.filter(id => id !== mangaId)
      : [...favorites, mangaId];
    
    setFavorites(newFavorites);
    localStorage.setItem('mangaFavorites', JSON.stringify(newFavorites));
    
    toast({
      title: favorites.includes(mangaId) ? "Removed from Favorites" : "Added to Favorites",
      description: selectedManga?.title || "Manga"
    });
  };

  const saveBookmark = () => {
    if (!selectedManga || !selectedChapter) return;
    
    const bookmark = {
      mangaId: selectedManga.id,
      mangaTitle: selectedManga.title,
      chapterId: selectedChapter.id,
      chapterNumber: selectedChapter.number,
      chapterTitle: selectedChapter.title
    };
    
    const newBookmarks = [...bookmarks, bookmark];
    setBookmarks(newBookmarks);
    localStorage.setItem('mangaBookmarks', JSON.stringify(newBookmarks));
    
    toast({
      title: "Bookmark Saved",
      description: `Chapter ${selectedChapter.number} bookmarked`
    });
  };

  const shareManga = () => {
    if (!selectedManga) return;
    
    if (navigator.share) {
      navigator.share({
        title: `Check out ${selectedManga.title} on StreamMe Manga!`,
        url: window.location.href
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(`Check out ${selectedManga.title} - ${window.location.href}`);
      toast({
        title: "Link Copied",
        description: "Manga link copied to clipboard"
      });
    }
  };

  const nextChapter = () => {
    if (!selectedChapter) return;
    
    const currentIndex = mangaChapters.findIndex(ch => ch.id === selectedChapter.id);
    if (currentIndex < mangaChapters.length - 1) {
      readChapter(mangaChapters[currentIndex + 1]);
    }
  };

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      readerRef.current?.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const closeReader = () => {
    setShowReader(false);
    setChapterPages(null);
    if (document.fullscreenElement) {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  const genres = ["all", "Action", "Romance", "Fantasy", "Shonen", "Seinen", "Comedy", "Drama", "Horror", "Slice of Life"];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <NavigationHeader title="StreamMe Manga" />
      
      {/* Header Section */}
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col md:flex-row justify-between items-center gap-4 mb-6">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-8 w-8 text-purple-400" />
            <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              Trending Manga
            </h1>
          </div>
          
          <div className="flex items-center gap-4 w-full md:w-auto">
            <div className="relative flex-1 md:w-64">
              <Input
                type="text"
                placeholder="Search manga..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-black/50 border-purple-500/30 text-white placeholder-gray-400 focus:border-purple-500"
                data-testid="input-search-manga"
              />
              <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            </div>
            
            <Select value={selectedGenre} onValueChange={setSelectedGenre}>
              <SelectTrigger className="bg-black/50 border-purple-500/30 text-white w-40">
                <SelectValue placeholder="All Genres" />
              </SelectTrigger>
              <SelectContent className="bg-black/90 border-purple-500/30 text-white">
                {genres.map(genre => (
                  <SelectItem key={genre} value={genre} className="hover:bg-purple-500/20">
                    {genre === "all" ? "All Genres" : genre}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Favorites Section */}
        {favorites.length > 0 && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-purple-400 mb-4 flex items-center gap-2">
              <Star className="h-6 w-6" />
              Your Favorites
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {mangaList
                .filter(manga => favorites.includes(manga.id))
                .slice(0, 6)
                .map((manga) => (
                  <Card key={manga.id} className="bg-black/50 border-purple-500/30 hover:border-purple-500/50 transition-all duration-300 hover:scale-105 cursor-pointer">
                    <CardContent className="p-2">
                      <img
                        src={manga.coverUrl}
                        alt={manga.title}
                        className="w-full h-48 object-cover rounded mb-2"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src = 'https://via.placeholder.com/256x364?text=No+Cover';
                        }}
                      />
                      <h3 className="text-sm font-semibold text-white truncate">{manga.title}</h3>
                      <Button
                        size="sm"
                        onClick={() => openMangaModal(manga)}
                        className="w-full mt-2 bg-purple-600 hover:bg-purple-700"
                      >
                        <Eye className="h-3 w-3 mr-1" />
                        View
                      </Button>
                    </CardContent>
                  </Card>
                ))}
            </div>
          </div>
        )}

        {/* Loading State */}
        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <div className="text-center">
              <div className="w-8 h-8 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-white">Loading manga...</p>
            </div>
          </div>
        ) : (
          <>
            {/* Manga Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {mangaList.map((manga) => (
                <Card key={manga.id} className="bg-black/50 border-purple-500/30 hover:border-purple-500/50 transition-all duration-300 hover:scale-105 cursor-pointer" data-testid={`card-manga-${manga.id}`}>
                  <CardContent className="p-3">
                    <img
                      src={manga.coverUrl}
                      alt={manga.title}
                      className="w-full h-48 object-cover rounded mb-2"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://via.placeholder.com/256x364?text=No+Cover';
                      }}
                    />
                    <h3 className="text-sm font-semibold text-white mb-1 truncate" title={manga.title}>
                      {manga.title}
                    </h3>
                    <p className="text-xs text-gray-400 mb-2 truncate">
                      {manga.author}
                    </p>
                    <div className="flex flex-wrap gap-1 mb-2">
                      {manga.tags.slice(0, 2).map((tag, index) => (
                        <Badge key={index} variant="outline" className="text-xs border-purple-500/50 text-purple-300">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <Button
                      size="sm"
                      onClick={() => openMangaModal(manga)}
                      className="w-full bg-purple-600 hover:bg-purple-700"
                      data-testid={`button-view-manga-${manga.id}`}
                    >
                      <Eye className="h-3 w-3 mr-1" />
                      View
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Load More */}
            {loadingMore && (
              <div className="flex justify-center mt-8">
                <div className="text-center">
                  <div className="w-6 h-6 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mx-auto mb-2"></div>
                  <p className="text-white text-sm">Loading more...</p>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {/* Manga Detail Modal */}
      <Dialog open={showModal} onOpenChange={setShowModal}>
        <DialogContent className="bg-black/90 border-purple-500/30 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-purple-400">Manga Details</DialogTitle>
            <DialogDescription className="text-gray-400">
              View chapters and read your favorite manga
            </DialogDescription>
          </DialogHeader>
          
          {selectedManga && (
            <div className="space-y-4">
              <div className="flex gap-4">
                <img
                  src={selectedManga.coverUrl}
                  alt={selectedManga.title}
                  className="w-32 h-48 object-cover rounded"
                />
                <div className="flex-1">
                  <h2 className="text-2xl font-bold mb-2">{selectedManga.title}</h2>
                  <p className="text-gray-300 mb-2">Author: {selectedManga.author}</p>
                  <p className="text-gray-300 mb-2">Status: {selectedManga.status}</p>
                  <p className="text-gray-300 mb-4 text-sm line-clamp-3">{selectedManga.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {selectedManga.tags.map((tag, index) => (
                      <Badge key={index} variant="outline" className="border-purple-500/50 text-purple-300">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
              
              <div className="flex gap-4 items-center">
                <div className="flex-1">
                  <label className="text-sm text-gray-400 mb-2 block">Select Chapter:</label>
                  <Select onValueChange={(chapterId) => {
                    const chapter = mangaChapters.find(ch => ch.id === chapterId);
                    if (chapter) setSelectedChapter(chapter);
                  }}>
                    <SelectTrigger className="bg-black/50 border-purple-500/30 text-white">
                      <SelectValue placeholder="Choose a chapter" />
                    </SelectTrigger>
                    <SelectContent className="bg-black/90 border-purple-500/30 text-white max-h-48">
                      {mangaChapters.map((chapter) => (
                        <SelectItem key={chapter.id} value={chapter.id} className="hover:bg-purple-500/20">
                          Chapter {chapter.number} {chapter.title && `- ${chapter.title}`}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div className="flex gap-2">
                <Button
                  onClick={() => selectedChapter && readChapter(selectedChapter)}
                  disabled={!selectedChapter}
                  className="bg-blue-600 hover:bg-blue-700"
                  data-testid="button-read-manga"
                >
                  <BookOpen className="h-4 w-4 mr-2" />
                  Read Manga
                </Button>
                <Button
                  onClick={() => toggleFavorite(selectedManga.id)}
                  variant="outline"
                  className={`border-yellow-500/50 ${favorites.includes(selectedManga.id) ? 'bg-yellow-600/20 text-yellow-400' : 'text-yellow-400'} hover:bg-yellow-500/20`}
                  data-testid="button-favorite-manga"
                >
                  <Star className={`h-4 w-4 mr-2 ${favorites.includes(selectedManga.id) ? 'fill-current' : ''}`} />
                  {favorites.includes(selectedManga.id) ? 'Remove from Favorites' : 'Add to Favorites'}
                </Button>
                <Button
                  onClick={shareManga}
                  variant="outline"
                  className="border-green-500/50 text-green-400 hover:bg-green-500/20"
                  data-testid="button-share-manga"
                >
                  <Share2 className="h-4 w-4 mr-2" />
                  Share
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Reader View */}
      {showReader && (
        <div ref={readerRef} className="fixed inset-0 bg-black z-50 overflow-y-auto">
          <div className="max-w-4xl mx-auto p-4">
            <div className="flex justify-between items-center mb-4 sticky top-0 bg-black/90 py-2">
              <Button onClick={closeReader} variant="destructive" size="sm">
                <X className="h-4 w-4 mr-2" />
                Close Reader
              </Button>
              <Button onClick={toggleFullscreen} variant="outline" size="sm" className="border-blue-500/50 text-blue-400">
                <Maximize2 className="h-4 w-4 mr-2" />
                {isFullscreen ? 'Exit Fullscreen' : 'Fullscreen'}
              </Button>
            </div>
            
            {chapterPages && (
              <div className="space-y-4">
                <div className="text-center text-gray-400 mb-4">
                  Reading: Chapter {selectedChapter?.number} - Page 1 of {chapterPages.data.length}
                </div>
                {chapterPages.data.map((page, index) => (
                  <div key={index} className="relative">
                    <img
                      src={chapterPages.baseUrl.includes('placeholder') 
                        ? `${chapterPages.baseUrl}/${page}`
                        : `${chapterPages.baseUrl}/data/${chapterPages.hash}/${page}`
                      }
                      alt={`Page ${index + 1}`}
                      className="w-full max-w-4xl rounded mx-auto shadow-lg"
                      loading="lazy"
                      onError={(e) => {
                        console.error(`Failed to load page ${index + 1}`, e);
                        // Set fallback image on error
                        e.currentTarget.src = `https://via.placeholder.com/800x1200/1a1a2e/ffffff?text=Error+Loading+Page+${index + 1}`;
                      }}
                      onLoad={() => {
                        console.log(`Successfully loaded page ${index + 1}`);
                      }}
                    />
                    <div className="absolute bottom-2 right-2 bg-black/70 text-white px-2 py-1 rounded text-sm">
                      {index + 1} / {chapterPages.data.length}
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            <div className="flex items-center gap-4 mt-4 sticky bottom-0 bg-black/90 py-4">
              <Button onClick={nextChapter} className="bg-green-600 hover:bg-green-700">
                <ChevronRight className="h-4 w-4 mr-2" />
                Next Chapter
              </Button>
              <Button onClick={saveBookmark} variant="outline" className="border-purple-500/50 text-purple-400">
                <Bookmark className="h-4 w-4 mr-2" />
                Bookmark
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}