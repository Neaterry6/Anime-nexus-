import { useState, useEffect, useRef } from "react";
import { Search, Download, Play, Music, Video, Loader2, ExternalLink, Heart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import NavigationHeader from "@/components/navigation-header";

interface VideoResult {
  title: string;
  url: string;
  thumbnail: string;
  duration: string;
  artist?: string;
  channel?: string;
  views?: string;
  uploadDate?: string;
}

interface QualityOption {
  quality: string;
  url: string;
  size?: string;
}

interface DownloadProgress {
  videoId: string;
  progress: number;
  status: 'downloading' | 'completed' | 'error';
}

export default function YouTubePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [results, setResults] = useState<VideoResult[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<VideoResult | null>(null);
  const [qualityOptions, setQualityOptions] = useState<QualityOption[]>([]);
  const [downloadProgress, setDownloadProgress] = useState<Record<string, DownloadProgress>>({});
  const [lyrics, setLyrics] = useState("");
  const [showLyrics, setShowLyrics] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const { toast } = useToast();

  // API configuration
  const API_KEY = 'a0ebe80e-bf1a-4dbf-8d36-6935b1bfa5ea';
  const SEARCH_API = 'https://kaiz-apis.gleeze.com/api/ytsearch';
  const MP3_API = 'https://kaiz-apis.gleeze.com/api/ytdown-mp3';
  const VIDEO_API = 'https://kaiz-apis.gleeze.com/api/ytmp4';
  const LYRICS_API = 'https://kaiz-apis.gleeze.com/api/shazam-lyrics';

  // Random search terms for initial load
  const randomSearchTerms = [
    "NF", "Drake", "Billie Eilish", "Taylor Swift", "K-pop", "Anime songs", "TikTok hits",
    "Post Malone", "Justin Bieber", "Ariana Grande", "The Weeknd", "Bad Bunny",
    "Demon Slayer soundtrack", "Attack on Titan songs", "Naruto Shippuden soundtrack",
    "BTS", "Blackpink", "EXO", "Red Velvet", "One Piece soundtrack"
  ];

  // Fallback results if API fails
  const fallbackResults: VideoResult[] = [
    { title: "Baby Girl - Joeboy", url: "#", thumbnail: "https://via.placeholder.com/480x360", duration: "3:30", artist: "Joeboy" },
    { title: "Shape of You - Ed Sheeran", url: "#", thumbnail: "https://via.placeholder.com/480x360", duration: "4:24", artist: "Ed Sheeran" },
    { title: "Dynamite - BTS", url: "#", thumbnail: "https://via.placeholder.com/480x360", duration: "3:19", artist: "BTS" },
    { title: "Blinding Lights - The Weeknd", url: "#", thumbnail: "https://via.placeholder.com/480x360", duration: "3:20", artist: "The Weeknd" },
    { title: "Levitating - Dua Lipa", url: "#", thumbnail: "https://via.placeholder.com/480x360", duration: "3:23", artist: "Dua Lipa" },
    { title: "Bad Guy - Billie Eilish", url: "#", thumbnail: "https://via.placeholder.com/480x360", duration: "3:14", artist: "Billie Eilish" },
  ];

  // Initialize with random search on mount
  useEffect(() => {
    const randomTerm = randomSearchTerms[Math.floor(Math.random() * randomSearchTerms.length)];
    setSearchQuery(randomTerm);
    searchMusic(randomTerm);
  }, []);

  const searchMusic = async (query: string, page: number = 1) => {
    if (!query.trim()) return;
    
    setIsLoading(true);
    try {
      console.log(`Searching for: ${query}, page: ${page}`);
      const response = await fetch(`${SEARCH_API}?q=${encodeURIComponent(query)}&apikey=${API_KEY}&page=${page}`);
      
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }
      
      const data = await response.json();
      console.log('API Response:', data);
      
      if (data.success && data.result && Array.isArray(data.result)) {
        const formattedResults = data.result.map((item: any) => ({
          title: item.title || 'Unknown Title',
          url: item.url || '#',
          thumbnail: item.thumbnail || 'https://via.placeholder.com/480x360',
          duration: item.duration || '0:00',
          artist: item.author || item.channel || 'Unknown Artist',
          channel: item.channel || item.author || 'Unknown Channel',
          views: item.views || '0',
          uploadDate: item.publishedTime || 'Unknown'
        }));
        
        if (page === 1) {
          setResults(formattedResults);
        } else {
          setResults(prev => [...prev, ...formattedResults]);
        }
      } else {
        throw new Error('Invalid API response format');
      }
    } catch (error) {
      console.error('Search error:', error);
      if (page === 1) {
        setResults(fallbackResults);
        toast({
          title: "API Error",
          description: "Showing fallback results. Try searching again.",
          variant: "destructive"
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = () => {
    if (!searchQuery.trim()) {
      toast({
        title: "Search Required",
        description: "Please enter a search term.",
        variant: "destructive"
      });
      return;
    }
    
    setCurrentPage(1);
    setResults([]);
    searchMusic(searchQuery, 1);
  };

  const loadMore = () => {
    const nextPage = currentPage + 1;
    setCurrentPage(nextPage);
    searchMusic(searchQuery, nextPage);
  };

  const downloadMP3 = async (video: VideoResult) => {
    const videoId = extractVideoId(video.url);
    if (!videoId) return;

    setDownloadProgress(prev => ({
      ...prev,
      [videoId]: { videoId, progress: 0, status: 'downloading' }
    }));

    try {
      const response = await fetch(`${MP3_API}?url=${encodeURIComponent(video.url)}&apikey=${API_KEY}`);
      const data = await response.json();
      
      if (data.success && data.result?.download) {
        // Simulate download progress
        for (let progress = 10; progress <= 100; progress += 10) {
          setDownloadProgress(prev => ({
            ...prev,
            [videoId]: { videoId, progress, status: 'downloading' }
          }));
          await new Promise(resolve => setTimeout(resolve, 200));
        }

        // Create download link
        const link = document.createElement('a');
        link.href = data.result.download;
        link.download = `${video.title}.mp3`;
        link.click();

        setDownloadProgress(prev => ({
          ...prev,
          [videoId]: { videoId, progress: 100, status: 'completed' }
        }));

        toast({
          title: "Download Started",
          description: `${video.title} - MP3 download initiated`,
        });
      } else {
        throw new Error('Failed to get download URL');
      }
    } catch (error) {
      console.error('Download error:', error);
      setDownloadProgress(prev => ({
        ...prev,
        [videoId]: { videoId, progress: 0, status: 'error' }
      }));
      
      toast({
        title: "Download Failed",
        description: "Could not download MP3. Please try again.",
        variant: "destructive"
      });
    }
  };

  const selectVideoQuality = async (video: VideoResult) => {
    setSelectedVideo(video);
    try {
      const response = await fetch(`${VIDEO_API}?url=${encodeURIComponent(video.url)}&apikey=${API_KEY}`);
      const data = await response.json();
      
      if (data.success && data.result) {
        const qualities: QualityOption[] = [
          { quality: "360p", url: data.result.low || data.result.download },
          { quality: "720p", url: data.result.high || data.result.download },
          { quality: "1080p", url: data.result.fullhd || data.result.download }
        ].filter(q => q.url);
        
        setQualityOptions(qualities);
      }
    } catch (error) {
      console.error('Quality fetch error:', error);
      toast({
        title: "Error",
        description: "Could not fetch video qualities.",
        variant: "destructive"
      });
    }
  };

  const downloadVideo = async (quality: QualityOption) => {
    if (!selectedVideo) return;
    
    const videoId = extractVideoId(selectedVideo.url);
    if (!videoId) return;

    setDownloadProgress(prev => ({
      ...prev,
      [videoId]: { videoId, progress: 0, status: 'downloading' }
    }));

    try {
      // Simulate download progress
      for (let progress = 10; progress <= 100; progress += 10) {
        setDownloadProgress(prev => ({
          ...prev,
          [videoId]: { videoId, progress, status: 'downloading' }
        }));
        await new Promise(resolve => setTimeout(resolve, 300));
      }

      // Create download link
      const link = document.createElement('a');
      link.href = quality.url;
      link.download = `${selectedVideo.title}_${quality.quality}.mp4`;
      link.click();

      setDownloadProgress(prev => ({
        ...prev,
        [videoId]: { videoId, progress: 100, status: 'completed' }
      }));

      toast({
        title: "Download Started",
        description: `${selectedVideo.title} - ${quality.quality} download initiated`,
      });
    } catch (error) {
      console.error('Download error:', error);
      setDownloadProgress(prev => ({
        ...prev,
        [videoId]: { videoId, progress: 0, status: 'error' }
      }));
      
      toast({
        title: "Download Failed", 
        description: "Could not download video. Please try again.",
        variant: "destructive"
      });
    }
  };

  const searchLyrics = async (video: VideoResult) => {
    try {
      const response = await fetch(`${LYRICS_API}?q=${encodeURIComponent(video.title)}&apikey=${API_KEY}`);
      const data = await response.json();
      
      if (data.success && data.result?.lyrics) {
        setLyrics(data.result.lyrics);
        setShowLyrics(true);
      } else {
        setLyrics("Lyrics not found for this song.");
        setShowLyrics(true);
      }
    } catch (error) {
      console.error('Lyrics error:', error);
      setLyrics("Error fetching lyrics. Please try again.");
      setShowLyrics(true);
    }
  };

  const extractVideoId = (url: string): string => {
    const match = url.match(/(?:v=|\/)([a-zA-Z0-9_-]{11})/);
    return match ? match[1] : url;
  };

  const formatDuration = (duration: string): string => {
    if (duration.includes(':')) return duration;
    const minutes = Math.floor(parseInt(duration) / 60);
    const seconds = parseInt(duration) % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <NavigationHeader title="YouTube Music & Videos" />
      
      {/* Hero Section */}
      <div className="relative bg-black/50 backdrop-blur-sm border-b border-purple-500/20">
        <div className="absolute inset-0 bg-gradient-to-r from-purple-600/20 to-pink-600/20" />
        <div className="relative container mx-auto px-4 py-12">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-4">
              <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                🎵 YouTube Downloader
              </span>
            </h1>
            <p className="text-xl text-gray-300 mb-8">
              Search, stream, and download your favorite music and videos
            </p>
            
            {/* Search Bar */}
            <div className="flex gap-4 max-w-2xl mx-auto">
              <Input
                type="text"
                placeholder="Search for music or videos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
                className="bg-black/50 border-purple-500/30 text-white placeholder-gray-400 focus:border-purple-500"
                data-testid="input-search-youtube"
              />
              <Button
                onClick={handleSearch}
                disabled={isLoading}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                data-testid="button-search-youtube"
              >
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Search className="h-4 w-4" />
                )}
                Search
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Results Section */}
      <div className="container mx-auto px-4 py-8">
        {isLoading && results.length === 0 ? (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-purple-500" />
            <span className="ml-2 text-white">Loading results...</span>
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {results.map((video, index) => {
                const videoId = extractVideoId(video.url);
                const progress = downloadProgress[videoId];
                
                return (
                  <Card key={index} className="bg-black/50 border-purple-500/30 hover:border-purple-500/50 transition-all duration-300 hover:scale-105" data-testid={`card-video-${index}`}>
                    <CardHeader className="p-0">
                      <div className="relative">
                        <img
                          src={video.thumbnail}
                          alt={video.title}
                          className="w-full h-48 object-cover rounded-t-lg"
                        />
                        <div className="absolute bottom-2 right-2 bg-black/80 text-white text-xs px-2 py-1 rounded">
                          {formatDuration(video.duration)}
                        </div>
                        <div className="absolute inset-0 bg-black/0 hover:bg-black/30 transition-colors duration-300 flex items-center justify-center opacity-0 hover:opacity-100 rounded-t-lg">
                          <Play className="h-12 w-12 text-white" />
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="p-4">
                      <CardTitle className="text-white text-sm mb-2 line-clamp-2">
                        {video.title}
                      </CardTitle>
                      <CardDescription className="text-gray-400 text-xs mb-3">
                        {video.artist || video.channel}
                      </CardDescription>
                      
                      {progress && (
                        <div className="mb-3">
                          <div className="flex justify-between text-xs text-gray-400 mb-1">
                            <span>{progress.status === 'downloading' ? 'Downloading...' : progress.status === 'completed' ? 'Complete!' : 'Error'}</span>
                            <span>{progress.progress}%</span>
                          </div>
                          <div className="w-full bg-gray-700 rounded-full h-1">
                            <div 
                              className={`h-1 rounded-full transition-all duration-300 ${
                                progress.status === 'error' ? 'bg-red-500' : 
                                progress.status === 'completed' ? 'bg-green-500' : 'bg-purple-500'
                              }`}
                              style={{ width: `${progress.progress}%` }}
                            />
                          </div>
                        </div>
                      )}
                      
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => downloadMP3(video)}
                          className="flex-1 border-green-500/50 text-green-400 hover:bg-green-500/20"
                          data-testid={`button-download-mp3-${index}`}
                        >
                          <Music className="h-3 w-3 mr-1" />
                          MP3
                        </Button>
                        
                        <Dialog>
                          <DialogTrigger asChild>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => selectVideoQuality(video)}
                              className="flex-1 border-blue-500/50 text-blue-400 hover:bg-blue-500/20"
                              data-testid={`button-download-video-${index}`}
                            >
                              <Video className="h-3 w-3 mr-1" />
                              MP4
                            </Button>
                          </DialogTrigger>
                          <DialogContent className="bg-black/90 border-purple-500/30 text-white">
                            <DialogHeader>
                              <DialogTitle>Choose Video Quality</DialogTitle>
                              <DialogDescription className="text-gray-400">
                                Select the quality for video download
                              </DialogDescription>
                            </DialogHeader>
                            <div className="space-y-2">
                              {qualityOptions.map((option, idx) => (
                                <Button
                                  key={idx}
                                  onClick={() => downloadVideo(option)}
                                  className="w-full bg-blue-600 hover:bg-blue-700"
                                  data-testid={`button-quality-${option.quality}`}
                                >
                                  <Download className="h-4 w-4 mr-2" />
                                  {option.quality} Quality
                                </Button>
                              ))}
                            </div>
                          </DialogContent>
                        </Dialog>
                        
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => searchLyrics(video)}
                          className="border-purple-500/50 text-purple-400 hover:bg-purple-500/20"
                          data-testid={`button-lyrics-${index}`}
                        >
                          <Heart className="h-3 w-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
            
            {results.length > 0 && (
              <div className="flex justify-center mt-8">
                <Button
                  onClick={loadMore}
                  disabled={isLoading}
                  variant="outline"
                  className="border-purple-500/50 text-purple-400 hover:bg-purple-500/20"
                  data-testid="button-load-more"
                >
                  {isLoading ? (
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  ) : null}
                  Load More
                </Button>
              </div>
            )}
          </>
        )}
      </div>

      {/* Lyrics Modal */}
      <Dialog open={showLyrics} onOpenChange={setShowLyrics}>
        <DialogContent className="bg-black/90 border-purple-500/30 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-purple-400">Lyrics</DialogTitle>
          </DialogHeader>
          <div className="whitespace-pre-line text-gray-300 leading-relaxed">
            {lyrics}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}