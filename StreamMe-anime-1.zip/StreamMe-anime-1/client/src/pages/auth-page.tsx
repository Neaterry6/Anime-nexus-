import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import NavigationHeader from "@/components/navigation-header";

export default function AuthPage() {
  const [isLoading, setIsLoading] = useState(false);
  const { login, register, user } = useAuth();
  const { toast } = useToast();
  const [location, setLocation] = useLocation();

  // Redirect if already logged in
  if (user) {
    setLocation("/");
    return null;
  }

  const handleLogin = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const email = formData.get("email") as string;
    const password = formData.get("password") as string;

    try {
      await login(email, password);
      toast({
        title: "Welcome back!",
        description: "Successfully logged in to StreamMe Anime.",
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Login Failed",
        description: error instanceof Error ? error.message : "Please check your credentials.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    const formData = new FormData(e.currentTarget);
    const username = formData.get("username") as string;
    const email = formData.get("email") as string;
    const password = formData.get("password") as string;
    const confirmPassword = formData.get("confirmPassword") as string;

    if (password !== confirmPassword) {
      toast({
        title: "Password Mismatch",
        description: "Passwords do not match.",
        variant: "destructive",
      });
      setIsLoading(false);
      return;
    }

    try {
      await register(username, email, password);
      toast({
        title: "Welcome to StreamMe Anime!",
        description: "Account created successfully.",
      });
      setLocation("/");
    } catch (error) {
      toast({
        title: "Registration Failed",
        description: error instanceof Error ? error.message : "Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <NavigationHeader title="Authentication" showBack={false} />
      <div className="flex items-center justify-center p-4 min-h-[calc(100vh-80px)]">
        <div className="w-full max-w-6xl grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
          {/* Left side - Auth forms */}
        <Card className="w-full max-w-md mx-auto bg-black/20 backdrop-blur-md border-purple-500/20">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
              StreamMe Anime
            </CardTitle>
            <CardDescription className="text-gray-300">
              Join the ultimate anime community
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="login" className="w-full">
              <TabsList className="grid w-full grid-cols-2 bg-purple-900/50">
                <TabsTrigger value="login" className="data-[state=active]:bg-purple-600">
                  Login
                </TabsTrigger>
                <TabsTrigger value="register" className="data-[state=active]:bg-purple-600">
                  Sign Up
                </TabsTrigger>
              </TabsList>

              <TabsContent value="login" className="space-y-4">
                <form onSubmit={handleLogin} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-gray-200">Email</Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="Enter your email"
                      required
                      className="bg-black/30 border-purple-500/30 text-white placeholder:text-gray-400"
                      data-testid="input-email"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="password" className="text-gray-200">Password</Label>
                    <Input
                      id="password"
                      name="password"
                      type="password"
                      placeholder="Enter your password"
                      required
                      className="bg-black/30 border-purple-500/30 text-white placeholder:text-gray-400"
                      data-testid="input-password"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                    disabled={isLoading}
                    data-testid="button-login"
                  >
                    {isLoading ? "Signing in..." : "Sign In"}
                  </Button>
                </form>
              </TabsContent>

              <TabsContent value="register" className="space-y-4">
                <form onSubmit={handleRegister} className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="username" className="text-gray-200">Username</Label>
                    <Input
                      id="username"
                      name="username"
                      type="text"
                      placeholder="Choose a username"
                      required
                      className="bg-black/30 border-purple-500/30 text-white placeholder:text-gray-400"
                      data-testid="input-username"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="register-email" className="text-gray-200">Email</Label>
                    <Input
                      id="register-email"
                      name="email"
                      type="email"
                      placeholder="Enter your email"
                      required
                      className="bg-black/30 border-purple-500/30 text-white placeholder:text-gray-400"
                      data-testid="input-register-email"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="register-password" className="text-gray-200">Password</Label>
                    <Input
                      id="register-password"
                      name="password"
                      type="password"
                      placeholder="Create a password"
                      required
                      className="bg-black/30 border-purple-500/30 text-white placeholder:text-gray-400"
                      data-testid="input-register-password"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="confirm-password" className="text-gray-200">Confirm Password</Label>
                    <Input
                      id="confirm-password"
                      name="confirmPassword"
                      type="password"
                      placeholder="Confirm your password"
                      required
                      className="bg-black/30 border-purple-500/30 text-white placeholder:text-gray-400"
                      data-testid="input-confirm-password"
                    />
                  </div>
                  <Button
                    type="submit"
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
                    disabled={isLoading}
                    data-testid="button-register"
                  >
                    {isLoading ? "Creating account..." : "Create Account"}
                  </Button>
                </form>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* Right side - Hero section */}
        <div className="text-center lg:text-left space-y-6">
          <h1 className="text-6xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
            StreamMe Anime
          </h1>
          <p className="text-xl text-gray-300 leading-relaxed">
            Discover, stream, and download your favorite anime content. Join our vibrant community for real-time discussions and AI-powered recommendations.
          </p>
          <div className="grid grid-cols-2 gap-4 text-sm text-gray-400">
            <div className="bg-black/20 backdrop-blur-sm rounded-lg p-4 border border-purple-500/20">
              <h3 className="font-semibold text-purple-400 mb-2">Premium Features</h3>
              <ul className="space-y-1">
                <li>• HD streaming & downloads</li>
                <li>• Real-time chat access</li>
                <li>• AI chatbot interactions</li>
                <li>• Early episode releases</li>
              </ul>
            </div>
            <div className="bg-black/20 backdrop-blur-sm rounded-lg p-4 border border-purple-500/20">
              <h3 className="font-semibold text-pink-400 mb-2">Community</h3>
              <ul className="space-y-1">
                <li>• Live chat discussions</li>
                <li>• Episode reactions</li>
                <li>• Anime recommendations</li>
                <li>• Trending updates</li>
              </ul>
            </div>
          </div>
          <div className="text-sm text-gray-500">
            <p>Contact WhatsApp for unlock code: <span className="font-mono text-pink-400">+2348039896597</span></p>
          </div>
        </div>
        </div>
      </div>
      
      {/* Admin Access Link */}
      <div className="absolute bottom-4 right-4">
        <Button
          variant="outline"
          size="sm"
          onClick={() => setLocation("/admin")}
          className="bg-black/50 border-red-500/50 text-red-400 hover:bg-red-900/20 hover:border-red-400 backdrop-blur-sm"
        >
          🔐 Admin Access
        </Button>
      </div>
    </div>
  );
}