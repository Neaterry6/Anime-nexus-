import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { 
  Bot, 
  Send, 
  Image as ImageIcon, 
  Copy, 
  Download, 
  Trash2, 
  RefreshCw,
  MessageSquare,
  Camera,
  Menu,
  X,
  Loader2,
  User,
  Code,
  Reply,
  Heart,
  Smile,
  ArrowLeft
} from "lucide-react";

interface ChatMessage {
  id: string;
  userId: string | null;
  username: string;
  message: string;
  messageType: string;
  fileUrl: string | null;
  timestamp: Date;
  isBot: boolean;
  aiModel: string | null;
  replyTo?: string;
}

interface AIModel {
  id: string;
  name: string;
  description: string;
  free: boolean;
}

export default function FullScreenChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isConnected, setIsConnected] = useState(false);
  const [selectedModel, setSelectedModel] = useState<string>("gemini");
  const [availableModels, setAvailableModels] = useState<AIModel[]>([]);
  const [userTrials, setUserTrials] = useState(0);
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [isUnlockDialogOpen, setIsUnlockDialogOpen] = useState(false);
  const [unlockCode, setUnlockCode] = useState("");
  const [onlineUsers, setOnlineUsers] = useState(Math.floor(Math.random() * 50) + 15);
  
  const { user, token, verifyUnlockCode } = useAuth();
  const { toast } = useToast();
  const wsRef = useRef<WebSocket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user?.chatAccess && token) {
      connectWebSocket();
      fetchMessages();
      fetchAIModels();
    }
    
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [user?.chatAccess, token]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Simulate online users count changing
  useEffect(() => {
    const interval = setInterval(() => {
      setOnlineUsers(prev => prev + Math.floor(Math.random() * 3) - 1);
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  const connectWebSocket = () => {
    if (!token) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    wsRef.current = new WebSocket(wsUrl);

    wsRef.current.onopen = () => {
      setIsConnected(true);
      wsRef.current?.send(JSON.stringify({ type: 'auth', token }));
    };

    wsRef.current.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === 'new_message') {
        setMessages(prev => [...prev, {
          ...data.data,
          timestamp: new Date(data.data.timestamp)
        }]);
      }
    };

    wsRef.current.onclose = () => {
      setIsConnected(false);
      setTimeout(connectWebSocket, 3000);
    };

    wsRef.current.onerror = (error) => {
      console.error('WebSocket error:', error);
      setIsConnected(false);
    };
  };

  const fetchMessages = async () => {
    try {
      const response = await fetch("/api/chat/messages", {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setMessages(data.map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp)
        })));
      }
    } catch (error) {
      console.error("Error fetching messages:", error);
    }
  };

  const fetchAIModels = async () => {
    try {
      const response = await fetch("/api/ai/models", {
        headers: { Authorization: `Bearer ${token}` }
      });
      if (response.ok) {
        const data = await response.json();
        setAvailableModels(data.models || []);
        setUserTrials(data.userTrials || 0);
      }
    } catch (error) {
      console.error("Error fetching AI models:", error);
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !token) return;

    try {
      const response = await fetch("/api/chat/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          message: newMessage,
          messageType: 'text',
          replyTo: replyTo
        }),
      });

      if (response.ok) {
        setNewMessage("");
        setReplyTo(null);
      } else {
        const error = await response.json();
        toast({
          title: "Message Failed",
          description: error.error,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    }
  };

  const sendAIMessage = async () => {
    if (!newMessage.trim() || !token) return;

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          model: selectedModel,
          prompt: newMessage,
        }),
      });

      if (response.ok) {
        setNewMessage("");
        fetchAIModels();
      } else {
        const error = await response.json();
        toast({
          title: "AI Request Failed",
          description: error.error,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send AI message",
        variant: "destructive",
      });
    }
  };

  const handleUnlockCode = async () => {
    try {
      await verifyUnlockCode(unlockCode);
      setIsUnlockDialogOpen(false);
      setUnlockCode("");
      toast({
        title: "Success!",
        description: "Chat access granted! You can now participate in conversations.",
      });
    } catch (error) {
      toast({
        title: "Invalid Code",
        description: error instanceof Error ? error.message : "Please check your unlock code.",
        variant: "destructive",
      });
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !token) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch("/api/upload", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });

      if (response.ok) {
        const { url } = await response.json();
        
        await fetch("/api/chat/messages", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            message: `Shared a ${file.type.startsWith('image') ? 'image' : file.type.startsWith('video') ? 'video' : 'file'}`,
            messageType: file.type.startsWith('image') ? 'image' : file.type.startsWith('video') ? 'video' : 'file',
            fileUrl: url,
          }),
        });
      }
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "Failed to upload file",
        variant: "destructive",
      });
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const copyMessage = async (content: string) => {
    await navigator.clipboard.writeText(content);
    toast({ title: "Copied!", description: "Message copied to clipboard" });
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  if (!user) {
    return (
      <div className="h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
        <Card className="bg-black/40 border-red-500/50 max-w-md w-full backdrop-blur-lg">
          <CardContent className="p-8 text-center">
            <h3 className="text-xl font-semibold text-white mb-4">Authentication Required</h3>
            <p className="text-gray-300">Please log in to access the chat room.</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!user.chatAccess) {
    return (
      <div className="h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
        <Card className="bg-black/40 border-red-500/50 max-w-md w-full backdrop-blur-lg">
          <CardContent className="p-8 text-center space-y-4">
            <h3 className="text-xl font-semibold text-white mb-4">Chat Access Required</h3>
            <p className="text-gray-300">
              You need chat access to participate in conversations. Use an unlock code or upgrade to premium.
            </p>
            
            <Dialog open={isUnlockDialogOpen} onOpenChange={setIsUnlockDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-gradient-to-r from-purple-600 to-pink-600">
                  <Code className="mr-2 h-4 w-4" />
                  Enter Unlock Code
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-black/90 border-purple-500/20">
                <DialogHeader>
                  <DialogTitle className="text-white">Enter Unlock Code</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <Input
                    placeholder="Enter unlock code"
                    value={unlockCode}
                    onChange={(e) => setUnlockCode(e.target.value)}
                    className="bg-black/30 border-purple-500/30 text-white"
                  />
                  <Button onClick={handleUnlockCode} className="w-full bg-gradient-to-r from-purple-600 to-pink-600">
                    Verify Code
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            
            <p className="text-sm text-gray-500">
              Contact WhatsApp for unlock code: <span className="font-mono text-pink-400">+2348039896597</span>
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 text-white flex flex-col overflow-hidden">
      {/* Header */}
      <div className="bg-black/50 backdrop-blur-lg border-b border-white/10 p-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="sm" onClick={() => window.history.back()}>
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
          <div>
            <h1 className="text-xl font-bold">StreamMe Community Chat</h1>
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <Badge variant={isConnected ? "default" : "destructive"} className="text-xs">
                {isConnected ? `Online (${onlineUsers})` : "Disconnected"}
              </Badge>
              <span>Active community chat room</span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Avatar className="h-8 w-8">
            <AvatarImage src="https://via.placeholder.com/32" />
            <AvatarFallback>
              {user.username[0].toUpperCase()}
            </AvatarFallback>
          </Avatar>
          <span className="text-sm font-medium">{user.username}</span>
        </div>
      </div>

      {/* Chat Messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4 max-w-4xl mx-auto">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.isBot ? 'justify-start' : message.userId === user.id ? 'justify-end' : 'justify-start'}`}
            >
              {!message.isBot && message.userId !== user.id && (
                <Avatar className="h-8 w-8 shrink-0">
                  <AvatarFallback className="bg-purple-600 text-xs">
                    {message.username[0].toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              )}
              
              {message.isBot && (
                <Avatar className="h-8 w-8 shrink-0">
                  <AvatarFallback className="bg-green-600">
                    <Bot className="h-4 w-4" />
                  </AvatarFallback>
                </Avatar>
              )}
              
              <div className={`rounded-lg p-3 max-w-[70%] ${
                message.isBot 
                  ? 'bg-green-600/20 border border-green-500/30' 
                  : message.userId === user.id 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-black/40 border border-white/10'
              }`}>
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-xs font-semibold">
                    {message.isBot ? `AI (${message.aiModel})` : message.username}
                  </span>
                  <span className="text-xs text-gray-400">
                    {formatTime(message.timestamp)}
                  </span>
                </div>
                
                {message.fileUrl && (
                  <div className="mb-2">
                    {message.messageType === 'image' ? (
                      <img 
                        src={message.fileUrl} 
                        alt="Shared image" 
                        className="max-w-full h-auto rounded-lg"
                      />
                    ) : (
                      <a 
                        href={message.fileUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-400 hover:underline"
                      >
                        📁 {message.message}
                      </a>
                    )}
                  </div>
                )}
                
                <div className="whitespace-pre-wrap text-sm">
                  {message.message}
                </div>
                
                <div className="flex items-center gap-2 mt-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => copyMessage(message.message)}
                    className="h-6 text-xs opacity-70 hover:opacity-100"
                  >
                    <Copy className="h-3 w-3" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => setReplyTo(message.id)}
                    className="h-6 text-xs opacity-70 hover:opacity-100"
                  >
                    <Reply className="h-3 w-3" />
                  </Button>
                </div>
              </div>

              {message.userId === user.id && (
                <Avatar className="h-8 w-8 shrink-0">
                  <AvatarFallback className="bg-blue-600">
                    {user.username[0].toUpperCase()}
                  </AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* Input Area */}
      <div className="bg-black/50 backdrop-blur-lg border-t border-white/10 p-4">
        <div className="max-w-4xl mx-auto">
          {replyTo && (
            <div className="mb-2 p-2 bg-blue-600/20 rounded-lg text-sm flex items-center justify-between">
              <span>Replying to message...</span>
              <Button variant="ghost" size="sm" onClick={() => setReplyTo(null)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          )}
          
          <div className="flex gap-2">
            <Textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              className="flex-1 bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 resize-none"
              rows={1}
            />
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              className="border-gray-600 text-gray-300 hover:bg-gray-700"
            >
              <Camera className="h-4 w-4" />
            </Button>
            
            <Button
              onClick={sendMessage}
              className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
            >
              <Send className="h-4 w-4" />
            </Button>
            
            <Button
              onClick={sendAIMessage}
              className="bg-gradient-to-r from-green-600 to-teal-600 hover:from-green-700 hover:to-teal-700"
            >
              <Bot className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="flex items-center gap-4 mt-2 text-xs text-gray-400">
            <span>Press Enter to send</span>
            <Select value={selectedModel} onValueChange={setSelectedModel}>
              <SelectTrigger className="w-32 h-6 text-xs bg-gray-800/50 border-gray-600">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-gray-800 border-gray-600">
                {availableModels.map((model) => (
                  <SelectItem key={model.id} value={model.id} className="text-white">
                    {model.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <span>AI Trials: {userTrials}</span>
          </div>
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*,video/*,audio/*"
        onChange={handleFileUpload}
        className="hidden"
      />
    </div>
  );
}