import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import NavigationHeader from "@/components/navigation-header";
import { 
  Bot, 
  Send, 
  Sparkles, 
  Image as ImageIcon, 
  Copy, 
  Download, 
  Trash2, 
  RefreshCw,
  MessageSquare,
  Zap,
  Brain,
  Palette,
  Camera,
  Menu,
  X,
  Loader2,
  User
} from "lucide-react";

interface ChatMessage {
  id: string;
  type: 'user' | 'bot';
  content: string;
  model?: string;
  timestamp: Date;
  imageUrl?: string;
  isLoading?: boolean;
  username?: string;
}

interface AIModel {
  id: string;
  name: string;
  description: string;
  free: boolean;
  icon: React.ReactNode;
  color: string;
}

const AI_MODELS: AIModel[] = [
  {
    id: "gpt4",
    name: "GPT-4",
    description: "Engage in advanced conversations and get answers to complex questions.",
    free: false,
    icon: <Brain className="h-4 w-4" />,
    color: "text-blue-400"
  },
  {
    id: "waifu",
    name: "Waifu",
    description: "Generate unique anime-style waifu images.",
    free: false,
    icon: <Sparkles className="h-4 w-4" />,
    color: "text-pink-400"
  },
  {
    id: "ghibli",
    name: "Photo to Ghibli",
    description: "Transform your images into Studio Ghibli-inspired art.",
    free: false,
    icon: <Sparkles className="h-4 w-4" />,
    color: "text-yellow-400"
  },
  {
    id: "pinterest",
    name: "Pinterest",
    description: "Search for inspirational images based on your query.",
    free: false,
    icon: <ImageIcon className="h-4 w-4" />,
    color: "text-red-400"
  },
  {
    id: "unsplash",
    name: "Unsplash",
    description: "Discover high-quality photos from Unsplash.",
    free: false,
    icon: <ImageIcon className="h-4 w-4" />,
    color: "text-green-400"
  },
  {
    id: "createai",
    name: "CreateAI",
    description: "Create stunning images from text descriptions.",
    free: false,
    icon: <Palette className="h-4 w-4" />,
    color: "text-purple-400"
  }
];

export default function ImprovedChatbot() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [currentMessage, setCurrentMessage] = useState("");
  const [selectedModel, setSelectedModel] = useState("gpt4");
  const [isLoading, setIsLoading] = useState(false);
  const [showSidebar, setShowSidebar] = useState(false);
  const [showUnlockDialog, setShowUnlockDialog] = useState(false);
  const [unlockCode, setUnlockCode] = useState("");
  const [isSubmittingCode, setIsSubmittingCode] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [sessionId, setSessionId] = useState<string>("");
  
  const { user, token } = useAuth();
  const { toast } = useToast();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  useEffect(() => {
    // Generate session ID for this chat session
    const generateSessionId = () => {
      return 'sid_' + Math.random().toString(36).substr(2, 9) + Date.now().toString(36);
    };
    setSessionId(generateSessionId());

    // Load conversation from localStorage
    const savedMessages = localStorage.getItem('improved-chatbot-messages');
    if (savedMessages) {
      try {
        const parsed = JSON.parse(savedMessages);
        setMessages(parsed.map((msg: any) => ({
          ...msg,
          timestamp: new Date(msg.timestamp)
        })));
      } catch (error) {
        console.error('Error loading saved messages:', error);
      }
    }

    // Welcome message
    if (user?.chatAccess) {
      const welcomeMessage: ChatMessage = {
        id: Date.now().toString(),
        type: 'bot',
        content: `👋 Welcome back, ${user.username || 'User'}! I'm your AI assistant powered by ${AI_MODELS.find(m => m.id === selectedModel)?.name}. Ready to chat?`,
        model: selectedModel,
        timestamp: new Date()
      };
      setMessages([welcomeMessage]);
    }
  }, [user, selectedModel]);

  useEffect(() => {
    // Save conversation to localStorage
    if (messages.length > 0) {
      localStorage.setItem('improved-chatbot-messages', JSON.stringify(messages));
    }
  }, [messages]);

  const handleUnlockCode = async () => {
    if (!unlockCode.trim()) return;
    
    setIsSubmittingCode(true);
    try {
      const response = await fetch('/api/unlock-code', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({ code: unlockCode }),
      });

      const data = await response.json();
      
      if (response.ok) {
        toast({
          title: "Success!",
          description: "Chat access granted! You can now use the AI chatbot.",
        });
        setShowUnlockDialog(false);
        setUnlockCode("");
        window.location.reload();
      } else {
        toast({
          title: "Invalid Code",
          description: data.error || "Please check your unlock code and try again.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to verify unlock code. Please try again.",
        variant: "destructive",
      });
    }
    setIsSubmittingCode(false);
  };

  const handleImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setImageFile(file);
      toast({
        title: "Image Selected",
        description: `${file.name} ready to upload`,
      });
    }
  };

  const sendMessage = async () => {
    if (!currentMessage.trim() && !imageFile) return;
    
    if (!user?.chatAccess) {
      setShowUnlockDialog(true);
      return;
    }

    let messageContent = currentMessage;
    let imageUrl = '';

    // Handle image upload if exists
    if (imageFile) {
      const formData = new FormData();
      formData.append('file', imageFile);

      try {
        const uploadResponse = await fetch('/api/upload', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
          },
          body: formData,
        });

        if (uploadResponse.ok) {
          const uploadData = await uploadResponse.json();
          imageUrl = uploadData.url;
          messageContent = messageContent || "Analyze this image";
        } else {
          toast({
            title: "Upload Failed",
            description: "Failed to upload image. Please try again.",
            variant: "destructive"
          });
          return;
        }
      } catch (error) {
        toast({
          title: "Upload Error",
          description: "Error uploading image. Please try again.",
          variant: "destructive"
        });
        return;
      }
    }

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: messageContent,
      timestamp: new Date(),
      imageUrl: imageUrl || undefined,
      username: user?.username || 'User'
    };

    setMessages(prev => [...prev, userMessage]);
    setCurrentMessage("");
    setImageFile(null);
    setIsLoading(true);

    // Add loading message
    const loadingMessage: ChatMessage = {
      id: (Date.now() + 1).toString(),
      type: 'bot',
      content: "Thinking...",
      model: selectedModel,
      timestamp: new Date(),
      isLoading: true
    };
    setMessages(prev => [...prev, loadingMessage]);

    try {
      const response = await fetch('/api/ai/chat', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          model: selectedModel,
          prompt: messageContent,
          imageUrl: imageUrl || undefined,
          sessionId: sessionId
        }),
      });

      const data = await response.json();

      if (response.ok) {
        // Remove loading message and add actual response
        setMessages(prev => {
          const filtered = prev.filter(msg => !msg.isLoading);
          const botMessage: ChatMessage = {
            id: Date.now().toString(),
            type: 'bot',
            content: data.response,
            model: selectedModel,
            timestamp: new Date(),
            imageUrl: data.imageUrl || undefined
          };
          return [...filtered, botMessage];
        });
        
        toast({
          title: "Response received",
          description: `${AI_MODELS.find(m => m.id === selectedModel)?.name} responded successfully`
        });
      } else {
        // Remove loading message and show error
        setMessages(prev => prev.filter(msg => !msg.isLoading));
        throw new Error(data.error || 'Failed to get AI response');
      }
    } catch (error) {
      setMessages(prev => prev.filter(msg => !msg.isLoading));
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to send message",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const clearConversation = () => {
    setMessages([]);
    localStorage.removeItem('improved-chatbot-messages');
    toast({ title: "Conversation cleared", description: "All messages have been removed" });
  };

  const copyMessage = async (content: string) => {
    await navigator.clipboard.writeText(content);
    toast({ title: "Copied!", description: "Message copied to clipboard" });
  };

  const switchModel = (modelId: string) => {
    setSelectedModel(modelId);
    setShowSidebar(false);
    const modelName = AI_MODELS.find(m => m.id === modelId)?.name;
    toast({
      title: "Model Switched",
      description: `Now using ${modelName}`,
    });
  };

  if (!user?.chatAccess) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900">
        <NavigationHeader title="StreamMe AI Chatbot" />
        <div className="flex items-center justify-center p-4 min-h-[calc(100vh-80px)]">
          <Card className="bg-black/40 border-red-500/50 max-w-md w-full backdrop-blur-lg">
            <CardHeader className="text-center">
              <Bot className="h-16 w-16 mx-auto mb-4 text-red-400" />
              <CardTitle className="text-white text-2xl font-bold">AI Chat Access Required</CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <p className="text-gray-300 mb-4">
                You need chat access to use the AI chatbot. Please enter your unlock code.
              </p>
              <Button onClick={() => setShowUnlockDialog(true)} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700">
                Enter Unlock Code
              </Button>
              <Badge variant="outline" className="border-red-500 text-red-400">
                Premium Feature
              </Badge>
            </CardContent>
          </Card>
        </div>

        {/* Unlock Code Dialog */}
        <Dialog open={showUnlockDialog} onOpenChange={setShowUnlockDialog}>
          <DialogContent className="bg-black/90 border-purple-500/50 backdrop-blur-lg">
            <DialogHeader>
              <DialogTitle className="text-white">Enter Unlock Code</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input
                type="text"
                placeholder="Enter your unlock code"
                value={unlockCode}
                onChange={(e) => setUnlockCode(e.target.value)}
                className="bg-gray-800 border-gray-600 text-white"
              />
              <Button 
                onClick={handleUnlockCode}
                disabled={isSubmittingCode}
                className="w-full bg-gradient-to-r from-blue-600 to-purple-600"
              >
                {isSubmittingCode ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Verifying...
                  </>
                ) : (
                  "Unlock Chat Access"
                )}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

  const selectedModelData = AI_MODELS.find(m => m.id === selectedModel);

  return (
    <div className="h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-indigo-900 text-white relative overflow-hidden">
      {/* Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-50 w-72 bg-black/90 backdrop-blur-lg border-r border-white/10 transform transition-transform duration-300 ${showSidebar ? 'translate-x-0' : '-translate-x-full'}`}>
        <div className="p-6 h-full flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center">
              <Avatar className="h-12 w-12 mr-3">
                <AvatarImage src="https://via.placeholder.com/48" />
                <AvatarFallback>
                  <User className="h-6 w-6" />
                </AvatarFallback>
              </Avatar>
              <span className="font-bold text-blue-400">{user?.username || 'User'}</span>
            </div>
            <Button variant="ghost" size="sm" onClick={() => setShowSidebar(false)}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          <nav className="flex-1 space-y-2">
            <h3 className="text-lg text-gray-200 mb-4 text-center font-bold">AI Models</h3>
            {AI_MODELS.map((model) => (
              <button
                key={model.id}
                onClick={() => switchModel(model.id)}
                className={`w-full p-3 rounded-lg border transition-all text-left ${
                  selectedModel === model.id
                    ? 'border-purple-500 bg-purple-500/20'
                    : 'border-gray-600 bg-black/30 hover:border-purple-400'
                }`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <span className={model.color}>{model.icon}</span>
                  <span className="font-semibold text-white">{model.name}</span>
                </div>
                <p className="text-xs text-gray-400">{model.description}</p>
              </button>
            ))}
          </nav>

          <Button 
            onClick={clearConversation}
            variant="outline" 
            className="mt-4 border-red-500 text-red-400 hover:bg-red-500/20"
          >
            <Trash2 className="h-4 w-4 mr-2" />
            Clear Chat
          </Button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex flex-col h-screen">
        {/* Header */}
        <div className="flex items-center justify-between p-4 bg-black/50 backdrop-blur-lg border-b border-white/10">
          <Button variant="ghost" size="sm" onClick={() => setShowSidebar(true)}>
            <Menu className="h-5 w-5" />
          </Button>
          
          <div className="text-center">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-pink-400 to-purple-400 bg-clip-text text-transparent">
              StreamMe AI Chatbot
            </h1>
            <p className="text-sm text-gray-400">
              Powered by {selectedModelData?.name}
            </p>
          </div>

          <div className="w-10" /> {/* Spacer */}
        </div>

        {/* Chat Messages */}
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4 max-w-4xl mx-auto">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {message.type === 'bot' && (
                  <Avatar className="h-8 w-8 shrink-0">
                    <AvatarFallback className="bg-purple-500">
                      <Bot className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                )}
                
                <div className={`rounded-lg p-4 max-w-[80%] ${
                  message.type === 'user' 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-black/40 border border-white/10 text-gray-100'
                }`}>
                  {message.type === 'user' && message.username && (
                    <div className="text-xs text-blue-200 mb-1 font-semibold">
                      {message.username}
                    </div>
                  )}
                  {message.imageUrl && (
                    <img 
                      src={message.imageUrl} 
                      alt="Uploaded content" 
                      className="max-w-full h-auto rounded-lg mb-2"
                    />
                  )}
                  <div className="whitespace-pre-wrap">
                    {message.isLoading ? (
                      <div className="flex items-center gap-2">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        {message.content}
                      </div>
                    ) : (
                      message.content
                    )}
                  </div>
                  {message.type === 'bot' && !message.isLoading && (
                    <div className="flex items-center gap-2 mt-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => copyMessage(message.content)}
                        className="h-6 text-xs"
                      >
                        <Copy className="h-3 w-3" />
                      </Button>
                      <span className="text-xs text-gray-400">
                        {message.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                  )}
                </div>

                {message.type === 'user' && (
                  <Avatar className="h-8 w-8 shrink-0">
                    <AvatarImage src="https://via.placeholder.com/32" />
                    <AvatarFallback>
                      <User className="h-4 w-4" />
                    </AvatarFallback>
                  </Avatar>
                )}
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="p-4 bg-black/50 backdrop-blur-lg border-t border-white/10">
          <div className="max-w-4xl mx-auto">
            <div className="flex gap-2">
              <Textarea
                ref={inputRef}
                value={currentMessage}
                onChange={(e) => setCurrentMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Type your message..."
                className="flex-1 bg-gray-800/50 border-gray-600 text-white placeholder-gray-400 resize-none"
                rows={1}
              />
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                <Camera className="h-4 w-4" />
              </Button>
              
              <Button
                onClick={sendMessage}
                disabled={isLoading}
                className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700"
              >
                {isLoading ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Send className="h-4 w-4" />
                )}
              </Button>
            </div>
            
            {imageFile && (
              <div className="mt-2 text-sm text-gray-400">
                Image selected: {imageFile.name}
              </div>
            )}
          </div>
        </div>
      </div>

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleImageUpload}
        className="hidden"
      />
    </div>
  );
}