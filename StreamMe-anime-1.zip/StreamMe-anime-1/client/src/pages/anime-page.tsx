import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Search, Download, ArrowLeft, Loader2 } from 'lucide-react';
import NavigationHeader from '@/components/navigation-header';
import { useAuth } from '@/hooks/use-auth';

interface SearchResult {
  title: string;
  link: string;
  image: string;
  type: string;
  season: string;
  description: string;
}

interface AnimeDetailResponse {
  title: string;
  image: string;
  releaseSeason?: string;
  rating?: {
    value: string;
    count: string;
  };
  credit?: string;
  encode?: string;
  genres?: string[];
  synopsis: string;
  episodes?: {
    title: string;
    link: string;
  }[];
  trailer?: string;
}

interface EpisodeDownloadResponse {
  title: string;
  image: string;
  info: {
    season: string;
    rating: string;
    voters: string;
    credit: string;
    encode: string;
    genre: string[];
  };
  synopsis: string;
  downloads: {
    resolution: string;
    links: {
      source: string;
      url: string;
    }[];
  }[];
}

export default function AnimePage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<SearchResult[]>([]);
  const [trendingAnime, setTrendingAnime] = useState<SearchResult[]>([]);
  const [subbedAnime, setSubbedAnime] = useState<SearchResult[]>([]);
  const [selectedAnime, setSelectedAnime] = useState<AnimeDetailResponse | null>(null);
  const [selectedEpisodeDownloads, setSelectedEpisodeDownloads] = useState<EpisodeDownloadResponse | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [isLoadingTrending, setIsLoadingTrending] = useState(true);
  const [isLoadingSubbed, setIsLoadingSubbed] = useState(true);
  const [isLoadingDetails, setIsLoadingDetails] = useState(false);
  const [isLoadingEpisodeDownloads, setIsLoadingEpisodeDownloads] = useState(false);
  const { toast } = useToast();
  const { user } = useAuth();

  // Load trending anime
  const loadTrendingAnime = async () => {
    setIsLoadingTrending(true);
    try {
      const response = await fetch('/api/anime/trending');
      const data = await response.json();
      
      if (response.ok && data.status && data.result) {
        setTrendingAnime(data.result);
      } else {
        toast({
          title: "Failed to Load Trending",
          description: "Unable to load trending anime.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Trending fetch error:', error);
      toast({
        title: "Failed to Load Trending",
        description: "Unable to load trending anime.",
        variant: "destructive"
      });
    } finally {
      setIsLoadingTrending(false);
    }
  };

  // Load subbed anime
  const loadSubbedAnime = async () => {
    setIsLoadingSubbed(true);
    try {
      const response = await fetch('/api/anime/subbed');
      const data = await response.json();
      
      if (response.ok && data.status && data.result) {
        setSubbedAnime(data.result);
      } else {
        toast({
          title: "Failed to Load Subbed",
          description: "Unable to load subbed anime.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Subbed fetch error:', error);
      toast({
        title: "Failed to Load Subbed",
        description: "Unable to load subbed anime.",
        variant: "destructive"
      });
    } finally {
      setIsLoadingSubbed(false);
    }
  };

  // Search anime
  const searchAnime = async (query: string) => {
    if (!query.trim()) {
      setSearchResults([]);
      return;
    }

    setIsSearching(true);
    try {
      const response = await fetch(`/api/anime/search?q=${encodeURIComponent(query.trim())}`);
      const data = await response.json();
      
      if (response.ok && data.status && data.result) {
        setSearchResults(data.result);
      } else {
        toast({
          title: "Search Failed",
          description: "Unable to search anime. Please try again.",
          variant: "destructive"
        });
        setSearchResults([]);
      }
    } catch (error) {
      console.error('Search error:', error);
      toast({
        title: "Search Failed",
        description: "Unable to search anime. Please try again.",
        variant: "destructive"
      });
      setSearchResults([]);
    } finally {
      setIsSearching(false);
    }
  };

  // Get anime details (episodes list)
  const getAnimeDetails = async (animeUrl: string) => {
    setIsLoadingDetails(true);
    try {
      const response = await fetch(`/api/anime/detail?url=${encodeURIComponent(animeUrl)}`);
      const data = await response.json();
      
      if (response.ok && data.status && data.result) {
        setSelectedAnime(data.result as AnimeDetailResponse);
      } else {
        toast({
          title: "Failed to Load Details",
          description: "Unable to load anime details. Please try again.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Detail fetch error:', error);
      toast({
        title: "Failed to Load Details",
        description: "Unable to load anime details. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoadingDetails(false);
    }
  };

  // Get episode download links
  const getEpisodeDownloads = async (episodeUrl: string) => {
    setIsLoadingEpisodeDownloads(true);
    try {
      const response = await fetch(`/api/anime/download-episode?url=${encodeURIComponent(episodeUrl)}`);
      const data = await response.json();
      
      if (response.ok && data.status && data.result) {
        setSelectedEpisodeDownloads(data.result);
      } else {
        toast({
          title: "No Download Links",
          description: "No download links found for this episode.",
          variant: "destructive"
        });
      }
    } catch (error) {
      console.error('Episode download error:', error);
      toast({
        title: "Failed to Load Downloads",
        description: "Unable to load episode downloads. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsLoadingEpisodeDownloads(false);
    }
  };

  // Handle direct download link
  const handleDirectDownload = (link: { source: string; url: string }) => {
    window.open(link.url, '_blank');
    toast({
      title: "Download Started",
      description: `Opening ${link.source} download link in a new tab.`,
    });
  };

  // Back to main view
  const handleBackToMain = () => {
    setSelectedAnime(null);
    setSelectedEpisodeDownloads(null);
  };

  // Back to anime details
  const handleBackToAnimeDetails = () => {
    setSelectedEpisodeDownloads(null);
  };

  // Handle search input changes with debouncing
  useEffect(() => {
    const timer = setTimeout(() => {
      if (searchQuery) {
        searchAnime(searchQuery);
      } else {
        setSearchResults([]);
      }
    }, 500);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Load trending and subbed anime on component mount
  useEffect(() => {
    loadTrendingAnime();
    loadSubbedAnime();
  }, []);

  // Anime Card Component
  const AnimeCard = ({ anime, onSelect }: { anime: SearchResult; onSelect: (url: string) => void }) => (
    <Card 
      className="bg-black/20 border border-purple-500/20 hover:border-purple-500/50 transform hover:scale-105 transition-all duration-300 group overflow-hidden cursor-pointer"
      onClick={() => onSelect(anime.link)}
    >
      <div className="relative">
        <img 
          src={anime.image} 
          alt={anime.title}
          className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500"
          onError={(e) => {
            e.currentTarget.src = "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=400&h=600&fit=crop";
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        <Badge className="absolute top-3 right-3 bg-purple-600">
          {anime.type}
        </Badge>
      </div>
      <CardContent className="p-4">
        <h3 className="text-lg font-semibold mb-2 text-white group-hover:text-purple-400 transition-colors line-clamp-2">
          {anime.title}
        </h3>
        <p className="text-gray-400 text-sm mb-3 line-clamp-3">
          {anime.description}
        </p>
        <Button
          size="sm"
          className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white border-0"
        >
          View Episodes
        </Button>
      </CardContent>
    </Card>
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900">
      <NavigationHeader />
      
      <div className="container mx-auto px-4 py-8 pt-24">
        {/* Episode Download View */}
        {selectedEpisodeDownloads && (
          <div>
            <div className="flex items-center gap-4 mb-6">
              <Button 
                onClick={handleBackToAnimeDetails}
                variant="ghost" 
                className="text-white hover:bg-white/10"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Episodes
              </Button>
            </div>

            <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20">
              <div className="flex flex-col md:flex-row gap-6 mb-6">
                <img 
                  src={selectedEpisodeDownloads.image} 
                  alt={selectedEpisodeDownloads.title}
                  className="w-full md:w-48 h-64 md:h-72 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-white mb-2">{selectedEpisodeDownloads.title}</h2>
                  <div className="grid grid-cols-2 gap-4 text-sm text-gray-300 mb-4">
                    <div>
                      <span className="text-purple-400">Season:</span>
                      <span className="ml-2">{selectedEpisodeDownloads.info.season}</span>
                    </div>
                    <div>
                      <span className="text-purple-400">Rating:</span>
                      <span className="ml-2">{selectedEpisodeDownloads.info.rating}/10 ({selectedEpisodeDownloads.info.voters} votes)</span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-purple-400">Genres:</span>
                      <span className="ml-2">
                        {selectedEpisodeDownloads.info.genre?.map((genre, index) => (
                          <span key={index} className="mr-2 bg-purple-600/30 px-2 py-1 rounded text-xs">
                            {genre}
                          </span>
                        ))}
                      </span>
                    </div>
                  </div>
                  <p className="text-gray-300 text-sm">{selectedEpisodeDownloads.synopsis}</p>
                </div>
              </div>

              {/* Download Options */}
              <div className="space-y-4">
                <h3 className="text-xl font-bold text-white mb-4">Download Options</h3>
                {selectedEpisodeDownloads.downloads?.map((download, index) => (
                  <div key={index} className="bg-black/20 rounded-lg p-4 border border-gray-600">
                    <div className="flex items-center justify-between mb-3">
                      <span className="text-lg font-semibold text-purple-400">{download.resolution}</span>
                      <Badge variant="secondary" className="bg-purple-600/20 text-purple-300">
                        {download.links?.length || 0} sources
                      </Badge>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                      {download.links?.map((link, linkIndex) => (
                        <Button
                          key={linkIndex}
                          onClick={() => handleDirectDownload(link)}
                          variant="outline"
                          className="bg-black/30 border-gray-600 text-white hover:bg-purple-600/20 hover:border-purple-500 transition-all duration-200"
                        >
                          <Download className="h-4 w-4 mr-2" />
                          {link.source}
                        </Button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Anime Details View (Episode Selection) */}
        {selectedAnime && !selectedEpisodeDownloads && (
          <div>
            <div className="flex items-center gap-4 mb-6">
              <Button 
                onClick={handleBackToMain}
                variant="ghost" 
                className="text-white hover:bg-white/10"
              >
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Browse
              </Button>
            </div>

            <div className="bg-white/10 backdrop-blur-md rounded-xl p-6 border border-white/20 mb-6">
              <div className="flex flex-col md:flex-row gap-6 mb-6">
                <img 
                  src={selectedAnime.image} 
                  alt={selectedAnime.title}
                  className="w-full md:w-48 h-64 md:h-72 object-cover rounded-lg"
                />
                <div className="flex-1">
                  <h2 className="text-2xl font-bold text-white mb-2">{selectedAnime.title}</h2>
                  <div className="grid grid-cols-2 gap-4 text-sm text-gray-300 mb-4">
                    <div>
                      <span className="text-purple-400">Season:</span>
                      <span className="ml-2">{selectedAnime.releaseSeason}</span>
                    </div>
                    <div>
                      <span className="text-purple-400">Rating:</span>
                      <span className="ml-2">{selectedAnime.rating?.value}/10 ({selectedAnime.rating?.count} votes)</span>
                    </div>
                    <div className="col-span-2">
                      <span className="text-purple-400">Genres:</span>
                      <span className="ml-2">
                        {selectedAnime.genres?.map((genre, index) => (
                          <span key={index} className="mr-2 bg-purple-600/30 px-2 py-1 rounded text-xs">
                            {genre}
                          </span>
                        ))}
                      </span>
                    </div>
                  </div>
                  <p className="text-gray-300 text-sm">{selectedAnime.synopsis}</p>
                </div>
              </div>

              {/* Episode List */}
              <div>
                <h3 className="text-xl font-bold text-white mb-4">Select Episode to Download</h3>
                {isLoadingDetails ? (
                  <div className="flex justify-center py-8">
                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
                  </div>
                ) : selectedAnime.episodes && selectedAnime.episodes.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {selectedAnime.episodes.map((episode, index) => (
                      <Button
                        key={index}
                        onClick={() => getEpisodeDownloads(episode.link)}
                        variant="outline"
                        disabled={isLoadingEpisodeDownloads}
                        className="bg-black/30 border-gray-600 text-white hover:bg-purple-600/20 hover:border-purple-500 transition-all duration-200 p-4 h-auto flex flex-col items-start"
                      >
                        <span className="font-semibold mb-1">{episode.title}</span>
                        <span className="text-xs text-gray-400">Click to view download options</span>
                        {isLoadingEpisodeDownloads && (
                          <Loader2 className="h-4 w-4 animate-spin mt-2" />
                        )}
                      </Button>
                    ))}
                  </div>
                ) : (
                  <p className="text-gray-400 text-center py-8">No episodes available for this anime.</p>
                )}
              </div>
            </div>
          </div>
        )}

        {/* Main Browse View */}
        {!selectedAnime && (
          <div>
            {/* Search Header */}
            <div className="text-center mb-8">
              <h1 className="text-4xl font-bold text-white mb-4">
                <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  Anime Search & Download
                </span>
              </h1>
              <p className="text-gray-300 text-lg">
                Search and download your favorite anime with multiple quality options
              </p>
            </div>

            {/* Search Bar */}
            <div className="max-w-2xl mx-auto mb-8">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                <Input
                  type="text"
                  placeholder="Search for anime (e.g., Solo Leveling, One Piece)..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 pr-4 py-3 w-full bg-white/10 border-gray-600 text-white placeholder-gray-400 focus:ring-2 focus:ring-purple-500 focus:border-transparent rounded-lg"
                />
                {isSearching && (
                  <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
                    <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-purple-400"></div>
                  </div>
                )}
              </div>
            </div>

            {/* Search Results */}
            {searchResults.length > 0 && (
              <div className="mb-12">
                <h2 className="text-2xl font-bold text-white mb-6">
                  Search Results ({searchResults.length} found)
                </h2>
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {searchResults.map((anime, index) => (
                    <AnimeCard key={index} anime={anime} onSelect={getAnimeDetails} />
                  ))}
                </div>
              </div>
            )}

            {/* Trending Anime Section */}
            <div className="mb-12">
              <h2 className="text-2xl font-bold text-white mb-6">
                🔥 Trending Anime
              </h2>
              {isLoadingTrending ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {trendingAnime.map((anime, index) => (
                    <AnimeCard key={index} anime={anime} onSelect={getAnimeDetails} />
                  ))}
                </div>
              )}
            </div>

            {/* Subbed Anime Section */}
            <div className="mb-12">
              <h2 className="text-2xl font-bold text-white mb-6">
                📺 Popular Subbed Anime
              </h2>
              {isLoadingSubbed ? (
                <div className="flex justify-center py-8">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-400"></div>
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                  {subbedAnime.map((anime, index) => (
                    <AnimeCard key={index} anime={anime} onSelect={getAnimeDetails} />
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}