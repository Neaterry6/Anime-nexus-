import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import Home from "@/pages/home";
import AuthPage from "@/pages/auth-page";
import EnhancedSettingsPage from "@/pages/enhanced-settings";
import ProfilePage from "@/pages/profile-page";
import MoviesPage from "@/pages/movies-page";
import ChatbotPage from "@/pages/chatbot-page";
import ImprovedChatbot from "@/pages/improved-chatbot";
import FullScreenChat from "@/pages/full-screen-chat";
import AnimePage from "@/pages/anime-page";
import AnimeDetailPage from "@/pages/anime-detail";
import MangaPage from "@/pages/MangaPage";
import FAQPage from "@/pages/faq-page";
import YouTubePage from "@/pages/youtube-page";
import NotFound from "@/pages/not-found";
import AdminPanel from "@/pages/admin-panel";
import AdminLogin from "@/pages/admin-login";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/auth" component={AuthPage} />
      <Route path="/settings" component={EnhancedSettingsPage} />
      <Route path="/profile" component={ProfilePage} />
      <Route path="/movies" component={MoviesPage} />
      <Route path="/anime" component={AnimePage} />
      <Route path="/anime/:animeUrl" component={AnimeDetailPage} />
      <Route path="/manga" component={MangaPage} />
      <Route path="/youtube" component={YouTubePage} />
      <Route path="/chatbot" component={FullScreenChat} />
      <Route path="/ai-chat" component={ImprovedChatbot} />
      <Route path="/faq" component={FAQPage} />
      <Route path="/admin-login" component={AdminLogin} />
      <Route path="/admin-panel" component={AdminPanel} />
      <Route path="/admin" component={AdminLogin} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
