import { useState } from "react";
import { Search, PlayCircle, User, Menu, X, Settings, LogOut } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { useAuth } from "@/hooks/use-auth";
import { useLocation } from "wouter";

export default function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, logout } = useAuth();
  const [location, setLocation] = useLocation();

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  const handleLogout = () => {
    logout();
    setLocation("/auth");
  };

  const getInitials = (username: string) => {
    return username.slice(0, 2).toUpperCase();
  };

  return (
    <>
      <header className="bg-anime-slate/80 backdrop-blur-md border-b border-purple-500/30 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-8">
              <div className="flex items-center space-x-2">
                <PlayCircle className="text-purple-500 w-8 h-8" />
                <h1 className="text-2xl font-bold anime-gradient-text">AnimeVault</h1>
              </div>
              <nav className="hidden md:flex space-x-6">
                <button 
                  onClick={() => scrollToSection('home')}
                  className="text-white hover:text-purple-500 transition-colors duration-300"
                  data-testid="nav-home"
                >
                  Home
                </button>
                <button 
                  onClick={() => scrollToSection('catalog')}
                  className="text-white hover:text-purple-500 transition-colors duration-300"
                  data-testid="nav-catalog"
                >
                  Catalog
                </button>
                <button 
                  onClick={() => setLocation('/movies')}
                  className="text-white hover:text-purple-500 transition-colors duration-300"
                >
                  Movies
                </button>
                <button 
                  onClick={() => setLocation('/youtube')}
                  className="text-white hover:text-purple-500 transition-colors duration-300"
                  data-testid="nav-youtube"
                >
                  YouTube
                </button>
                <button 
                  onClick={() => setLocation('/manga')}
                  className="text-white hover:text-purple-500 transition-colors duration-300"
                  data-testid="nav-manga"
                >
                  Manga
                </button>
                <button 
                  onClick={() => scrollToSection('chat')}
                  className="text-white hover:text-purple-500 transition-colors duration-300"
                  data-testid="nav-chat"
                >
                  Chat
                </button>
                <button 
                  onClick={() => scrollToSection('trending')}
                  className="text-white hover:text-purple-500 transition-colors duration-300"
                  data-testid="nav-trending"
                >
                  Trending
                </button>
                <button 
                  onClick={() => setLocation('/faq')}
                  className="text-white hover:text-purple-500 transition-colors duration-300"
                >
                  FAQ
                </button>
              </nav>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative hidden lg:block">
                <Input 
                  type="text" 
                  placeholder="Search anime..." 
                  className="bg-anime-dark/50 border border-purple-500/30 rounded-lg px-4 py-2 pl-10 text-white placeholder-gray-400 focus:outline-none focus:border-purple-500"
                  data-testid="input-search"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              </div>
              {user ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                      <Avatar className="h-8 w-8 border-2 border-purple-500">
                        <AvatarImage src={`https://api.dicebear.com/7.x/adventurer/svg?seed=${user.username}`} />
                        <AvatarFallback className="bg-purple-600 text-white text-xs">
                          {getInitials(user.username)}
                        </AvatarFallback>
                      </Avatar>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="w-64 bg-black/90 border-purple-500/20" align="end">
                    <div className="flex items-center justify-start gap-2 p-2">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={`https://api.dicebear.com/7.x/adventurer/svg?seed=${user.username}`} />
                        <AvatarFallback className="bg-purple-600 text-white text-xs">
                          {getInitials(user.username)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex flex-col space-y-1">
                        <p className="text-sm font-medium text-white">{user.username}</p>
                        <div className="flex items-center gap-2">
                          <p className="text-xs text-gray-400">{user.email}</p>
                          {user.chatAccess && (
                            <Badge className="text-xs bg-gradient-to-r from-yellow-500 to-orange-500">Premium</Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    <DropdownMenuSeparator className="bg-purple-500/20" />
                    <DropdownMenuItem 
                      onClick={() => setLocation("/profile")}
                      className="text-white hover:bg-purple-600/20 cursor-pointer"
                    >
                      <User className="mr-2 h-4 w-4" />
                      Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      onClick={() => setLocation("/settings")}
                      className="text-white hover:bg-purple-600/20 cursor-pointer"
                    >
                      <Settings className="mr-2 h-4 w-4" />
                      Settings
                    </DropdownMenuItem>
                    <DropdownMenuSeparator className="bg-purple-500/20" />
                    <DropdownMenuItem 
                      onClick={handleLogout}
                      className="text-red-400 hover:bg-red-600/20 cursor-pointer"
                    >
                      <LogOut className="mr-2 h-4 w-4" />
                      Log out
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Button 
                  onClick={() => setLocation("/auth")}
                  className="anime-gradient hover:anime-glow-hover transition-all duration-300 hidden md:flex"
                  data-testid="button-login"
                >
                  <User className="w-4 h-4 mr-2" />
                  Login
                </Button>
              )}
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
                onClick={() => setIsMobileMenuOpen(true)}
                data-testid="button-mobile-menu"
              >
                <Menu className="w-6 h-6" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 bg-anime-dark/95 backdrop-blur-md z-50 md:hidden">
          <div className="flex flex-col h-full">
            <div className="flex justify-between items-center p-4 border-b border-purple-500/30">
              <h2 className="text-xl font-bold anime-gradient-text">Menu</h2>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => setIsMobileMenuOpen(false)}
                data-testid="button-close-mobile-menu"
              >
                <X className="w-6 h-6" />
              </Button>
            </div>
            <nav className="flex-1 p-4">
              <div className="space-y-4">
                <button 
                  onClick={() => scrollToSection('home')}
                  className="block text-white hover:text-purple-500 transition-colors py-2 w-full text-left"
                  data-testid="mobile-nav-home"
                >
                  Home
                </button>
                <button 
                  onClick={() => scrollToSection('catalog')}
                  className="block text-white hover:text-purple-500 transition-colors py-2 w-full text-left"
                  data-testid="mobile-nav-catalog"
                >
                  Catalog
                </button>
                <button 
                  onClick={() => { setLocation('/movies'); setIsMobileMenuOpen(false); }}
                  className="block text-white hover:text-purple-500 transition-colors py-2 w-full text-left"
                  data-testid="mobile-nav-movies"
                >
                  Movies
                </button>
                <button 
                  onClick={() => { setLocation('/youtube'); setIsMobileMenuOpen(false); }}
                  className="block text-white hover:text-purple-500 transition-colors py-2 w-full text-left"
                  data-testid="mobile-nav-youtube"
                >
                  YouTube
                </button>
                <button 
                  onClick={() => { setLocation('/manga'); setIsMobileMenuOpen(false); }}
                  className="block text-white hover:text-purple-500 transition-colors py-2 w-full text-left"
                  data-testid="mobile-nav-manga"
                >
                  Manga
                </button>
                <button 
                  onClick={() => scrollToSection('chat')}
                  className="block text-white hover:text-purple-500 transition-colors py-2 w-full text-left"
                  data-testid="mobile-nav-chat"
                >
                  Chat
                </button>
                <button 
                  onClick={() => scrollToSection('trending')}
                  className="block text-white hover:text-purple-500 transition-colors py-2 w-full text-left"
                  data-testid="mobile-nav-trending"
                >
                  Trending
                </button>
                <button 
                  onClick={() => { setLocation('/faq'); setIsMobileMenuOpen(false); }}
                  className="block text-white hover:text-purple-500 transition-colors py-2 w-full text-left"
                  data-testid="mobile-nav-faq"
                >
                  FAQ
                </button>
              </div>
            </nav>
          </div>
        </div>
      )}
    </>
  );
}
