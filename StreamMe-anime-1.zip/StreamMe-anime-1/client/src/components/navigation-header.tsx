import { Button } from "@/components/ui/button";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { ArrowLeft, Home, Gift, Heart, CreditCard, HandHeart } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface NavigationHeaderProps {
  title?: string;
  showBack?: boolean;
}

export default function NavigationHeader({ title, showBack = true }: NavigationHeaderProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const goBack = () => {
    if (window.history.length > 1) {
      window.history.back();
    } else {
      setLocation("/");
    }
  };

  const goHome = () => {
    setLocation("/");
  };

  const copyPaymentInfo = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    toast({
      title: "Copied!",
      description: `${label} copied to clipboard`,
    });
  };

  return (
    <div className="flex items-center justify-between p-4 bg-black/50 backdrop-blur-sm border-b border-purple-500/20 sticky top-0 z-50">
      <div className="flex items-center gap-4">
        {showBack && (
          <Button
            variant="ghost"
            size="sm"
            onClick={goBack}
            className="text-white hover:text-purple-400 hover:bg-purple-500/20"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back
          </Button>
        )}
        
        <Button
          variant="ghost"
          size="sm"
          onClick={goHome}
          className="text-white hover:text-purple-400 hover:bg-purple-500/20"
        >
          <Home className="h-4 w-4 mr-2" />
          Home
        </Button>
        
        {title && (
          <h1 className="text-xl font-bold text-white ml-4">{title}</h1>
        )}
      </div>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="outline"
            size="sm"
            className="border-purple-500/30 text-purple-400 hover:text-white hover:bg-purple-500/20 bg-black/50"
          >
            <Gift className="h-4 w-4 mr-2" />
            Gift the Creator
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent className="bg-black/90 border-purple-500/30 text-white w-80">
          <div className="p-3 border-b border-purple-500/20">
            <div className="flex items-center gap-2 mb-2">
              <Heart className="h-4 w-4 text-red-400" />
              <span className="font-semibold text-purple-400">Support the Creator</span>
            </div>
            <p className="text-sm text-gray-400">
              Show your appreciation for this amazing anime streaming platform!
            </p>
          </div>
          
          <DropdownMenuItem 
            onClick={() => copyPaymentInfo("9019185241", "Phone Number")}
            className="cursor-pointer hover:bg-purple-500/20 focus:bg-purple-500/20"
          >
            <CreditCard className="h-4 w-4 mr-2 text-green-400" />
            <div className="flex-1">
              <div className="font-medium">Opay Account</div>
              <div className="text-sm text-gray-400">9019185241</div>
            </div>
          </DropdownMenuItem>
          
          <DropdownMenuItem 
            onClick={() => copyPaymentInfo("Akewushola Abdulbakri Temitope", "Account Name")}
            className="cursor-pointer hover:bg-purple-500/20 focus:bg-purple-500/20"
          >
            <HandHeart className="h-4 w-4 mr-2 text-blue-400" />
            <div className="flex-1">
              <div className="font-medium">Account Name</div>
              <div className="text-sm text-gray-400">Akewushola Abdulbakri Temitope</div>
            </div>
          </DropdownMenuItem>
          
          <div className="p-3 border-t border-purple-500/20">
            <Badge variant="outline" className="w-full justify-center border-purple-500/50 text-purple-400">
              Every donation helps keep this platform running!
            </Badge>
            <p className="text-xs text-gray-500 text-center mt-2">
              Click any item above to copy to clipboard
            </p>
          </div>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}