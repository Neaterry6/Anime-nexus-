import { useQuery } from "@tanstack/react-query";
import { TrendingUp, Flame } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import type { Anime } from "@shared/schema";

interface Stats {
  totalAnime: number;
  activeUsers: number;
  downloadsToday: number;
  onlineNow: number;
}

export default function TrendingSection() {
  const { data: trendingAnime = [], isLoading: trendingLoading } = useQuery<Anime[]>({
    queryKey: ['/api/anime/trending'],
  });

  const { data: stats, isLoading: statsLoading } = useQuery<Stats>({
    queryKey: ['/api/stats'],
  });

  return (
    <section id="trending" className="py-20 bg-anime-slate/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 anime-gradient-text">Trending Now</h2>
          <p className="text-gray-300 text-lg">The hottest anime everyone's talking about</p>
        </div>

        {trendingLoading ? (
          <div className="text-center py-12">
            <div className="anime-gradient-text text-lg">Loading trending anime...</div>
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
            {trendingAnime.map((anime, index) => (
              <Card key={anime.id} className="glass-effect border border-purple-500/20 overflow-hidden hover:border-purple-500/50 transition-all duration-300" data-testid={`card-trending-${anime.id}`}>
                <img 
                  src={anime.imageUrl} 
                  alt={`${anime.title} trending`} 
                  className="w-full h-48 object-cover"
                  data-testid={`img-trending-${anime.id}`}
                />
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="text-xl font-bold" data-testid={`text-trending-title-${anime.id}`}>{anime.title}</h3>
                    <span className="anime-gradient px-3 py-1 rounded-full text-xs font-semibold" data-testid={`text-trending-rank-${anime.id}`}>
                      #{index + 1}
                    </span>
                  </div>
                  <p className="text-gray-400 text-sm mb-4" data-testid={`text-trending-description-${anime.id}`}>
                    {anime.description.length > 100 ? `${anime.description.substring(0, 100)}...` : anime.description}
                  </p>
                  <div className="flex items-center justify-between">
                    <span className="text-cyan-400 text-sm" data-testid={`text-trending-downloads-${anime.id}`}>
                      +{(Math.random() * 3 + 1).toFixed(1)}k downloads today
                    </span>
                    <span className="flex items-center text-yellow-400" data-testid={`text-trending-status-${anime.id}`}>
                      <Flame className="w-4 h-4 mr-1" />
                      {index === 0 ? 'Hot' : 'Rising'}
                    </span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {/* Statistics Section */}
        {statsLoading ? (
          <div className="text-center py-8">
            <div className="anime-gradient-text">Loading statistics...</div>
          </div>
        ) : (
          <div className="grid md:grid-cols-4 gap-6">
            <Card className="glass-effect border border-purple-500/20 text-center">
              <CardContent className="p-6">
                <div className="text-3xl font-bold anime-gradient-text mb-2" data-testid="stat-total-anime">
                  {stats?.totalAnime.toLocaleString() || '0'}
                </div>
                <p className="text-gray-400">Total Anime</p>
              </CardContent>
            </Card>
            <Card className="glass-effect border border-purple-500/20 text-center">
              <CardContent className="p-6">
                <div className="text-3xl font-bold anime-gradient-text mb-2" data-testid="stat-active-users">
                  {stats ? `${(stats.activeUsers / 1000).toFixed(1)}k` : '0'}
                </div>
                <p className="text-gray-400">Active Users</p>
              </CardContent>
            </Card>
            <Card className="glass-effect border border-purple-500/20 text-center">
              <CardContent className="p-6">
                <div className="text-3xl font-bold anime-gradient-text mb-2" data-testid="stat-downloads-today">
                  {stats ? `${(stats.downloadsToday / 1000).toFixed(1)}k` : '0'}
                </div>
                <p className="text-gray-400">Downloads Today</p>
              </CardContent>
            </Card>
            <Card className="glass-effect border border-purple-500/20 text-center">
              <CardContent className="p-6">
                <div className="text-3xl font-bold anime-gradient-text mb-2" data-testid="stat-online-now">
                  {stats ? `${(stats.onlineNow / 1000).toFixed(1)}k` : '0'}
                </div>
                <p className="text-gray-400">Online Now</p>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </section>
  );
}
