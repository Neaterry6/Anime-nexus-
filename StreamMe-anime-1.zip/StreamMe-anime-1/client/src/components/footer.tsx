import { PlayCircle } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-anime-dark border-t border-purple-500/30 py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <PlayCircle className="text-purple-500 w-8 h-8" />
              <h3 className="text-xl font-bold anime-gradient-text">AnimeVault</h3>
            </div>
            <p className="text-gray-400 mb-4">Your ultimate destination for anime downloads and community discussions.</p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-purple-500 transition-colors" data-testid="link-twitter">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M6.29 18.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0020 3.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.073 4.073 0 01.8 7.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 010 16.407a11.616 11.616 0 006.29 1.84" />
                </svg>
              </a>
              <a href="#" className="text-gray-400 hover:text-purple-500 transition-colors" data-testid="link-discord">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M16.942 5.556a16.3 16.3 0 00-4.126-1.297.068.068 0 00-.07.033c-.177.324-.375.75-.512 1.082a15.042 15.042 0 00-4.573 0 9.997 9.997 0 00-.522-1.082.07.07 0 00-.07-.033 16.263 16.263 0 00-4.126 1.297.064.064 0 00-.029.025C.533 9.046-.32 12.58.099 16.021a.077.077 0 00.031.053c1.56 1.167 3.072 1.879 4.558 2.353a.07.07 0 00.076-.025c.416-.58.786-1.19 1.11-1.836a.07.07 0 00-.04-.097c-.496-.191-.968-.415-1.419-.678a.07.07 0 01-.007-.117c.095-.072.19-.147.281-.223a.067.067 0 01.07-.01c2.982 1.386 6.212 1.386 9.16 0a.067.067 0 01.071.01c.09.076.185.151.28.223a.07.07 0 01-.006.117c-.45.263-.923.487-1.42.678a.07.07 0 00-.038.097c.33.646.7 1.256 1.109 1.836a.07.07 0 00.076.025c1.492-.474 3.003-1.186 4.563-2.353a.077.077 0 00.031-.053c.5-3.99-.838-7.464-3.549-10.54a.055.055 0 00-.029-.025zM6.729 13.56c-1.183 0-2.16-1.109-2.16-2.466 0-1.357.956-2.466 2.16-2.466 1.215 0 2.182 1.12 2.16 2.466 0 1.357-.956 2.466-2.16 2.466zm6.542 0c-1.183 0-2.16-1.109-2.16-2.466 0-1.357.955-2.466 2.16-2.466 1.215 0 2.182 1.12 2.16 2.466 0 1.357-.946 2.466-2.16 2.466z" />
                </svg>
              </a>
              <a href="#" className="text-gray-400 hover:text-purple-500 transition-colors" data-testid="link-reddit">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M16.5 10.5c0-.827-.673-1.5-1.5-1.5s-1.5.673-1.5 1.5c0 .827.673 1.5 1.5 1.5s1.5-.673 1.5-1.5zM15.999 14c-.615 0-1.5-.9-3.999-.9s-3.384.9-3.999.9c-.348 0-.686-.57-.686-.9 0-.827 1.5-.9 4.685-.9s4.685.073 4.685.9c0 .33-.338.9-.686.9zM5.5 10.5c0-.827.673-1.5 1.5-1.5s1.5.673 1.5 1.5c0 .827-.673 1.5-1.5 1.5s-1.5-.673-1.5-1.5z" />
                  <path fillRule="evenodd" d="M20 10c0 5.523-4.477 10-10 10S0 15.523 0 10 4.477 0 10 0s10 4.477 10 10zm-2 0c0-.668-.076-1.319-.217-1.942A1.5 1.5 0 0017 6.5c0-.828-.672-1.5-1.5-1.5-.394 0-.75.152-1.016.4A8.97 8.97 0 0010 4a8.97 8.97 0 00-4.484 1.4A1.497 1.497 0 004.5 5C3.672 5 3 5.672 3 6.5c0 .53.276 1.01.717 1.28A9.06 9.06 0 003 10c0 4.418 3.582 8 8 8s8-3.582 8-8z" clipRule="evenodd" />
                </svg>
              </a>
              <a href="#" className="text-gray-400 hover:text-purple-500 transition-colors" data-testid="link-youtube">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M2.5 3A1.5 1.5 0 001 4.5v11A1.5 1.5 0 002.5 17h15a1.5 1.5 0 001.5-1.5v-11A1.5 1.5 0 0017.5 3h-15zM8 12V8l4 2-4 2z" />
                </svg>
              </a>
            </div>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Browse</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-purple-500 transition-colors" data-testid="link-popular">Popular Anime</a></li>
              <li><a href="#" className="hover:text-purple-500 transition-colors" data-testid="link-new-releases">New Releases</a></li>
              <li><a href="#" className="hover:text-purple-500 transition-colors" data-testid="link-top-rated">Top Rated</a></li>
              <li><a href="#" className="hover:text-purple-500 transition-colors" data-testid="link-genres">Genres</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Community</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-purple-500 transition-colors" data-testid="link-chat-rooms">Chat Rooms</a></li>
              <li><a href="#" className="hover:text-purple-500 transition-colors" data-testid="link-forums">Forums</a></li>
              <li><a href="#" className="hover:text-purple-500 transition-colors" data-testid="link-reviews">Reviews</a></li>
              <li><a href="#" className="hover:text-purple-500 transition-colors" data-testid="link-recommendations">Recommendations</a></li>
            </ul>
          </div>
          <div>
            <h4 className="font-semibold mb-4">Support</h4>
            <ul className="space-y-2 text-gray-400">
              <li><a href="#" className="hover:text-purple-500 transition-colors" data-testid="link-help-center">Help Center</a></li>
              <li><a href="#" className="hover:text-purple-500 transition-colors" data-testid="link-contact">Contact Us</a></li>
              <li><a href="#" className="hover:text-purple-500 transition-colors" data-testid="link-bug-reports">Bug Reports</a></li>
              <li><a href="#" className="hover:text-purple-500 transition-colors" data-testid="link-feature-requests">Feature Requests</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-purple-500/20 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">&copy; 2024 AnimeVault. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <a href="#" className="text-gray-400 hover:text-purple-500 transition-colors text-sm" data-testid="link-privacy">Privacy Policy</a>
            <a href="#" className="text-gray-400 hover:text-purple-500 transition-colors text-sm" data-testid="link-terms">Terms of Service</a>
            <a href="#" className="text-gray-400 hover:text-purple-500 transition-colors text-sm" data-testid="link-dmca">DMCA</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
