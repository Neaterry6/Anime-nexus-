import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Send, Bot, Reply, Mic, Image, Video, Code, Sparkles } from "lucide-react";

interface ChatMessage {
  id: string;
  userId: string | null;
  username: string;
  message: string;
  messageType: string;
  fileUrl: string | null;
  timestamp: Date;
  isBot: boolean;
  aiModel: string | null;
}

interface AIModel {
  id: string;
  name: string;
  description: string;
  free: boolean;
}

export default function ChatRoom() {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [isConnected, setIsConnected] = useState(false);
  const [selectedModel, setSelectedModel] = useState<string>("gemini");
  const [availableModels, setAvailableModels] = useState<AIModel[]>([]);
  const [userTrials, setUserTrials] = useState(0);
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [isUnlockDialogOpen, setIsUnlockDialogOpen] = useState(false);
  const [unlockCode, setUnlockCode] = useState("");
  
  const { user, token, verifyUnlockCode } = useAuth();
  const { toast } = useToast();
  const wsRef = useRef<WebSocket | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user?.chatAccess && token) {
      connectWebSocket();
      fetchMessages();
      fetchAIModels();
    }
    
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [user?.chatAccess, token]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const connectWebSocket = () => {
    if (!token) return;

    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    wsRef.current = new WebSocket(wsUrl);

    wsRef.current.onopen = () => {
      setIsConnected(true);
      wsRef.current?.send(JSON.stringify({ type: 'auth', token }));
    };

    wsRef.current.onmessage = (event) => {
      const data = JSON.parse(event.data);
      
      if (data.type === 'new_message') {
        setMessages(prev => [...prev, data.data]);
      }
    };

    wsRef.current.onclose = () => {
      setIsConnected(false);
      // Reconnect after 3 seconds
      setTimeout(connectWebSocket, 3000);
    };

    wsRef.current.onerror = (error) => {
      console.error('WebSocket error:', error);
      setIsConnected(false);
    };
  };

  const fetchMessages = async () => {
    try {
      const response = await fetch("/api/chat/messages", {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.ok) {
        const data = await response.json();
        setMessages(data);
      }
    } catch (error) {
      console.error("Error fetching messages:", error);
    }
  };

  const fetchAIModels = async () => {
    try {
      const response = await fetch("/api/ai/models", {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.ok) {
        const data = await response.json();
        setAvailableModels(data.models);
        setUserTrials(data.userTrials);
      }
    } catch (error) {
      console.error("Error fetching AI models:", error);
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !token) return;

    try {
      const response = await fetch("/api/chat/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          message: newMessage,
          messageType: replyTo ? "reply" : "text",
          replyTo,
        }),
      });

      if (response.ok) {
        setNewMessage("");
        setReplyTo(null);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send message",
        variant: "destructive",
      });
    }
  };

  const sendAIMessage = async () => {
    if (!newMessage.trim() || !token) return;

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({
          model: selectedModel,
          prompt: newMessage,
        }),
      });

      if (response.ok) {
        setNewMessage("");
        // Refresh user trials count
        fetchAIModels();
      } else {
        const error = await response.json();
        toast({
          title: "AI Request Failed",
          description: error.error,
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to send AI message",
        variant: "destructive",
      });
    }
  };

  const handleUnlockCode = async () => {
    try {
      await verifyUnlockCode(unlockCode);
      setIsUnlockDialogOpen(false);
      setUnlockCode("");
      toast({
        title: "Success!",
        description: "Chat access granted! You can now participate in conversations.",
      });
    } catch (error) {
      toast({
        title: "Invalid Code",
        description: error instanceof Error ? error.message : "Please check your unlock code.",
        variant: "destructive",
      });
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !token) return;

    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await fetch("/api/upload", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });

      if (response.ok) {
        const { fileUrl } = await response.json();
        
        // Send message with file
        await fetch("/api/chat/messages", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
          body: JSON.stringify({
            message: `Shared a ${file.type.startsWith('image') ? 'image' : file.type.startsWith('video') ? 'video' : 'file'}`,
            messageType: file.type.startsWith('image') ? 'image' : file.type.startsWith('video') ? 'video' : 'file',
            fileUrl,
          }),
        });
      }
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "Failed to upload file",
        variant: "destructive",
      });
    }
  };

  if (!user) {
    return (
      <Card className="w-full max-w-4xl mx-auto bg-black/20 backdrop-blur-md border-purple-500/20">
        <CardContent className="p-8 text-center">
          <h3 className="text-xl font-semibold text-white mb-4">Authentication Required</h3>
          <p className="text-gray-300">Please log in to access the chat room.</p>
        </CardContent>
      </Card>
    );
  }

  if (!user.chatAccess) {
    return (
      <Card className="w-full max-w-4xl mx-auto bg-black/20 backdrop-blur-md border-purple-500/20">
        <CardContent className="p-8 text-center space-y-4">
          <h3 className="text-xl font-semibold text-white mb-4">Chat Access Required</h3>
          <p className="text-gray-300">
            You need chat access to participate in conversations. Use an unlock code or upgrade to premium.
          </p>
          
          <Dialog open={isUnlockDialogOpen} onOpenChange={setIsUnlockDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-purple-600 to-pink-600">
                <Code className="mr-2 h-4 w-4" />
                Enter Unlock Code
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-black/90 border-purple-500/20">
              <DialogHeader>
                <DialogTitle className="text-white">Enter Unlock Code</DialogTitle>
                <DialogDescription className="text-gray-300">
                  Enter your unlock code to gain chat access. Contact WhatsApp +2348039896597 to get your code.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <Input
                  placeholder="Enter unlock code"
                  value={unlockCode}
                  onChange={(e) => setUnlockCode(e.target.value)}
                  className="bg-black/30 border-purple-500/30 text-white"
                  data-testid="input-unlock-code"
                />
                <Button onClick={handleUnlockCode} className="w-full bg-gradient-to-r from-purple-600 to-pink-600" data-testid="button-verify-code">
                  Verify Code
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          
          <p className="text-sm text-gray-500">
            Contact WhatsApp for unlock code: <span className="font-mono text-pink-400">+2348039896597</span>
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-6xl mx-auto bg-black/20 backdrop-blur-md border-purple-500/20">
      <CardHeader className="border-b border-purple-500/20">
        <CardTitle className="flex items-center justify-between text-white">
          <span className="flex items-center gap-3">
            💬 StreamMe Community Chat
            <Badge variant={isConnected ? "default" : "destructive"} className="text-xs">
              {isConnected ? `Online (${Math.floor(Math.random() * 50) + 10})` : "Disconnected"}
            </Badge>
            <Badge className="bg-purple-600 text-xs">Premium</Badge>
          </span>
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4 w-4 text-purple-400" />
              <span className="text-purple-400">AI Trials: {userTrials}</span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              className="text-gray-400 hover:text-white"
              onClick={() => setMessages([])}
            >
              Clear Chat
            </Button>
          </div>
        </CardTitle>
      </CardHeader>
      
      <CardContent className="p-0">
        <ScrollArea className="h-96 p-4">
          <div className="space-y-4" data-testid="chat-messages">
            {messages.map((message) => (
              <div key={message.id} className="flex gap-3 group">
                <Avatar className="h-8 w-8">
                  <AvatarImage src={message.isBot ? "/bot-avatar.png" : undefined} />
                  <AvatarFallback className={message.isBot ? "bg-purple-600" : "bg-blue-600"}>
                    {message.isBot ? <Bot className="h-4 w-4" /> : message.username[0].toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                
                <div className="flex-1 space-y-1">
                  <div className="flex items-center gap-2">
                    <span className={`font-semibold text-sm ${message.isBot ? "text-purple-400" : "text-blue-400"}`}>
                      {message.username}
                    </span>
                    {message.aiModel && (
                      <Badge variant="outline" className="text-xs border-purple-500/30 text-purple-300">
                        {message.aiModel}
                      </Badge>
                    )}
                    <span className="text-xs text-gray-500">
                      {new Date(message.timestamp).toLocaleTimeString()}
                    </span>
                  </div>
                  
                  <div className="bg-gray-800/50 rounded-lg p-3 text-white text-sm">
                    {message.messageType === 'image' && message.fileUrl && (
                      <img src={message.fileUrl} alt="Shared image" className="max-w-xs rounded mb-2" />
                    )}
                    {message.messageType === 'video' && message.fileUrl && (
                      <video src={message.fileUrl} controls className="max-w-xs rounded mb-2" />
                    )}
                    <p className="whitespace-pre-wrap">{message.message}</p>
                  </div>
                  
                  <Button
                    variant="ghost"
                    size="sm"
                    className="opacity-0 group-hover:opacity-100 transition-opacity text-xs text-gray-400 hover:text-white"
                    onClick={() => setReplyTo(message.id)}
                    data-testid={`button-reply-${message.id}`}
                  >
                    <Reply className="h-3 w-3 mr-1" />
                    Reply
                  </Button>
                </div>
              </div>
            ))}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>
        
        <div className="border-t border-purple-500/20 p-4 space-y-3">
          {replyTo && (
            <div className="flex items-center gap-2 text-sm text-gray-400 bg-gray-800/30 rounded p-2">
              <Reply className="h-4 w-4" />
              <span>Replying to message</span>
              <Button variant="ghost" size="sm" onClick={() => setReplyTo(null)} className="ml-auto h-6 w-6 p-0">
                ×
              </Button>
            </div>
          )}
          
          <div className="flex gap-2">
            <Select value={selectedModel} onValueChange={setSelectedModel}>
              <SelectTrigger className="w-40 bg-black/30 border-purple-500/30 text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-black/90 border-purple-500/30">
                {availableModels.map((model) => (
                  <SelectItem key={model.id} value={model.id} className="text-white hover:bg-purple-600/20">
                    <div className="flex items-center gap-2">
                      <Bot className="h-4 w-4" />
                      {model.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => fileInputRef.current?.click()}
              className="border-purple-500/30 hover:bg-purple-600/20"
              data-testid="button-upload"
            >
              <Image className="h-4 w-4" />
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              className="border-purple-500/30 hover:bg-purple-600/20"
              data-testid="button-voice"
            >
              <Mic className="h-4 w-4" />
            </Button>
          </div>
          
          <form onSubmit={sendMessage} className="flex gap-2">
            <Input
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type your message..."
              className="flex-1 bg-black/30 border-purple-500/30 text-white placeholder:text-gray-400"
              data-testid="input-message"
            />
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700" data-testid="button-send">
              <Send className="h-4 w-4" />
            </Button>
            <Button 
              type="button" 
              onClick={sendAIMessage}
              className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
              data-testid="button-ai-send"
            >
              <Bot className="h-4 w-4" />
            </Button>
          </form>
        </div>
        
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*,video/*,audio/*"
          onChange={handleFileUpload}
          className="hidden"
        />
      </CardContent>
    </Card>
  );
}