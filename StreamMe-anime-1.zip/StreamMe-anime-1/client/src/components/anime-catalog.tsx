import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { Search, Download, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import type { Anime } from "@shared/schema";

export default function AnimeCatalog() {
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedGenre, setSelectedGenre] = useState("All Genres");
  const [selectedYear, setSelectedYear] = useState("All Years");
  const [sortBy, setSortBy] = useState("Sort by Rating");
  const { toast } = useToast();

  const { data: allAnime = [], isLoading } = useQuery<Anime[]>({
    queryKey: ['/api/anime'],
  });

  const filteredAndSortedAnime = useMemo(() => {
    let filtered = allAnime;

    // Apply search filter
    if (searchQuery) {
      filtered = filtered.filter(anime =>
        anime.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        anime.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        anime.genre.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Apply genre filter
    if (selectedGenre !== "All Genres") {
      filtered = filtered.filter(anime =>
        anime.genre.toLowerCase().includes(selectedGenre.toLowerCase())
      );
    }

    // Apply year filter
    if (selectedYear !== "All Years") {
      const year = parseInt(selectedYear);
      filtered = filtered.filter(anime => anime.year === year);
    }

    // Apply sorting
    if (sortBy === "Sort by Rating") {
      filtered.sort((a, b) => b.rating - a.rating);
    } else if (sortBy === "Sort by Year") {
      filtered.sort((a, b) => b.year - a.year);
    } else if (sortBy === "Sort by Name") {
      filtered.sort((a, b) => a.title.localeCompare(b.title));
    } else if (sortBy === "Sort by Episodes") {
      filtered.sort((a, b) => b.episodes - a.episodes);
    }

    return filtered;
  }, [allAnime, searchQuery, selectedGenre, selectedYear, sortBy]);

  const handleDownload = (anime: Anime) => {
    toast({
      title: "Download Started",
      description: `${anime.title} download has been initiated. Check your downloads folder.`,
    });
  };

  const genres = ["All Genres", "Action", "Romance", "Comedy", "Drama", "Adventure", "Thriller", "Mystery", "Supernatural", "Sports"];
  const years = ["All Years", "2024", "2023", "2022", "2021", "2020", "2019", "2016", "2013", "2007", "2006", "2001", "1999"];

  return (
    <section id="catalog" className="py-20 bg-anime-slate/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 anime-gradient-text">Anime Catalog</h2>
          <p className="text-gray-300 text-lg">Discover your next favorite anime from our extensive collection</p>
        </div>

        {/* Search and Filter Bar */}
        <div className="glass-effect rounded-xl p-6 mb-8">
          <div className="grid md:grid-cols-4 gap-4">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search anime titles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-anime-slate border border-purple-500/30 rounded-lg px-4 py-3 pl-10 text-white placeholder-gray-400 focus:outline-none focus:border-purple-500"
                data-testid="input-anime-search"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            </div>
            <Select value={selectedGenre} onValueChange={setSelectedGenre}>
              <SelectTrigger className="bg-anime-slate border border-purple-500/30 rounded-lg text-white" data-testid="select-genre">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {genres.map(genre => (
                  <SelectItem key={genre} value={genre}>{genre}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={selectedYear} onValueChange={setSelectedYear}>
              <SelectTrigger className="bg-anime-slate border border-purple-500/30 rounded-lg text-white" data-testid="select-year">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {years.map(year => (
                  <SelectItem key={year} value={year}>{year}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="bg-anime-slate border border-purple-500/30 rounded-lg text-white" data-testid="select-sort">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Sort by Rating">Sort by Rating</SelectItem>
                <SelectItem value="Sort by Year">Sort by Year</SelectItem>
                <SelectItem value="Sort by Name">Sort by Name</SelectItem>
                <SelectItem value="Sort by Episodes">Sort by Episodes</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Anime Grid */}
        {isLoading ? (
          <div className="text-center py-12">
            <div className="anime-gradient-text text-lg">Loading anime...</div>
          </div>
        ) : filteredAndSortedAnime.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-400 text-lg">No anime found matching your criteria.</div>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredAndSortedAnime.map((anime) => (
              <Card key={anime.id} className="glass-effect border border-purple-500/20 hover:border-purple-500/50 transform hover:scale-105 transition-all duration-300 group overflow-hidden" data-testid={`card-anime-${anime.id}`}>
                <div className="relative">
                  <img 
                    src={anime.imageUrl} 
                    alt={`${anime.title} poster`} 
                    className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500"
                    data-testid={`img-anime-${anime.id}`}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-anime-dark/80 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                </div>
                <CardContent className="p-4">
                  <h3 className="text-lg font-semibold mb-2 group-hover:text-purple-500 transition-colors" data-testid={`text-anime-title-${anime.id}`}>
                    {anime.title}
                  </h3>
                  <div className="flex items-center justify-between text-sm text-gray-400 mb-3">
                    <span data-testid={`text-anime-genre-${anime.id}`}>{anime.genre}</span>
                    <span className="flex items-center text-yellow-400" data-testid={`text-anime-rating-${anime.id}`}>
                      <Star className="w-3 h-3 mr-1 fill-current" />
                      {anime.rating}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-sm text-gray-400 mb-3">
                    <span data-testid={`text-anime-year-${anime.id}`}>{anime.year}</span>
                    <span data-testid={`text-anime-episodes-${anime.id}`}>{anime.episodes} eps</span>
                  </div>
                  <Button 
                    className="w-full anime-gradient hover:shadow-lg hover:shadow-purple-500/50 transition-all duration-300"
                    onClick={() => handleDownload(anime)}
                    data-testid={`button-download-${anime.id}`}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
