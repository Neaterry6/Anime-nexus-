import { Play, MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function HeroSection() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated background with colorful orbs */}
      <div className="absolute inset-0 bg-gradient-to-br from-anime-dark via-anime-slate to-anime-dark">
        <div className="absolute top-20 left-20 w-64 h-64 bg-purple-500/20 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-20 right-20 w-96 h-96 bg-pink-500/20 rounded-full blur-3xl animate-float-delayed"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl animate-float-delayed-2"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="text-center lg:text-left">
            <h1 className="text-5xl lg:text-7xl font-bold mb-6 anime-gradient-text leading-tight">
              Your Ultimate Anime Destination
            </h1>
            <p className="text-xl text-gray-300 mb-8 leading-relaxed">
              Discover, download, and discuss thousands of anime titles. Join our vibrant community and never miss an episode again.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <Button 
                className="anime-gradient px-8 py-4 text-lg font-semibold hover:shadow-xl hover:shadow-purple-500/50 transform hover:scale-105 transition-all duration-300"
                onClick={() => scrollToSection('catalog')}
                data-testid="button-browse-catalog"
              >
                <Play className="mr-2 w-5 h-5" />
                Browse Catalog
              </Button>
              <Button 
                variant="outline"
                className="border-2 border-purple-500 px-8 py-4 text-lg font-semibold hover:bg-purple-500/20 transition-all duration-300"
                onClick={() => scrollToSection('chat')}
                data-testid="button-join-chat"
              >
                <MessageCircle className="mr-2 w-5 h-5" />
                Join Chat
              </Button>
            </div>
          </div>
          <div className="relative">
            {/* Featured anime poster with glassmorphism effect */}
            <div className="relative group">
              <img 
                src="https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=1200" 
                alt="Featured anime poster" 
                className="rounded-2xl shadow-2xl w-full max-w-md mx-auto transform group-hover:scale-105 transition-transform duration-500"
                data-testid="img-featured-anime"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-anime-dark/80 via-transparent to-transparent rounded-2xl"></div>
              <div className="absolute bottom-6 left-6 right-6">
                <h3 className="text-2xl font-bold mb-2" data-testid="text-featured-title">Attack on Titan</h3>
                <div className="flex items-center space-x-4 text-sm text-gray-300">
                  <span className="flex items-center" data-testid="text-featured-rating">⭐ 9.8</span>
                  <span data-testid="text-featured-genre">Action, Drama</span>
                  <span data-testid="text-featured-year">2023</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
