import { useState, useEffect, useRef } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Bot, Code, Send, Image, Mic, Sparkles, Reply, Users, Smile, MoreHorizontal, Pin, Trash2, Edit2, Flag, Heart, ThumbsUp, MessageSquare, FileText, Calendar, Settings } from "lucide-react";

interface ChatMessage {
  id: string;
  username: string;
  message: string;
  timestamp: string;
  isBot?: boolean;
  aiModel?: string;
  messageType?: 'text' | 'image' | 'video' | 'file';
  fileUrl?: string;
  reactions?: { [emoji: string]: string[] };
  isPinned?: boolean;
  replyTo?: string;
  isEdited?: boolean;
}

interface AIModel {
  id: string;
  name: string;
  description: string;
  available: boolean;
}

interface TypingIndicator {
  username: string;
  timestamp: number;
}

export default function EnhancedChatRoom() {
  const { user, token, verifyUnlockCode } = useAuth();
  const { toast } = useToast();

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState("");
  const [selectedModel, setSelectedModel] = useState("gemini");
  const [userTrials, setUserTrials] = useState(5);
  const [isConnected, setIsConnected] = useState(false);
  const [replyTo, setReplyTo] = useState<string | null>(null);
  const [editingMessage, setEditingMessage] = useState<string | null>(null);
  const [unlockCode, setUnlockCode] = useState("");
  const [isUnlockDialogOpen, setIsUnlockDialogOpen] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const [typingUsers, setTypingUsers] = useState<TypingIndicator[]>([]);
  const [onlineCount, setOnlineCount] = useState(Math.floor(Math.random() * 50) + 15);
  const [pinnedMessages, setPinnedMessages] = useState<ChatMessage[]>([]);
  const [showEmojiPicker, setShowEmojiPicker] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const wsRef = useRef<WebSocket | null>(null);
  const typingTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  const availableModels: AIModel[] = [
    { id: "gemini", name: "Gemini Pro", description: "Google's advanced AI", available: true },
    { id: "grok", name: "Grok", description: "X's AI assistant", available: true },
    { id: "image-gen", name: "Image Generator", description: "AI image creation", available: user?.chatAccess || false },
  ];

  const popularEmojis = ["👍", "❤️", "😂", "😢", "😮", "😡", "🎉", "🔥", "💯", "👏"];

  useEffect(() => {
    if (!user || !user.chatAccess) return;

    // Connect to WebSocket
    const connectWebSocket = () => {
      const ws = new WebSocket(`ws://localhost:5000`);
      wsRef.current = ws;

      ws.onopen = () => {
        setIsConnected(true);
        console.log("Connected to chat server");
      };

      ws.onmessage = (event) => {
        const data = JSON.parse(event.data);
        if (data.type === 'message') {
          setMessages(prev => [...prev, data.message]);
        } else if (data.type === 'typing') {
          setTypingUsers(prev => {
            const filtered = prev.filter(t => t.username !== data.username);
            if (data.isTyping) {
              return [...filtered, { username: data.username, timestamp: Date.now() }];
            }
            return filtered;
          });
        } else if (data.type === 'userCount') {
          setOnlineCount(data.count);
        }
      };

      ws.onclose = () => {
        setIsConnected(false);
        setTimeout(connectWebSocket, 3000);
      };

      ws.onerror = (error) => {
        console.error("WebSocket error:", error);
        setIsConnected(false);
      };
    };

    connectWebSocket();
    loadMessages();
    loadUserTrials();

    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, [user]);

  // Clean up old typing indicators
  useEffect(() => {
    const interval = setInterval(() => {
      setTypingUsers(prev => 
        prev.filter(t => Date.now() - t.timestamp < 3000)
      );
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const loadMessages = async () => {
    try {
      const response = await fetch("/api/chat/messages", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.ok) {
        const data = await response.json();
        setMessages(data);
      }
    } catch (error) {
      console.error("Failed to load messages:", error);
    }
  };

  const loadUserTrials = async () => {
    try {
      const response = await fetch("/api/auth/me", {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (response.ok) {
        const userData = await response.json();
        setUserTrials(userData.aiTrials || 0);
      }
    } catch (error) {
      console.error("Failed to load user trials:", error);
    }
  };

  const handleTyping = () => {
    if (!isTyping && wsRef.current) {
      setIsTyping(true);
      wsRef.current.send(JSON.stringify({
        type: 'typing',
        username: user?.username,
        isTyping: true
      }));
    }

    if (typingTimeoutRef.current) {
      clearTimeout(typingTimeoutRef.current);
    }

    typingTimeoutRef.current = setTimeout(() => {
      setIsTyping(false);
      if (wsRef.current) {
        wsRef.current.send(JSON.stringify({
          type: 'typing',
          username: user?.username,
          isTyping: false
        }));
      }
    }, 1000);
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !user) return;

    const messageData = {
      username: user.username,
      message: newMessage,
      messageType: 'text' as const,
      replyTo,
    };

    try {
      const response = await fetch("/api/chat/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(messageData),
      });

      if (response.ok) {
        setNewMessage("");
        setReplyTo(null);
        if (wsRef.current) {
          wsRef.current.send(JSON.stringify({
            type: 'typing',
            username: user.username,
            isTyping: false
          }));
        }
      }
    } catch (error) {
      toast({
        title: "Message Failed",
        description: "Could not send message. Please try again.",
        variant: "destructive",
      });
    }
  };

  const sendAIMessage = async () => {
    if (!newMessage.trim() || userTrials <= 0) return;

    const messageData = {
      username: user?.username || "User",
      message: newMessage,
      aiModel: selectedModel,
      messageType: 'text' as const,
      replyTo,
    };

    try {
      const response = await fetch("/api/ai/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(messageData),
      });

      if (response.ok) {
        setNewMessage("");
        setReplyTo(null);
        setUserTrials(prev => prev - 1);
      }
    } catch (error) {
      toast({
        title: "AI Chat Failed",
        description: "Could not send AI message. Please try again.",
        variant: "destructive",
      });
    }
  };

  const addReaction = async (messageId: string, emoji: string) => {
    try {
      const response = await fetch(`/api/chat/messages/${messageId}/react`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ emoji, username: user?.username }),
      });

      if (response.ok) {
        setMessages(prev => prev.map(msg => {
          if (msg.id === messageId) {
            const reactions = { ...msg.reactions };
            if (!reactions[emoji]) reactions[emoji] = [];
            
            const userIndex = reactions[emoji].indexOf(user?.username || "");
            if (userIndex > -1) {
              reactions[emoji].splice(userIndex, 1);
              if (reactions[emoji].length === 0) delete reactions[emoji];
            } else {
              reactions[emoji].push(user?.username || "");
            }
            
            return { ...msg, reactions };
          }
          return msg;
        }));
      }
    } catch (error) {
      console.error("Failed to add reaction:", error);
    }
  };

  const pinMessage = async (messageId: string) => {
    try {
      const response = await fetch(`/api/chat/messages/${messageId}/pin`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.ok) {
        const message = messages.find(m => m.id === messageId);
        if (message) {
          setPinnedMessages(prev => [...prev, { ...message, isPinned: true }]);
        }
      }
    } catch (error) {
      console.error("Failed to pin message:", error);
    }
  };

  const deleteMessage = async (messageId: string) => {
    try {
      const response = await fetch(`/api/chat/messages/${messageId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` },
      });

      if (response.ok) {
        setMessages(prev => prev.filter(m => m.id !== messageId));
      }
    } catch (error) {
      console.error("Failed to delete message:", error);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);
    formData.append("username", user?.username || "User");

    try {
      const response = await fetch("/api/chat/upload", {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: formData,
      });

      if (response.ok) {
        toast({
          title: "File Uploaded",
          description: "Your file has been shared in the chat.",
        });
      }
    } catch (error) {
      toast({
        title: "Upload Failed",
        description: "Could not upload file. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleUnlockCode = async () => {
    try {
      await verifyUnlockCode(unlockCode);
      setIsUnlockDialogOpen(false);
      setUnlockCode("");
      toast({
        title: "Success!",
        description: "Premium features unlocked! You now have unlimited AI trials.",
      });
    } catch (error) {
      toast({
        title: "Invalid Code",
        description: error instanceof Error ? error.message : "Please check your unlock code.",
        variant: "destructive",
      });
    }
  };

  if (!user || !user.chatAccess) {
    return (
      <Card className="w-full max-w-4xl mx-auto bg-black/20 backdrop-blur-md border-purple-500/20">
        <CardHeader className="text-center">
          <CardTitle className="text-white flex items-center justify-center gap-2">
            <MessageSquare className="h-6 w-6" />
            Premium Chat Access Required
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-6">
          <p className="text-gray-300">
            Unlock exclusive chat features and join our anime community!
          </p>
          
          <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
            <div className="bg-purple-900/20 p-4 rounded-lg">
              <Bot className="h-8 w-8 text-purple-400 mx-auto mb-2" />
              <h3 className="text-white font-semibold">AI Chatbots</h3>
              <p className="text-gray-400 text-sm">Chat with multiple AI models</p>
            </div>
            <div className="bg-purple-900/20 p-4 rounded-lg">
              <Users className="h-8 w-8 text-purple-400 mx-auto mb-2" />
              <h3 className="text-white font-semibold">Community</h3>
              <p className="text-gray-400 text-sm">Join live discussions</p>
            </div>
          </div>
          
          <Dialog open={isUnlockDialogOpen} onOpenChange={setIsUnlockDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                <Code className="mr-2 h-4 w-4" />
                Enter Unlock Code
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-black/90 border-purple-500/20">
              <DialogHeader>
                <DialogTitle className="text-white">Enter Unlock Code</DialogTitle>
                <DialogDescription className="text-gray-300">
                  Enter your unlock code to gain chat access. Contact WhatsApp +2348039896597 to get your code.
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <Input
                  placeholder="Enter unlock code"
                  value={unlockCode}
                  onChange={(e) => setUnlockCode(e.target.value)}
                  className="bg-black/30 border-purple-500/30 text-white"
                />
                <Button onClick={handleUnlockCode} className="w-full bg-gradient-to-r from-purple-600 to-pink-600">
                  Verify Code
                </Button>
              </div>
            </DialogContent>
          </Dialog>
          
          <p className="text-sm text-gray-500">
            Contact WhatsApp for unlock code: <span className="font-mono text-pink-400">+2348039896597</span>
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="w-full max-w-7xl mx-auto space-y-4">
      {/* Pinned Messages */}
      {pinnedMessages.length > 0 && (
        <Card className="bg-yellow-900/20 backdrop-blur-md border-yellow-500/20">
          <CardHeader className="pb-2">
            <CardTitle className="text-yellow-400 text-sm flex items-center gap-2">
              <Pin className="h-4 w-4" />
              Pinned Messages
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <ScrollArea className="h-20">
              {pinnedMessages.map((msg) => (
                <div key={msg.id} className="text-sm text-gray-300 mb-1">
                  <span className="font-semibold text-yellow-400">{msg.username}:</span> {msg.message}
                </div>
              ))}
            </ScrollArea>
          </CardContent>
        </Card>
      )}

      {/* Main Chat */}
      <Card className="bg-black/20 backdrop-blur-md border-purple-500/20">
        <CardHeader className="border-b border-purple-500/20">
          <CardTitle className="flex items-center justify-between text-white">
            <div className="flex items-center gap-3">
              <MessageSquare className="h-6 w-6 text-purple-400" />
              <span>StreamMe Community Chat</span>
              <Badge variant={isConnected ? "default" : "destructive"} className="text-xs">
                {isConnected ? "Online" : "Disconnected"}
              </Badge>
              <Badge className="bg-purple-600 text-xs">Premium</Badge>
            </div>
            <div className="flex items-center gap-4 text-sm">
              <div className="flex items-center gap-2">
                <Users className="h-4 w-4 text-green-400" />
                <span className="text-green-400">{onlineCount} online</span>
              </div>
              <div className="flex items-center gap-2">
                <Sparkles className="h-4 w-4 text-purple-400" />
                <span className="text-purple-400">AI Trials: {userTrials}</span>
              </div>
              <Button
                variant="ghost"
                size="sm"
                className="text-gray-400 hover:text-white"
                onClick={() => setMessages([])}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          </CardTitle>
        </CardHeader>
        
        <CardContent className="p-0">
          <ScrollArea className="h-[450px] p-4">
            <div className="space-y-4">
              {messages.map((message) => (
                <div key={message.id} className="flex gap-3 group hover:bg-purple-900/10 p-2 rounded-lg transition-colors">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={message.isBot ? "/bot-avatar.png" : undefined} />
                    <AvatarFallback className={message.isBot ? "bg-purple-600" : "bg-blue-600"}>
                      {message.isBot ? <Bot className="h-4 w-4" /> : message.username[0].toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  
                  <div className="flex-1 space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className={`font-semibold text-sm ${message.isBot ? "text-purple-400" : "text-blue-400"}`}>
                        {message.username}
                      </span>
                      {message.isBot && (
                        <Badge className="bg-purple-600/20 text-purple-300 text-xs px-2 py-1">
                          <Bot className="h-3 w-3 mr-1" />
                          AI
                        </Badge>
                      )}
                      {message.aiModel && (
                        <Badge variant="outline" className="text-xs border-purple-500/30 text-purple-300 px-2 py-1">
                          {message.aiModel}
                        </Badge>
                      )}
                      <span className="text-xs text-gray-500">
                        {new Date(message.timestamp).toLocaleTimeString()}
                      </span>
                      {message.isEdited && (
                        <span className="text-xs text-gray-500 italic">(edited)</span>
                      )}
                    </div>
                    
                    <div className={`${message.isBot ? 'bg-purple-900/20 border border-purple-500/20' : 'bg-gray-800/50'} rounded-lg p-3 text-white text-sm hover:bg-gray-700/50 transition-colors`}>
                      {message.messageType === 'image' && message.fileUrl && (
                        <img src={message.fileUrl} alt="Shared image" className="max-w-xs rounded mb-2" />
                      )}
                      {message.messageType === 'video' && message.fileUrl && (
                        <video src={message.fileUrl} controls className="max-w-xs rounded mb-2" />
                      )}
                      <p className="whitespace-pre-wrap">{message.message}</p>
                    </div>
                    
                    {/* Reactions */}
                    {message.reactions && Object.keys(message.reactions).length > 0 && (
                      <div className="flex flex-wrap gap-1 mt-2">
                        {Object.entries(message.reactions).map(([emoji, users]) => (
                          <Button
                            key={emoji}
                            variant="outline"
                            size="sm"
                            className="h-6 px-2 text-xs border-purple-500/30 hover:bg-purple-600/20"
                            onClick={() => addReaction(message.id, emoji)}
                          >
                            {emoji} {users.length}
                          </Button>
                        ))}
                      </div>
                    )}
                    
                    {/* Message Actions */}
                    <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Popover open={showEmojiPicker === message.id} onOpenChange={(open) => setShowEmojiPicker(open ? message.id : null)}>
                        <PopoverTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0 text-gray-400 hover:text-white">
                            <Smile className="h-3 w-3" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-2 bg-black/90 border-purple-500/20">
                          <div className="grid grid-cols-5 gap-1">
                            {popularEmojis.map((emoji) => (
                              <Button
                                key={emoji}
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0 hover:bg-purple-600/20"
                                onClick={() => {
                                  addReaction(message.id, emoji);
                                  setShowEmojiPicker(null);
                                }}
                              >
                                {emoji}
                              </Button>
                            ))}
                          </div>
                        </PopoverContent>
                      </Popover>
                      
                      <Button
                        variant="ghost"
                        size="sm"
                        className="h-6 px-2 text-xs text-gray-400 hover:text-white"
                        onClick={() => setReplyTo(message.id)}
                      >
                        <Reply className="h-3 w-3 mr-1" />
                        Reply
                      </Button>
                      
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button variant="ghost" size="sm" className="h-6 w-6 p-0 text-gray-400 hover:text-white">
                            <MoreHorizontal className="h-3 w-3" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-1 bg-black/90 border-purple-500/20">
                          <div className="flex flex-col gap-1">
                            <Button
                              variant="ghost"
                              size="sm"
                              className="justify-start text-xs"
                              onClick={() => pinMessage(message.id)}
                            >
                              <Pin className="h-3 w-3 mr-2" />
                              Pin
                            </Button>
                            {message.username === user?.username && (
                              <>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="justify-start text-xs"
                                  onClick={() => setEditingMessage(message.id)}
                                >
                                  <Edit2 className="h-3 w-3 mr-2" />
                                  Edit
                                </Button>
                                <Button
                                  variant="ghost"
                                  size="sm"
                                  className="justify-start text-xs text-red-400"
                                  onClick={() => deleteMessage(message.id)}
                                >
                                  <Trash2 className="h-3 w-3 mr-2" />
                                  Delete
                                </Button>
                              </>
                            )}
                            <Button
                              variant="ghost"
                              size="sm"
                              className="justify-start text-xs text-red-400"
                            >
                              <Flag className="h-3 w-3 mr-2" />
                              Report
                            </Button>
                          </div>
                        </PopoverContent>
                      </Popover>
                    </div>
                  </div>
                </div>
              ))}
              
              {/* Typing Indicators */}
              {typingUsers.length > 0 && (
                <div className="flex items-center gap-2 text-sm text-gray-400 animate-pulse">
                  <div className="flex gap-1">
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }} />
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }} />
                    <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }} />
                  </div>
                  <span>
                    {typingUsers.slice(0, 3).map(t => t.username).join(', ')} 
                    {typingUsers.length === 1 ? ' is' : ' are'} typing...
                  </span>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>
          </ScrollArea>
          
          <div className="border-t border-purple-500/20 p-4 space-y-3">
            {replyTo && (
              <div className="flex items-center gap-2 text-sm text-gray-400 bg-gray-800/30 rounded p-2">
                <Reply className="h-4 w-4" />
                <span>Replying to message</span>
                <Button variant="ghost" size="sm" onClick={() => setReplyTo(null)} className="ml-auto h-6 w-6 p-0">
                  ×
                </Button>
              </div>
            )}
            
            <div className="flex gap-2">
              <Select value={selectedModel} onValueChange={setSelectedModel}>
                <SelectTrigger className="w-40 bg-black/30 border-purple-500/30 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-black/90 border-purple-500/30">
                  {availableModels.map((model) => (
                    <SelectItem key={model.id} value={model.id} className="text-white hover:bg-purple-600/20">
                      <div className="flex items-center gap-2">
                        <Bot className="h-4 w-4" />
                        {model.name}
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Button
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                className="border-purple-500/30 hover:bg-purple-600/20"
              >
                <Image className="h-4 w-4" />
              </Button>
              
              <Button
                variant="outline"
                size="sm"
                className="border-purple-500/30 hover:bg-purple-600/20"
              >
                <Mic className="h-4 w-4" />
              </Button>
            </div>
            
            <form onSubmit={sendMessage} className="flex gap-2">
              <Input
                value={newMessage}
                onChange={(e) => {
                  setNewMessage(e.target.value);
                  handleTyping();
                }}
                placeholder="Type your message..."
                className="flex-1 bg-black/30 border-purple-500/30 text-white placeholder:text-gray-400"
              />
              <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                <Send className="h-4 w-4" />
              </Button>
              <Button 
                type="button" 
                onClick={sendAIMessage}
                disabled={userTrials <= 0}
                className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 disabled:opacity-50"
              >
                <Bot className="h-4 w-4" />
              </Button>
            </form>
          </div>
          
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,video/*,audio/*"
            onChange={handleFileUpload}
            className="hidden"
          />
        </CardContent>
      </Card>
    </div>
  );
}