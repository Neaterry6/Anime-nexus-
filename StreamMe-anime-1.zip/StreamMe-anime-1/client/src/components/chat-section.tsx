import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Send, Bot, Users, TrendingUp, Calendar, Shuffle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { ChatMessage } from "@shared/schema";

export default function ChatSection() {
  const [newMessage, setNewMessage] = useState("");
  const [botMessage, setBotMessage] = useState("");
  const scrollRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const { data: messages = [], isLoading } = useQuery<ChatMessage[]>({
    queryKey: ['/api/chat/messages'],
    refetchInterval: 5000, // Refresh every 5 seconds for "real-time" effect
  });

  const sendMessageMutation = useMutation({
    mutationFn: async (data: { username: string; message: string; isBot: boolean }) => {
      const response = await apiRequest("POST", "/api/chat/messages", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/chat/messages'] });
      setNewMessage("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      });
    },
  });

  const chatbotMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest("POST", "/api/chatbot", { message });
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/chat/messages'] });
      setBotMessage("");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Chatbot is currently unavailable. Please try again later.",
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    
    sendMessageMutation.mutate({
      username: "User", // In a real app, this would come from authentication
      message: newMessage,
      isBot: false,
    });
  };

  const handleSendToChatbot = () => {
    if (!botMessage.trim()) return;
    
    chatbotMutation.mutate(botMessage);
  };

  const handleQuickAction = (action: string) => {
    const actionMessages = {
      trending: "What are the trending anime right now?",
      schedule: "When are new episodes released?",
      random: "Recommend me a random anime",
    };
    setBotMessage(actionMessages[action as keyof typeof actionMessages] || "");
  };

  const onlineUsers = [
    { name: "AnimeOtaku", avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32" },
    { name: "SakuraChan", avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32" },
    { name: "NarutoFan99", avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=32&h=32" },
  ];

  return (
    <section id="chat" className="py-20">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold mb-4 anime-gradient-text">Community Chat</h2>
          <p className="text-gray-300 text-lg">Connect with fellow anime enthusiasts and get instant help from our AI chatbot</p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Chat Area */}
          <div className="lg:col-span-2">
            <Card className="glass-effect border border-purple-500/20 h-96 flex flex-col">
              <CardHeader className="border-b border-purple-500/20">
                <div className="flex items-center justify-between">
                  <CardTitle>General Chat</CardTitle>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
                    <span className="text-sm text-gray-400" data-testid="text-online-count">234 online</span>
                  </div>
                </div>
              </CardHeader>
              
              <ScrollArea className="flex-1 p-4" ref={scrollRef}>
                {isLoading ? (
                  <div className="text-center text-gray-400">Loading messages...</div>
                ) : messages.length === 0 ? (
                  <div className="text-center text-gray-400">No messages yet. Start the conversation!</div>
                ) : (
                  <div className="space-y-4">
                    {messages.map((message) => (
                      <div key={message.id} className="flex items-start space-x-3" data-testid={`message-${message.id}`}>
                        {message.isBot ? (
                          <div className="w-8 h-8 anime-gradient rounded-full flex items-center justify-center">
                            <Bot className="w-4 h-4 text-white" />
                          </div>
                        ) : (
                          <img 
                            src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&auto=format&fit=crop&w=40&h=40" 
                            alt="User avatar" 
                            className="w-8 h-8 rounded-full"
                          />
                        )}
                        <div>
                          <div className="flex items-center space-x-2">
                            <span className={`font-medium ${message.isBot ? 'text-cyan-400' : 'text-purple-500'}`} data-testid={`text-username-${message.id}`}>
                              {message.username}
                            </span>
                            <span className="text-xs text-gray-400" data-testid={`text-timestamp-${message.id}`}>
                              {new Date(message.timestamp).toLocaleTimeString()}
                            </span>
                          </div>
                          <p className="text-sm text-gray-300" data-testid={`text-message-${message.id}`}>{message.message}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>

              <div className="p-4 border-t border-purple-500/20">
                <div className="flex space-x-2">
                  <Input
                    type="text"
                    placeholder="Type your message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    className="flex-1 bg-anime-slate border border-purple-500/30 text-white placeholder-gray-400"
                    disabled={sendMessageMutation.isPending}
                    data-testid="input-chat-message"
                  />
                  <Button 
                    className="anime-gradient hover:anime-glow-hover transition-all duration-300"
                    onClick={handleSendMessage}
                    disabled={sendMessageMutation.isPending}
                    data-testid="button-send-message"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* AI Chatbot */}
            <Card className="glass-effect border border-purple-500/20">
              <CardContent className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className="w-10 h-10 anime-gradient rounded-full flex items-center justify-center anime-glow">
                    <Bot className="w-5 h-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold">AnimeBot AI</h3>
                    <p className="text-xs text-gray-400">Always ready to help!</p>
                  </div>
                </div>
                
                <div className="bg-anime-slate/50 rounded-lg p-3 mb-4">
                  <p className="text-sm text-gray-300">Hi! I'm your anime assistant. Ask me about:</p>
                  <ul className="text-xs text-gray-400 mt-2 space-y-1">
                    <li>• Anime recommendations</li>
                    <li>• Episode schedules</li>
                    <li>• Download help</li>
                    <li>• Anime information</li>
                  </ul>
                </div>

                <div className="flex space-x-2">
                  <Input
                    type="text"
                    placeholder="Ask AnimeBot..."
                    value={botMessage}
                    onChange={(e) => setBotMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendToChatbot()}
                    className="flex-1 bg-anime-slate border border-purple-500/30 text-sm text-white placeholder-gray-400"
                    disabled={chatbotMutation.isPending}
                    data-testid="input-chatbot-message"
                  />
                  <Button 
                    size="sm"
                    className="bg-purple-500 hover:bg-purple-600"
                    onClick={handleSendToChatbot}
                    disabled={chatbotMutation.isPending}
                    data-testid="button-send-chatbot"
                  >
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="glass-effect border border-purple-500/20">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">Quick Actions</h3>
                <div className="space-y-2">
                  <Button
                    variant="ghost"
                    className="w-full justify-start p-3 bg-anime-slate/30 hover:bg-purple-500/20 transition-colors text-sm"
                    onClick={() => handleQuickAction('trending')}
                    data-testid="button-quick-trending"
                  >
                    <TrendingUp className="w-4 h-4 text-pink-500 mr-2" />
                    Trending Anime
                  </Button>
                  <Button
                    variant="ghost"
                    className="w-full justify-start p-3 bg-anime-slate/30 hover:bg-purple-500/20 transition-colors text-sm"
                    onClick={() => handleQuickAction('schedule')}
                    data-testid="button-quick-schedule"
                  >
                    <Calendar className="w-4 h-4 text-cyan-400 mr-2" />
                    Release Schedule
                  </Button>
                  <Button
                    variant="ghost"
                    className="w-full justify-start p-3 bg-anime-slate/30 hover:bg-purple-500/20 transition-colors text-sm"
                    onClick={() => handleQuickAction('random')}
                    data-testid="button-quick-random"
                  >
                    <Shuffle className="w-4 h-4 text-purple-500 mr-2" />
                    Random Anime
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Online Users */}
            <Card className="glass-effect border border-purple-500/20">
              <CardContent className="p-6">
                <h3 className="font-semibold mb-4">Online Users</h3>
                <div className="space-y-3">
                  {onlineUsers.map((user) => (
                    <div key={user.name} className="flex items-center space-x-3" data-testid={`user-online-${user.name}`}>
                      <img src={user.avatar} alt={`${user.name} avatar`} className="w-6 h-6 rounded-full" />
                      <span className="text-sm">{user.name}</span>
                      <div className="w-2 h-2 bg-green-400 rounded-full ml-auto"></div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}
