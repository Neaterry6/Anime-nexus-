# StreamMe Anime - Vercel Deployment Guide

## Quick Deployment Steps

### 1. Build the Application
```bash
# Build client
npm run build:client

# Build server for Vercel
npx esbuild server/index.ts --platform=node --packages=external --bundle --format=cjs --outfile=api/index.js --target=node18
```

### 2. Deploy to Vercel
```bash
# Install Vercel CLI (if not installed)
npm i -g vercel

# Deploy
npx vercel --prod
```

### 3. One-Command Deployment
```bash
# Use the deployment script
./deploy.sh
```

## Project Structure for Vercel

```
StreamMe-Anime/
├── api/
│   └── index.js           # Serverless function
├── client/
│   └── dist/             # Built frontend
├── vercel.json           # Vercel configuration
└── .vercelignore         # Files to ignore
```

## Environment Variables

Set these in Vercel dashboard:
- `NODE_ENV=production`
- Any API keys needed for external services

## Features Deployed

✅ **Real Anime Search** - zetsu.xyz API integration  
✅ **Download System** - Multiple quality/source options  
✅ **AI Chatbot** - Multi-model chat system  
✅ **User Authentication** - JWT-based auth  
✅ **Real-time Chat** - WebSocket communication  
✅ **Manga Reader** - Complete reading experience  
✅ **Movies Hub** - Search and download movies  

## API Endpoints

- `/api/anime/search` - Search anime
- `/api/anime/detail` - Get anime details
- `/api/anime/download-episode` - Get download links
- `/api/auth/*` - Authentication endpoints
- `/api/chat/*` - Chat functionality
- `/api/ai/*` - AI chatbot endpoints

## Performance Optimizations

- Client-side caching with TanStack Query
- Optimized bundle sizes
- CDN delivery for static assets
- Serverless API functions

## Post-Deployment

1. Test all anime search functionality
2. Verify download links work
3. Check AI chatbot responses
4. Test user authentication flow
5. Verify real-time chat works

Your StreamMe Anime platform is now live on Vercel! 🚀