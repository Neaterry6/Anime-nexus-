#!/bin/bash

# StreamMe Anime - GitHub Push Script
echo "🚀 Pushing StreamMe Anime Platform to GitHub..."

# Configure Git
git config user.name "StreamMe Anime"
git config user.email "dev@streamme-anime.com"

# Pull latest changes twice (as requested)
echo "📥 Pulling latest changes (attempt 1)..."
git pull origin main --allow-unrelated-histories || echo "First pull completed"

echo "📥 Pulling latest changes (attempt 2)..."
git pull origin main --allow-unrelated-histories || echo "Second pull completed"

# Add all files
echo "📝 Staging all files..."
git add .

# Commit with comprehensive message
echo "💾 Committing changes..."
git commit -m "🚀 StreamMe Anime Platform v2.0 - Complete Release

✨ Key Features:
• Comprehensive anime catalog with search & filtering
• Real-time chat with WebSocket communication  
• Multi-AI chatbot (GPT-4, Gemini, Image Generation)
• Movies & Music hub with download functionality
• JWT authentication system with user profiles
• Settings & profile management pages
• Beautiful anime-themed responsive UI design
• Universal navigation with back/home buttons
• Gift Creator payment integration dropdown

🔧 Technical Architecture:
• React 18 + TypeScript frontend
• Express.js backend with memory storage fallback
• Tailwind CSS + shadcn/ui component system
• Vite build system with hot module reloading
• WebSocket integration for real-time features
• Production-ready deployment configuration
• Vercel serverless function setup

🎨 Enhanced UI/UX:
• Anime-inspired purple/blue gradient themes
• Fully responsive design across all devices
• Interactive animations and smooth transitions
• Comprehensive navigation system
• Payment integration with copy-to-clipboard

📦 Deployment Ready:
• Optimized Vercel configuration
• Serverless API endpoints configured
• Environment variables setup guide
• GitHub Actions workflow compatible
• Production build optimization

💎 Premium Features:
• Unlock code system for premium chat access
• Creator support integration
• Payment: Opay 9019185241 (Akewushola Abdulbakri Temitope)
• Support contact: WhatsApp +2348039896597"

# Force push to GitHub (as requested)
echo "🚀 Force pushing to GitHub (attempt 1)..."
git push -u origin main --force

echo "🚀 Force pushing to GitHub (attempt 2)..."
git push -u origin main --force

echo "✅ StreamMe Anime Platform successfully pushed to GitHub!"
echo "🔗 Repository: https://github.com/Neaterry6/Anime-nexus-"
echo "🚀 Ready for Vercel deployment!"