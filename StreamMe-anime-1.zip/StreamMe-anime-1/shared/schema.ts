import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, real, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  avatar: text("avatar").default(""),
  bio: text("bio").default(""),
  isPremium: boolean("is_premium").notNull().default(false),
  chatAccess: boolean("chat_access").notNull().default(false),
  aiTrialsLeft: integer("ai_trials_left").notNull().default(3),
  unlockCode: text("unlock_code").default(""),
  stripeCustomerId: text("stripe_customer_id").default(""),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const anime = pgTable("anime", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  title: text("title").notNull(),
  description: text("description").notNull(),
  genre: text("genre").notNull(),
  year: integer("year").notNull(),
  rating: real("rating").notNull(),
  episodes: integer("episodes").notNull(),
  imageUrl: text("image_url").notNull(),
  downloadUrl: text("download_url").notNull(),
  status: text("status").notNull().default("completed"), // completed, ongoing, upcoming
});

export const chatMessages = pgTable("chat_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").references(() => users.id),
  username: text("username").notNull(),
  message: text("message").notNull(),
  messageType: text("message_type").notNull().default("text"), // text, image, voice, video, reply
  fileUrl: text("file_url").default(""),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  isBot: boolean("is_bot").notNull().default(false),
  aiModel: text("ai_model").default(""), // gemini, grok, etc
  replyTo: varchar("reply_to"),
});

export const payments = pgTable("payments", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  amount: real("amount").notNull(),
  currency: text("currency").notNull().default("usd"),
  paymentMethod: text("payment_method").notNull(), // stripe, unlock_code
  stripePaymentIntentId: text("stripe_payment_intent_id").default(""),
  status: text("status").notNull().default("pending"), // pending, completed, failed
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const readingHistory = pgTable("reading_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  mangaId: text("manga_id").notNull(),
  mangaTitle: text("manga_title").notNull(),
  mangaGenres: text("manga_genres").array(),
  mangaAuthor: text("manga_author"),
  mangaRating: real("manga_rating"),
  chaptersRead: integer("chapters_read").default(0),
  totalChapters: integer("total_chapters").default(0),
  lastReadAt: timestamp("last_read_at").notNull().defaultNow(),
  completedAt: timestamp("completed_at"),
  isFavorite: boolean("is_favorite").default(false),
  readingTime: integer("reading_time").default(0), // in minutes
});

export const admins = pgTable("admins", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("admin"),
  lastLogin: timestamp("last_login"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const recommendations = pgTable("recommendations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  userId: varchar("user_id").notNull().references(() => users.id),
  mangaId: text("manga_id").notNull(),
  mangaTitle: text("manga_title").notNull(),
  mangaGenres: text("manga_genres").array(),
  mangaAuthor: text("manga_author"),
  mangaRating: real("manga_rating"),
  score: integer("score").notNull(), // 1-100 recommendation score
  reason: text("reason"), // Why recommended
  basedOnManga: text("based_on_manga").array(), // Manga titles this recommendation is based on
  createdAt: timestamp("created_at").notNull().defaultNow(),
  isViewed: boolean("is_viewed").default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true,
});

export const loginUserSchema = createInsertSchema(users).pick({
  email: true,
  password: true,
});

export const updateUserSchema = createInsertSchema(users).pick({
  username: true,
  avatar: true,
  bio: true,
}).partial();

export const insertAnimeSchema = createInsertSchema(anime).omit({
  id: true,
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  timestamp: true,
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
});

export const insertReadingHistorySchema = createInsertSchema(readingHistory).omit({
  id: true,
  lastReadAt: true,
});

export const insertAdminSchema = createInsertSchema(admins).pick({
  email: true,
  password: true,
});

export const adminLoginSchema = createInsertSchema(admins).pick({
  email: true,
  password: true,
});

export const insertRecommendationSchema = createInsertSchema(recommendations).omit({
  id: true,
  createdAt: true,
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  readingHistory: many(readingHistory),
  recommendations: many(recommendations),
  chatMessages: many(chatMessages),
  payments: many(payments),
}));

export const readingHistoryRelations = relations(readingHistory, ({ one }) => ({
  user: one(users, {
    fields: [readingHistory.userId],
    references: [users.id],
  }),
}));

export const recommendationsRelations = relations(recommendations, ({ one }) => ({
  user: one(users, {
    fields: [recommendations.userId],
    references: [users.id],
  }),
}));

export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;
export type UpdateUser = z.infer<typeof updateUserSchema>;

export type InsertAdmin = z.infer<typeof insertAdminSchema>;
export type AdminLogin = z.infer<typeof adminLoginSchema>;

export type Admin = {
  id: string;
  email: string;
  password: string;
  role: string;
  lastLogin: Date | null;
  createdAt: Date;
};

export type User = {
  id: string;
  username: string;
  email: string;
  password: string;
  avatar: string | null;
  bio: string | null;
  isPremium: boolean;
  chatAccess: boolean;
  aiTrialsLeft: number;
  unlockCode: string | null;
  stripeCustomerId: string | null;
  createdAt: Date;
};

export type Anime = {
  id: string;
  title: string;
  description: string;
  genre: string;
  year: number;
  rating: number;
  episodes: number;
  imageUrl: string;
  downloadUrl: string;
  status: string;
};

export type ChatMessage = {
  id: string;
  userId: string | null;
  username: string;
  message: string;
  messageType: string;
  fileUrl: string | null;
  timestamp: Date;
  isBot: boolean;
  aiModel: string | null;
  replyTo?: string | null;
};

export type Payment = {
  id: string;
  userId: string;
  amount: number;
  currency: string;
  paymentMethod: string;
  stripePaymentIntentId: string | null;
  status: string;
  createdAt: Date;
};

export type InsertAnime = z.infer<typeof insertAnimeSchema>;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type InsertReadingHistory = z.infer<typeof insertReadingHistorySchema>;
export type InsertRecommendation = z.infer<typeof insertRecommendationSchema>;

export type ReadingHistory = {
  id: string;
  userId: string;
  mangaId: string;
  mangaTitle: string;
  mangaGenres: string[] | null;
  mangaAuthor: string | null;
  mangaRating: number | null;
  chaptersRead: number;
  totalChapters: number;
  lastReadAt: Date;
  completedAt: Date | null;
  isFavorite: boolean;
  readingTime: number;
};

export type Recommendation = {
  id: string;
  userId: string;
  mangaId: string;
  mangaTitle: string;
  mangaGenres: string[] | null;
  mangaAuthor: string | null;
  mangaRating: number | null;
  score: number;
  reason: string | null;
  basedOnManga: string[] | null;
  createdAt: Date;
  isViewed: boolean;
};
