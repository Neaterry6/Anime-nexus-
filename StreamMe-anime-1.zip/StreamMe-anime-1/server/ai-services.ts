const KAIZ_API_KEY = 'a0ebe80e-bf1a-4dbf-8d36-6935b1bfa5ea';
const IMGBB_API_KEY = 'YOUR_IMGBB_API_KEY'; // Will need this for image uploads

export interface AIModel {
  id: string;
  name: string;
  description: string;
  free: boolean;
}

export const AVAILABLE_MODELS: AIModel[] = [
  {
    id: "gpt4",
    name: "GPT-4",
    description: "Advanced AI for conversations and image recognition",
    free: false,
  },
  {
    id: "waifu",
    name: "Waifu Generator",
    description: "Generate anime waifu characters",
    free: false,
  },
  {
    id: "pinterest",
    name: "Pinterest Search",
    description: "Search Pinterest for images",
    free: false,
  },
  {
    id: "unsplash",
    name: "Unsplash Search",
    description: "Search high-quality photos from Unsplash",
    free: false,
  },
  {
    id: "createai",
    name: "AI Art Generator",
    description: "Generate custom AI artwork from text",
    free: false,
  },
  {
    id: "ghibli",
    name: "Ghibli Style Converter",
    description: "Convert images to Studio Ghibli anime style",
    free: false,
  },
];

export const availableModels = AVAILABLE_MODELS; // Keep backward compatibility

export const getAIResponse = async (model: string, prompt: string, imageUrl?: string, sessionId?: string): Promise<{ response: string; model: string; imageUrl?: string; }> => {
  try {
    let response: string;
    let responseImageUrl: string | undefined;
    
    switch (model) {
      case "gpt4":
        response = await generateGPT4Response(prompt, imageUrl, sessionId);
        break;
      case "waifu":
        const waifuResult = await generateWaifuResponse();
        response = waifuResult.text;
        responseImageUrl = waifuResult.imageUrl;
        break;
      case "pinterest":
        const pinterestResult = await searchPinterestImages(prompt);
        response = pinterestResult.text;
        responseImageUrl = pinterestResult.imageUrl;
        break;
      case "unsplash":
        const unsplashResult = await searchUnsplashImages(prompt);
        response = unsplashResult.text;
        responseImageUrl = unsplashResult.imageUrl;
        break;
      case "createai":
        const createAIResult = await generateAIArt(prompt);
        response = createAIResult.text;
        responseImageUrl = createAIResult.imageUrl;
        break;
      case "ghibli":
        const ghibliResult = await convertToGhibliStyle(imageUrl);
        response = ghibliResult.text;
        responseImageUrl = ghibliResult.imageUrl;
        break;
      default:
        throw new Error("Unknown AI model");
    }
    
    return { 
      response, 
      model,
      imageUrl: responseImageUrl 
    };
  } catch (error) {
    console.error(`AI generation error for ${model}:`, error);
    throw new Error(`Failed to generate response with ${model}`);
  }
};

export const generateAIResponse = getAIResponse; // Keep backward compatibility

const generateSessionId = (): string => {
  return Date.now().toString() + Math.random().toString(36).substring(7);
};

const generateGPT4Response = async (prompt: string, imageUrl?: string, sessionId?: string): Promise<string> => {
  try {
    const actualSessionId = sessionId || generateSessionId();
    let apiUrl = `https://kaiz-apis.gleeze.com/api/gpt-4?ask=${encodeURIComponent(prompt)}&uid=1268&sessionId=${encodeURIComponent(actualSessionId)}&apikey=${KAIZ_API_KEY}`;
    
    if (imageUrl) {
      apiUrl += `&imageUrl=${encodeURIComponent(imageUrl)}`;
    }

    const response = await fetch(apiUrl, {
      headers: { 'Cache-Control': 'no-cache' }
    });

    if (!response.ok) {
      throw new Error(`GPT-4 API error: ${response.statusText}`);
    }

    const data = await response.json();
    return data.response || "No response generated";
  } catch (error) {
    console.error("GPT-4 API error:", error);
    return "Sorry, I'm having trouble connecting to GPT-4. Please try again later.";
  }
};

const generateWaifuResponse = async (): Promise<{ text: string; imageUrl?: string }> => {
  try {
    const response = await fetch(`https://kaiz-apis.gleeze.com/api/waifu?apikey=${KAIZ_API_KEY}`, {
      headers: { 'Cache-Control': 'no-cache' }
    });

    if (!response.ok) {
      throw new Error(`Waifu API error: ${response.statusText}`);
    }

    const data = await response.json();
    return {
      text: "Generated a new anime waifu character for you!",
      imageUrl: data.imageUrl
    };
  } catch (error) {
    console.error("Waifu API error:", error);
    return {
      text: "Sorry, I'm having trouble generating waifu images. Please try again later."
    };
  }
};

const searchPinterestImages = async (query: string): Promise<{ text: string; imageUrl?: string }> => {
  try {
    const response = await fetch(`https://kaiz-apis.gleeze.com/api/pinterest?search=${encodeURIComponent(query)}&apikey=${KAIZ_API_KEY}`, {
      headers: { 'Cache-Control': 'no-cache' }
    });

    if (!response.ok) {
      throw new Error(`Pinterest API error: ${response.statusText}`);
    }

    const data = await response.json();
    if (data.data && data.data.length > 0) {
      return {
        text: `Found ${data.data.length} Pinterest images for "${query}". Here's the first one:`,
        imageUrl: data.data[0]
      };
    } else {
      return {
        text: "No images found on Pinterest for your search."
      };
    }
  } catch (error) {
    console.error("Pinterest API error:", error);
    return {
      text: "Sorry, I'm having trouble searching Pinterest. Please try again later."
    };
  }
};

const searchUnsplashImages = async (query: string): Promise<{ text: string; imageUrl?: string }> => {
  try {
    const response = await fetch(`https://bk9.fun/search/unsplash?q=${encodeURIComponent(query)}`, {
      headers: { 'Cache-Control': 'no-cache' }
    });

    if (!response.ok) {
      throw new Error(`Unsplash API error: ${response.statusText}`);
    }

    const data = await response.json();
    if (data.BK9 && data.BK9.length > 0) {
      return {
        text: `Found ${data.BK9.length} high-quality photos for "${query}". Here's the first one:`,
        imageUrl: data.BK9[0]
      };
    } else {
      return {
        text: "No images found on Unsplash for your search."
      };
    }
  } catch (error) {
    console.error("Unsplash API error:", error);
    return {
      text: "Sorry, I'm having trouble searching Unsplash. Please try again later."
    };
  }
};

const generateAIArt = async (prompt: string): Promise<{ text: string; imageUrl?: string }> => {
  try {
    const response = await fetch(`https://smfahim.xyz/creartai?prompt=${encodeURIComponent(prompt)}`, {
      headers: { 'Cache-Control': 'no-cache' }
    });

    if (!response.ok) {
      throw new Error(`CreateAI API error: ${response.statusText}`);
    }

    // This API returns a blob/image directly
    const blob = await response.blob();
    const imageUrl = URL.createObjectURL(blob);
    
    return {
      text: `Generated AI artwork for "${prompt}"`,
      imageUrl: imageUrl
    };
  } catch (error) {
    console.error("CreateAI API error:", error);
    return {
      text: "Sorry, I'm having trouble generating AI artwork. Please try again later."
    };
  }
};

const convertToGhibliStyle = async (imageUrl?: string): Promise<{ text: string; imageUrl?: string }> => {
  if (!imageUrl) {
    return {
      text: "Please provide an image to convert to Ghibli style."
    };
  }

  try {
    const response = await fetch(`https://kaiz-apis.gleeze.com/api/img2ghibli?imageUrl=${encodeURIComponent(imageUrl)}&apikey=${KAIZ_API_KEY}`);

    if (!response.ok) {
      throw new Error(`Ghibli API error: ${response.statusText}`);
    }

    const data = await response.json();
    if (data.url) {
      return {
        text: "Successfully converted your image to Studio Ghibli style!",
        imageUrl: data.url
      };
    } else {
      return {
        text: "Failed to convert image to Ghibli style."
      };
    }
  } catch (error) {
    console.error("Ghibli API error:", error);
    return {
      text: "Sorry, I'm having trouble converting the image. Please try again later."
    };
  }
};

export const canUseAIModel = (userIsPremium: boolean, aiTrialsLeft: number): boolean => {
  return userIsPremium || aiTrialsLeft > 0;
};

export const decrementAITrials = async (userId: string): Promise<void> => {
  // This would update the user's AI trials in the database
  // For now, we'll handle this in the route handler
};