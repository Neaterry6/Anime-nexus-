import mongoose from "mongoose";
import { type User, type InsertUser, type UpdateUser, type Admin, type InsertAdmin, type Anime, type InsertAnime, type ChatMessage, type InsertChatMessage, type Payment, type InsertPayment, type ReadingHistory, type InsertReadingHistory, type Recommendation, type InsertRecommendation } from "@shared/schema";
import { randomUUID } from "crypto";
import bcrypt from "bcryptjs";

// MongoDB Schemas
const UserSchema = new mongoose.Schema({
  _id: { type: String, default: () => randomUUID() },
  username: { type: String, required: true, unique: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  avatar: { type: String, default: "" },
  bio: { type: String, default: "" },
  isPremium: { type: Boolean, default: false },
  chatAccess: { type: Boolean, default: false },
  aiTrialsLeft: { type: Number, default: 3 },
  unlockCode: { type: String, default: "" },
  stripeCustomerId: { type: String, default: "" },
  createdAt: { type: Date, default: Date.now },
}, { _id: false, versionKey: false });

const AnimeSchema = new mongoose.Schema({
  _id: { type: String, default: () => randomUUID() },
  title: { type: String, required: true },
  description: { type: String, required: true },
  genre: { type: String, required: true },
  year: { type: Number, required: true },
  rating: { type: Number, required: true },
  episodes: { type: Number, required: true },
  imageUrl: { type: String, required: true },
  downloadUrl: { type: String, required: true },
  status: { type: String, default: "completed" },
}, { _id: false, versionKey: false });

const ChatMessageSchema = new mongoose.Schema({
  _id: { type: String, default: () => randomUUID() },
  userId: { type: String, ref: 'User', default: null },
  username: { type: String, required: true },
  message: { type: String, required: true },
  messageType: { type: String, default: "text" },
  fileUrl: { type: String, default: "" },
  timestamp: { type: Date, default: Date.now },
  isBot: { type: Boolean, default: false },
  aiModel: { type: String, default: "" },
  replyTo: { type: String, ref: 'ChatMessage', default: null },
}, { _id: false, versionKey: false });

const PaymentSchema = new mongoose.Schema({
  _id: { type: String, default: () => randomUUID() },
  userId: { type: String, required: true, ref: 'User' },
  amount: { type: Number, required: true },
  currency: { type: String, default: "usd" },
  paymentMethod: { type: String, required: true },
  stripePaymentIntentId: { type: String, default: "" },
  status: { type: String, default: "pending" },
  createdAt: { type: Date, default: Date.now },
}, { _id: false, versionKey: false });

const ReadingHistorySchema = new mongoose.Schema({
  _id: { type: String, default: () => randomUUID() },
  userId: { type: String, required: true, ref: 'User' },
  mangaId: { type: String, required: true },
  mangaTitle: { type: String, required: true },
  mangaGenres: [{ type: String }],
  mangaAuthor: { type: String },
  mangaRating: { type: Number },
  chaptersRead: { type: Number, default: 0 },
  totalChapters: { type: Number, default: 0 },
  lastReadAt: { type: Date, default: Date.now },
  completedAt: { type: Date },
  isFavorite: { type: Boolean, default: false },
  readingTime: { type: Number, default: 0 },
}, { _id: false, versionKey: false });

const RecommendationSchema = new mongoose.Schema({
  _id: { type: String, default: () => randomUUID() },
  userId: { type: String, required: true, ref: 'User' },
  mangaId: { type: String, required: true },
  mangaTitle: { type: String, required: true },
  mangaGenres: [{ type: String }],
  mangaAuthor: { type: String },
  mangaRating: { type: Number },
  score: { type: Number, required: true },
  reason: { type: String },
  basedOnManga: [{ type: String }],
  createdAt: { type: Date, default: Date.now },
  isViewed: { type: Boolean, default: false },
}, { _id: false, versionKey: false });

const AdminSchema = new mongoose.Schema({
  _id: { type: String, default: () => randomUUID() },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, default: "admin" },
  lastLogin: { type: Date },
  createdAt: { type: Date, default: Date.now },
}, { _id: false, versionKey: false });

const UserModel = mongoose.model('User', UserSchema);
const AnimeModel = mongoose.model('Anime', AnimeSchema);
const ChatMessageModel = mongoose.model('ChatMessage', ChatMessageSchema);
const PaymentModel = mongoose.model('Payment', PaymentSchema);
const ReadingHistoryModel = mongoose.model('ReadingHistory', ReadingHistorySchema);
const RecommendationModel = mongoose.model('Recommendation', RecommendationSchema);
const AdminModel = mongoose.model('Admin', AdminSchema);

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: UpdateUser): Promise<User | undefined>;
  updateUserChatAccess(id: string, hasAccess: boolean): Promise<User | undefined>;
  updateUserTrials(id: string, trials: number): Promise<User | undefined>;
  verifyUnlockCode(userId: string, code: string): Promise<boolean>;
  
  // Admin methods
  getAdmin(id: string): Promise<Admin | undefined>;
  getAdminByEmail(email: string): Promise<Admin | undefined>;
  createAdmin(admin: InsertAdmin): Promise<Admin>;
  updateAdminLastLogin(id: string): Promise<Admin | undefined>;
  
  // Anime methods
  getAllAnime(): Promise<Anime[]>;
  getAnimeById(id: string): Promise<Anime | undefined>;
  searchAnime(query: string): Promise<Anime[]>;
  filterAnime(genre?: string, year?: number): Promise<Anime[]>;
  getTrendingAnime(): Promise<Anime[]>;
  
  // Chat methods
  getChatMessages(limit?: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  // Payment methods
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPaymentsByUser(userId: string): Promise<Payment[]>;
  updatePaymentStatus(id: string, status: string): Promise<Payment | undefined>;
  
  // Reading History methods
  addReadingHistory(history: InsertReadingHistory): Promise<ReadingHistory>;
  getReadingHistory(userId: string): Promise<ReadingHistory[]>;
  updateReadingProgress(userId: string, mangaId: string, chaptersRead: number, readingTime?: number): Promise<ReadingHistory | undefined>;
  markAsCompleted(userId: string, mangaId: string): Promise<ReadingHistory | undefined>;
  toggleFavorite(userId: string, mangaId: string): Promise<ReadingHistory | undefined>;
  
  // Recommendation methods
  generateRecommendations(userId: string): Promise<Recommendation[]>;
  getRecommendations(userId: string): Promise<Recommendation[]>;
  markRecommendationViewed(userId: string, recommendationId: string): Promise<void>;
  createRecommendation(recommendation: InsertRecommendation): Promise<Recommendation>;
}

export class MongoStorage implements IStorage {
  constructor() {
    this.connectToDatabase();
    this.initializeAnimeData();
  }

  private async connectToDatabase() {
    try {
      await mongoose.connect(process.env.MONGODB_URI!);
      console.log("Connected to MongoDB");
    } catch (error) {
      console.error("MongoDB connection error:", error);
    }
  }

  private async initializeAnimeData() {
    try {
      const existingAnime = await AnimeModel.countDocuments();
      if (existingAnime > 0) return;

      const initialAnime = [
        {
          _id: "1",
          title: "Demon Slayer",
          description: "A young boy becomes a demon slayer to save his sister and avenge his family.",
          genre: "Action, Supernatural",
          year: 2019,
          rating: 9.5,
          episodes: 26,
          imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
          downloadUrl: "/download/demon-slayer",
          status: "completed"
        },
        {
          _id: "2",
          title: "My Hero Academia",
          description: "In a world where most people have superpowers, a powerless boy dreams of becoming a hero.",
          genre: "Action, School",
          year: 2016,
          rating: 9.2,
          episodes: 138,
          imageUrl: "https://images.unsplash.com/photo-1606041008023-472dfb5e530f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
          downloadUrl: "/download/my-hero-academia",
          status: "ongoing"
        },
        {
          _id: "3",
          title: "Attack on Titan",
          description: "Humanity fights for survival against giant humanoid Titans behind massive walls.",
          genre: "Action, Drama",
          year: 2013,
          rating: 9.8,
          episodes: 87,
          imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
          downloadUrl: "/download/attack-on-titan",
          status: "completed"
        }
      ];

      await AnimeModel.insertMany(initialAnime);
      console.log("Initialized anime data");
    } catch (error) {
      console.error("Error initializing anime data:", error);
    }
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    try {
      const user = await UserModel.findById(id).lean();
      return user ? { 
        id: user._id, 
        username: user.username,
        email: user.email,
        password: user.password,
        avatar: user.avatar || "",
        bio: user.bio || "",
        isPremium: user.isPremium,
        chatAccess: user.chatAccess,
        aiTrialsLeft: user.aiTrialsLeft,
        unlockCode: user.unlockCode || "",
        stripeCustomerId: user.stripeCustomerId || "",
        createdAt: user.createdAt
      } : undefined;
    } catch (error) {
      console.error("Error getting user:", error);
      return undefined;
    }
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    try {
      const user = await UserModel.findOne({ email }).lean();
      return user ? { 
        id: user._id, 
        username: user.username,
        email: user.email,
        password: user.password,
        avatar: user.avatar || "",
        bio: user.bio || "",
        isPremium: user.isPremium,
        chatAccess: user.chatAccess,
        aiTrialsLeft: user.aiTrialsLeft,
        unlockCode: user.unlockCode || "",
        stripeCustomerId: user.stripeCustomerId || "",
        createdAt: user.createdAt
      } : undefined;
    } catch (error) {
      console.error("Error getting user by email:", error);
      return undefined;
    }
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    try {
      const user = await UserModel.findOne({ username }).lean();
      return user ? { 
        id: user._id, 
        username: user.username,
        email: user.email,
        password: user.password,
        avatar: user.avatar || "",
        bio: user.bio || "",
        isPremium: user.isPremium,
        chatAccess: user.chatAccess,
        aiTrialsLeft: user.aiTrialsLeft,
        unlockCode: user.unlockCode || "",
        stripeCustomerId: user.stripeCustomerId || "",
        createdAt: user.createdAt
      } : undefined;
    } catch (error) {
      console.error("Error getting user by username:", error);
      return undefined;
    }
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    try {
      const hashedPassword = await bcrypt.hash(insertUser.password, 10);
      const user = new UserModel({
        username: insertUser.username,
        email: insertUser.email,
        password: hashedPassword,
      });
      const savedUser = await user.save();
      return {
        id: savedUser._id,
        username: savedUser.username,
        email: savedUser.email,
        password: savedUser.password,
        avatar: savedUser.avatar || "",
        bio: savedUser.bio || "",
        isPremium: savedUser.isPremium,
        chatAccess: savedUser.chatAccess,
        aiTrialsLeft: savedUser.aiTrialsLeft,
        unlockCode: savedUser.unlockCode || "",
        stripeCustomerId: savedUser.stripeCustomerId || "",
        createdAt: savedUser.createdAt
      };
    } catch (error) {
      console.error("Error creating user:", error);
      throw error;
    }
  }

  async updateUser(id: string, updates: UpdateUser): Promise<User | undefined> {
    try {
      const user = await UserModel.findByIdAndUpdate(id, updates, { new: true }).lean();
      return user ? { 
        id: user._id, 
        username: user.username,
        email: user.email,
        password: user.password,
        avatar: user.avatar || "",
        bio: user.bio || "",
        isPremium: user.isPremium,
        chatAccess: user.chatAccess,
        aiTrialsLeft: user.aiTrialsLeft,
        unlockCode: user.unlockCode || "",
        stripeCustomerId: user.stripeCustomerId || "",
        createdAt: user.createdAt
      } : undefined;
    } catch (error) {
      console.error("Error updating user:", error);
      return undefined;
    }
  }

  async updateUserChatAccess(id: string, hasAccess: boolean): Promise<User | undefined> {
    return this.updateUser(id, { chatAccess: hasAccess } as UpdateUser);
  }

  async updateUserTrials(id: string, trials: number): Promise<User | undefined> {
    return this.updateUser(id, { aiTrialsLeft: trials } as UpdateUser);
  }

  async verifyUnlockCode(userId: string, code: string): Promise<boolean> {
    const UNLOCK_CODE = "0814880";
    if (code === UNLOCK_CODE) {
      await this.updateUserChatAccess(userId, true);
      return true;
    }
    return false;
  }

  // Anime methods
  async getAllAnime(): Promise<Anime[]> {
    try {
      const animes = await AnimeModel.find().lean();
      return animes.map(anime => ({
        id: anime._id,
        title: anime.title,
        description: anime.description,
        genre: anime.genre,
        year: anime.year,
        rating: anime.rating,
        episodes: anime.episodes,
        imageUrl: anime.imageUrl,
        downloadUrl: anime.downloadUrl,
        status: anime.status
      }));
    } catch (error) {
      console.error("Error getting all anime:", error);
      return [];
    }
  }

  async getAnimeById(id: string): Promise<Anime | undefined> {
    try {
      const anime = await AnimeModel.findById(id).lean();
      return anime ? {
        id: anime._id,
        title: anime.title,
        description: anime.description,
        genre: anime.genre,
        year: anime.year,
        rating: anime.rating,
        episodes: anime.episodes,
        imageUrl: anime.imageUrl,
        downloadUrl: anime.downloadUrl,
        status: anime.status
      } : undefined;
    } catch (error) {
      console.error("Error getting anime by id:", error);
      return undefined;
    }
  }

  async searchAnime(query: string): Promise<Anime[]> {
    try {
      const animes = await AnimeModel.find({
        $or: [
          { title: { $regex: query, $options: 'i' } },
          { description: { $regex: query, $options: 'i' } },
          { genre: { $regex: query, $options: 'i' } }
        ]
      }).lean();
      return animes.map(anime => ({
        id: anime._id,
        title: anime.title,
        description: anime.description,
        genre: anime.genre,
        year: anime.year,
        rating: anime.rating,
        episodes: anime.episodes,
        imageUrl: anime.imageUrl,
        downloadUrl: anime.downloadUrl,
        status: anime.status
      }));
    } catch (error) {
      console.error("Error searching anime:", error);
      return [];
    }
  }

  async filterAnime(genre?: string, year?: number): Promise<Anime[]> {
    try {
      const filter: any = {};
      if (genre && genre !== "All Genres") {
        filter.genre = { $regex: genre, $options: 'i' };
      }
      if (year) {
        filter.year = year;
      }
      const animes = await AnimeModel.find(filter).lean();
      return animes.map(anime => ({
        id: anime._id,
        title: anime.title,
        description: anime.description,
        genre: anime.genre,
        year: anime.year,
        rating: anime.rating,
        episodes: anime.episodes,
        imageUrl: anime.imageUrl,
        downloadUrl: anime.downloadUrl,
        status: anime.status
      }));
    } catch (error) {
      console.error("Error filtering anime:", error);
      return [];
    }
  }

  async getTrendingAnime(): Promise<Anime[]> {
    try {
      const animes = await AnimeModel.find().sort({ rating: -1 }).limit(3).lean();
      return animes.map(anime => ({
        id: anime._id,
        title: anime.title,
        description: anime.description,
        genre: anime.genre,
        year: anime.year,
        rating: anime.rating,
        episodes: anime.episodes,
        imageUrl: anime.imageUrl,
        downloadUrl: anime.downloadUrl,
        status: anime.status
      }));
    } catch (error) {
      console.error("Error getting trending anime:", error);
      return [];
    }
  }

  // Chat methods
  async getChatMessages(limit: number = 50): Promise<ChatMessage[]> {
    try {
      const messages = await ChatMessageModel.find()
        .sort({ timestamp: -1 })
        .limit(limit)
        .populate('replyTo')
        .lean();
      
      return messages.reverse().map(msg => ({
        id: msg._id,
        userId: msg.userId || null,
        username: msg.username,
        message: msg.message,
        messageType: msg.messageType,
        fileUrl: msg.fileUrl || null,
        timestamp: msg.timestamp,
        isBot: msg.isBot,
        aiModel: msg.aiModel || null
      }));
    } catch (error) {
      console.error("Error getting chat messages:", error);
      return [];
    }
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    try {
      const message = new ChatMessageModel(insertMessage);
      const savedMessage = await message.save();
      return {
        id: savedMessage._id,
        userId: savedMessage.userId || null,
        username: savedMessage.username,
        message: savedMessage.message,
        messageType: savedMessage.messageType,
        fileUrl: savedMessage.fileUrl || null,
        timestamp: savedMessage.timestamp,
        isBot: savedMessage.isBot,
        aiModel: savedMessage.aiModel || null
      };
    } catch (error) {
      console.error("Error creating chat message:", error);
      throw error;
    }
  }

  // Payment methods
  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    try {
      const payment = new PaymentModel(insertPayment);
      const savedPayment = await payment.save();
      return {
        id: savedPayment._id,
        userId: savedPayment.userId,
        amount: savedPayment.amount,
        currency: savedPayment.currency,
        paymentMethod: savedPayment.paymentMethod,
        stripePaymentIntentId: savedPayment.stripePaymentIntentId || null,
        status: savedPayment.status,
        createdAt: savedPayment.createdAt
      };
    } catch (error) {
      console.error("Error creating payment:", error);
      throw error;
    }
  }

  async getPaymentsByUser(userId: string): Promise<Payment[]> {
    try {
      const payments = await PaymentModel.find({ userId }).lean();
      return payments.map(payment => ({
        id: payment._id,
        userId: payment.userId,
        amount: payment.amount,
        currency: payment.currency,
        paymentMethod: payment.paymentMethod,
        stripePaymentIntentId: payment.stripePaymentIntentId || null,
        status: payment.status,
        createdAt: payment.createdAt
      }));
    } catch (error) {
      console.error("Error getting payments by user:", error);
      return [];
    }
  }

  async updatePaymentStatus(id: string, status: string): Promise<Payment | undefined> {
    try {
      const payment = await PaymentModel.findByIdAndUpdate(id, { status }, { new: true }).lean();
      return payment ? {
        id: payment._id,
        userId: payment.userId,
        amount: payment.amount,
        currency: payment.currency,
        paymentMethod: payment.paymentMethod,
        stripePaymentIntentId: payment.stripePaymentIntentId || null,
        status: payment.status,
        createdAt: payment.createdAt
      } : undefined;
    } catch (error) {
      console.error("Error updating payment status:", error);
      return undefined;
    }
  }
}

// In-memory storage implementation as fallback
export class MemStorage implements IStorage {
  private users = new Map<string, User>();
  private admins = new Map<string, Admin>();
  private anime = new Map<string, Anime>();
  private chatMessages: ChatMessage[] = [];
  private payments = new Map<string, Payment>();
  private readingHistory = new Map<string, ReadingHistory>();
  private recommendations = new Map<string, Recommendation>();

  constructor() {
    this.initializeAnimeData();
  }



  private initializeAnimeData() {
    const initialAnime: Anime[] = [
      {
        id: "1",
        title: "Demon Slayer",
        description: "A young boy becomes a demon slayer to save his sister and avenge his family.",
        genre: "Action, Supernatural",
        year: 2019,
        rating: 9.5,
        episodes: 26,
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        downloadUrl: "/download/demon-slayer",
        status: "completed"
      },
      {
        id: "2", 
        title: "My Hero Academia",
        description: "In a world where most people have superpowers, a powerless boy dreams of becoming a hero.",
        genre: "Action, School",
        year: 2016,
        rating: 9.2,
        episodes: 138,
        imageUrl: "https://images.unsplash.com/photo-1606041008023-472dfb5e530f?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        downloadUrl: "/download/my-hero-academia",
        status: "ongoing"
      },
      {
        id: "3",
        title: "Attack on Titan", 
        description: "Humanity fights for survival against giant humanoid Titans behind massive walls.",
        genre: "Action, Drama",
        year: 2013,
        rating: 9.8,
        episodes: 87,
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        downloadUrl: "/download/attack-on-titan",
        status: "completed"
      },
      {
        id: "4",
        title: "Jujutsu Kaisen",
        description: "A high school student joins a secret organization to fight cursed spirits.",
        genre: "Action, Supernatural",
        year: 2020,
        rating: 9.3,
        episodes: 24,
        imageUrl: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&auto=format&fit=crop&w=400&h=600",
        downloadUrl: "/download/jujutsu-kaisen",
        status: "ongoing"
      }
    ];

    initialAnime.forEach(anime => this.anime.set(anime.id, anime));
    console.log("Initialized anime data in memory storage");
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const hashedPassword = await bcrypt.hash(insertUser.password, 10);
    
    const user: User = {
      id,
      username: insertUser.username,
      email: insertUser.email,
      password: hashedPassword,
      avatar: "",
      bio: "",
      isPremium: false,
      chatAccess: false,
      aiTrialsLeft: 3,
      unlockCode: "",
      stripeCustomerId: "",
      createdAt: new Date()
    };
    
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: UpdateUser): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async updateUserChatAccess(id: string, hasAccess: boolean): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    user.chatAccess = hasAccess;
    this.users.set(id, user);
    return user;
  }

  async updateUserTrials(id: string, trials: number): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    user.aiTrialsLeft = trials;
    this.users.set(id, user);
    return user;
  }

  async verifyUnlockCode(userId: string, code: string): Promise<boolean> {
    const UNLOCK_CODE = "0814880";
    if (code === UNLOCK_CODE) {
      await this.updateUserChatAccess(userId, true);
      return true;
    }
    return false;
  }

  // Anime methods
  async getAllAnime(): Promise<Anime[]> {
    return Array.from(this.anime.values());
  }

  async getAnimeById(id: string): Promise<Anime | undefined> {
    return this.anime.get(id);
  }

  async searchAnime(query: string): Promise<Anime[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.anime.values()).filter(anime =>
      anime.title.toLowerCase().includes(lowerQuery) ||
      anime.description.toLowerCase().includes(lowerQuery) ||
      anime.genre.toLowerCase().includes(lowerQuery)
    );
  }

  async filterAnime(genre?: string, year?: number): Promise<Anime[]> {
    let results = Array.from(this.anime.values());
    
    if (genre && genre !== "All Genres") {
      results = results.filter(anime => 
        anime.genre.toLowerCase().includes(genre.toLowerCase())
      );
    }
    
    if (year) {
      results = results.filter(anime => anime.year === year);
    }
    
    return results;
  }

  async getTrendingAnime(): Promise<Anime[]> {
    return Array.from(this.anime.values())
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 3);
  }

  // Chat methods
  async getChatMessages(limit: number = 50): Promise<ChatMessage[]> {
    return this.chatMessages
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit)
      .reverse();
  }

  async createChatMessage(insertMessage: InsertChatMessage): Promise<ChatMessage> {
    const message: ChatMessage = {
      id: randomUUID(),
      userId: insertMessage.userId || null,
      username: insertMessage.username,
      message: insertMessage.message,
      messageType: insertMessage.messageType || 'text',
      fileUrl: insertMessage.fileUrl || null,
      timestamp: new Date(),
      isBot: insertMessage.isBot || false,
      aiModel: insertMessage.aiModel || null,
      replyTo: insertMessage.replyTo || null
    };
    
    this.chatMessages.push(message);
    return message;
  }

  // Payment methods
  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const id = randomUUID();
    const payment: Payment = {
      id,
      userId: insertPayment.userId,
      amount: insertPayment.amount,
      currency: insertPayment.currency || "usd",
      paymentMethod: insertPayment.paymentMethod,
      stripePaymentIntentId: insertPayment.stripePaymentIntentId || null,
      status: insertPayment.status || "pending",
      createdAt: new Date()
    };
    
    this.payments.set(id, payment);
    return payment;
  }

  async getPaymentsByUser(userId: string): Promise<Payment[]> {
    return Array.from(this.payments.values()).filter(payment => payment.userId === userId);
  }

  async updatePaymentStatus(id: string, status: string): Promise<Payment | undefined> {
    const payment = this.payments.get(id);
    if (!payment) return undefined;
    
    payment.status = status;
    this.payments.set(id, payment);
    return payment;
  }

  // Reading History methods
  async addReadingHistory(insertHistory: InsertReadingHistory): Promise<ReadingHistory> {
    const id = randomUUID();
    const history: ReadingHistory = {
      id,
      userId: insertHistory.userId,
      mangaId: insertHistory.mangaId,
      mangaTitle: insertHistory.mangaTitle,
      mangaGenres: insertHistory.mangaGenres || null,
      mangaAuthor: insertHistory.mangaAuthor || null,
      mangaRating: insertHistory.mangaRating || null,
      chaptersRead: insertHistory.chaptersRead || 0,
      totalChapters: insertHistory.totalChapters || 0,
      lastReadAt: new Date(),
      completedAt: insertHistory.completedAt || null,
      isFavorite: insertHistory.isFavorite || false,
      readingTime: insertHistory.readingTime || 0
    };
    
    this.readingHistory.set(id, history);
    return history;
  }

  async getReadingHistory(userId: string): Promise<ReadingHistory[]> {
    return Array.from(this.readingHistory.values())
      .filter(history => history.userId === userId)
      .sort((a, b) => b.lastReadAt.getTime() - a.lastReadAt.getTime());
  }

  async updateReadingProgress(userId: string, mangaId: string, chaptersRead: number, readingTime?: number): Promise<ReadingHistory | undefined> {
    const history = Array.from(this.readingHistory.values())
      .find(h => h.userId === userId && h.mangaId === mangaId);
    
    if (!history) return undefined;
    
    history.chaptersRead = chaptersRead;
    history.lastReadAt = new Date();
    if (readingTime) history.readingTime += readingTime;
    
    this.readingHistory.set(history.id, history);
    return history;
  }

  async markAsCompleted(userId: string, mangaId: string): Promise<ReadingHistory | undefined> {
    const history = Array.from(this.readingHistory.values())
      .find(h => h.userId === userId && h.mangaId === mangaId);
    
    if (!history) return undefined;
    
    history.completedAt = new Date();
    this.readingHistory.set(history.id, history);
    return history;
  }

  async toggleFavorite(userId: string, mangaId: string): Promise<ReadingHistory | undefined> {
    const history = Array.from(this.readingHistory.values())
      .find(h => h.userId === userId && h.mangaId === mangaId);
    
    if (!history) return undefined;
    
    history.isFavorite = !history.isFavorite;
    this.readingHistory.set(history.id, history);
    return history;
  }

  // Recommendation methods
  async generateRecommendations(userId: string): Promise<Recommendation[]> {
    const userHistory = await this.getReadingHistory(userId);
    if (userHistory.length === 0) return [];

    // Analyze user preferences
    const genreFrequency = new Map<string, number>();
    const authorFrequency = new Map<string, number>();
    let totalRating = 0;
    let ratedCount = 0;

    userHistory.forEach(history => {
      // Count genres
      if (history.mangaGenres) {
        history.mangaGenres.forEach(genre => {
          genreFrequency.set(genre, (genreFrequency.get(genre) || 0) + 1);
        });
      }
      
      // Count authors
      if (history.mangaAuthor) {
        authorFrequency.set(history.mangaAuthor, (authorFrequency.get(history.mangaAuthor) || 0) + 1);
      }
      
      // Calculate average rating preference
      if (history.mangaRating) {
        totalRating += history.mangaRating;
        ratedCount++;
      }
    });

    const avgRatingPreference = ratedCount > 0 ? totalRating / ratedCount : 4.0;
    const favoriteGenres = Array.from(genreFrequency.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 3)
      .map(([genre]) => genre);

    // Create sample recommendations based on preferences
    const recommendations: Recommendation[] = [
      {
        id: randomUUID(),
        userId,
        mangaId: "rec_1",
        mangaTitle: "Recommended: Action Adventure",
        mangaGenres: favoriteGenres.length > 0 ? [favoriteGenres[0], "Adventure"] : ["Action", "Adventure"],
        mangaAuthor: "Popular Author",
        mangaRating: Math.min(avgRatingPreference + 0.2, 5.0),
        score: 95,
        reason: `Based on your love for ${favoriteGenres[0] || "action"} manga`,
        basedOnManga: userHistory.slice(0, 2).map(h => h.mangaTitle),
        createdAt: new Date(),
        isViewed: false
      },
      {
        id: randomUUID(),
        userId,
        mangaId: "rec_2", 
        mangaTitle: "Trending: Popular Series",
        mangaGenres: favoriteGenres.length > 1 ? [favoriteGenres[1], "Romance"] : ["Romance", "Drama"],
        mangaAuthor: "Trending Author",
        mangaRating: avgRatingPreference,
        score: 88,
        reason: `High-rated series similar to your reading pattern`,
        basedOnManga: userHistory.slice(0, 3).map(h => h.mangaTitle),
        createdAt: new Date(),
        isViewed: false
      }
    ];

    // Store recommendations
    recommendations.forEach(rec => {
      this.recommendations.set(rec.id, rec);
    });

    return recommendations;
  }

  async getRecommendations(userId: string): Promise<Recommendation[]> {
    return Array.from(this.recommendations.values())
      .filter(rec => rec.userId === userId)
      .sort((a, b) => b.score - a.score);
  }

  async markRecommendationViewed(userId: string, recommendationId: string): Promise<void> {
    const recommendation = this.recommendations.get(recommendationId);
    if (recommendation && recommendation.userId === userId) {
      recommendation.isViewed = true;
      this.recommendations.set(recommendationId, recommendation);
    }
  }

  async createRecommendation(insertRecommendation: InsertRecommendation): Promise<Recommendation> {
    const id = randomUUID();
    const recommendation: Recommendation = {
      id,
      userId: insertRecommendation.userId,
      mangaId: insertRecommendation.mangaId,
      mangaTitle: insertRecommendation.mangaTitle,
      mangaGenres: insertRecommendation.mangaGenres || null,
      mangaAuthor: insertRecommendation.mangaAuthor || null,
      mangaRating: insertRecommendation.mangaRating || null,
      score: insertRecommendation.score,
      reason: insertRecommendation.reason || null,
      basedOnManga: insertRecommendation.basedOnManga || null,
      createdAt: new Date(),
      isViewed: insertRecommendation.isViewed || false
    };
    
    this.recommendations.set(id, recommendation);
    return recommendation;
  }
}

// Use memory storage for development
console.log("Using memory storage for development");
export const storage: IStorage = new MemStorage();