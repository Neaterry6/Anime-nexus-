import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { Request, Response, NextFunction } from "express";
import { storage } from "./storage";

const JWT_SECRET = process.env.JWT_SECRET || "fallback-secret-key";

export interface AuthRequest extends Request {
  user?: {
    id: string;
    username: string;
    email: string;
    isPremium: boolean;
    chatAccess: boolean;
    aiTrialsLeft: number;
  };
}

export const hashPassword = async (password: string): Promise<string> => {
  return await bcrypt.hash(password, 12);
};

export const comparePassword = async (password: string, hash: string): Promise<boolean> => {
  return await bcrypt.compare(password, hash);
};

export const generateToken = (userId: string): string => {
  return jwt.sign({ userId }, JWT_SECRET, { expiresIn: "7d" });
};

export const authenticateToken = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return res.status(401).json({ error: "Access token required" });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
    const user = await storage.getUser(decoded.userId);
    
    if (!user) {
      return res.status(401).json({ error: "User not found" });
    }

    req.user = {
      id: user.id,
      username: user.username,
      email: user.email,
      isPremium: user.isPremium,
      chatAccess: user.chatAccess,
      aiTrialsLeft: user.aiTrialsLeft,
    };
    
    next();
  } catch (error) {
    return res.status(403).json({ error: "Invalid token" });
  }
};

export const optionalAuth = async (req: AuthRequest, res: Response, next: NextFunction) => {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(" ")[1];

  if (!token) {
    return next();
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
    const user = await storage.getUser(decoded.userId);
    
    if (user) {
      req.user = {
        id: user.id,
        username: user.username,
        email: user.email,
        isPremium: user.isPremium,
        chatAccess: user.chatAccess,
        aiTrialsLeft: user.aiTrialsLeft,
      };
    }
  } catch (error) {
    // Ignore invalid tokens for optional auth
  }

  next();
};

export const authenticateRequest = (authHeader?: string) => {
  if (!authHeader) return null;
  
  const token = authHeader.split(" ")[1];
  if (!token) return null;

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
    return { id: decoded.userId, username: decoded.userId }; // This will be enriched in route handlers
  } catch (error) {
    return null;
  }
};

export const registerUser = async (userData: { username: string; email: string; password: string }) => {
  // Check if user already exists
  const existingUser = await storage.getUserByEmail(userData.email);
  if (existingUser) {
    throw new Error("User already exists with this email");
  }

  const existingUsername = await storage.getUserByUsername(userData.username);
  if (existingUsername) {
    throw new Error("Username already taken");
  }

  // Create new user
  const user = await storage.createUser(userData);
  const token = generateToken(user.id);

  return { user, token };
};

export const loginUser = async (credentials: { email: string; password: string }) => {
  const user = await storage.getUserByEmail(credentials.email);
  if (!user) {
    throw new Error("Invalid credentials");
  }

  const isValidPassword = await comparePassword(credentials.password, user.password);
  if (!isValidPassword) {
    throw new Error("Invalid credentials");
  }

  const token = generateToken(user.id);
  return { user, token };
};