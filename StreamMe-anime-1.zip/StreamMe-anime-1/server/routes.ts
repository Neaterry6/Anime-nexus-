import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import multer, { FileFilterCallback } from "multer";
import { storage } from "./storage";
import { authenticateRequest, registerUser, loginUser } from "./auth";
import { getAIResponse, AVAILABLE_MODELS } from "./ai-services";
import { insertChatMessageSchema, insertUserSchema, loginUserSchema, updateUserSchema } from "@shared/schema";
import jwt from "jsonwebtoken";

// Configure multer for file uploads
const upload = multer({
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
  fileFilter: (req: Request, file: Express.Multer.File, cb: FileFilterCallback) => {
    if (file.mimetype.startsWith('image/') || file.mimetype.startsWith('audio/') || file.mimetype.startsWith('video/')) {
      cb(null, true);
    } else {
      cb(new Error('Invalid file type'));
    }
  }
});

// Store WebSocket connections
const clients = new Set<WebSocket>();

export function registerRoutes(app: Express): Server {
  // Authentication routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const { user, token } = await registerUser(userData);
      
      res.status(201).json({
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          avatar: user.avatar,
          bio: user.bio,
          isPremium: user.isPremium,
          chatAccess: user.chatAccess,
          aiTrialsLeft: user.aiTrialsLeft
        },
        token
      });
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const credentials = loginUserSchema.parse(req.body);
      const { user, token } = await loginUser(credentials);
      
      res.json({
        user: {
          id: user.id,
          username: user.username,
          email: user.email,
          avatar: user.avatar,
          bio: user.bio,
          isPremium: user.isPremium,
          chatAccess: user.chatAccess,
          aiTrialsLeft: user.aiTrialsLeft
        },
        token
      });
    } catch (error) {
      res.status(401).json({ error: error instanceof Error ? error.message : "Login failed" });
    }
  });

  // Admin Authentication Routes
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      // Simple admin credential validation
      if (email === "akewusholaabdulbakri101@gmail.com" && password === "Makemoney@11") {
        const adminToken = jwt.sign(
          { 
            id: "admin", 
            email: email,
            role: "admin"
          },
          process.env.JWT_SECRET || "fallback-secret",
          { expiresIn: "7d" }
        );
        
        res.json({
          admin: {
            id: "admin",
            email: email,
            role: "admin",
            lastLogin: new Date()
          },
          token: adminToken
        });
      } else {
        res.status(401).json({ error: "Invalid admin credentials" });
      }
    } catch (error) {
      res.status(400).json({ error: "Admin login failed" });
    }
  });

  app.get("/api/admin/verify", async (req, res) => {
    try {
      const token = req.headers.authorization?.replace("Bearer ", "");
      if (!token) {
        return res.status(401).json({ error: "No admin token provided" });
      }
      
      const decoded = jwt.verify(token, process.env.JWT_SECRET || "fallback-secret") as any;
      if (decoded.role === "admin") {
        res.json({
          admin: {
            id: decoded.id,
            email: decoded.email,
            role: decoded.role
          }
        });
      } else {
        res.status(403).json({ error: "Not an admin" });
      }
    } catch (error) {
      res.status(401).json({ error: "Invalid admin token" });
    }
  });

  app.get("/api/auth/me", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }
      
      const fullUser = await storage.getUser(user.id);
      if (!fullUser) {
        return res.status(404).json({ error: "User not found" });
      }
      
      res.json({
        id: fullUser.id,
        username: fullUser.username,
        email: fullUser.email,
        avatar: fullUser.avatar,
        bio: fullUser.bio,
        isPremium: fullUser.isPremium,
        chatAccess: fullUser.chatAccess,
        aiTrialsLeft: fullUser.aiTrialsLeft
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch user data" });
    }
  });

  // User profile routes
  app.put("/api/user/profile", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const updates = updateUserSchema.parse(req.body);
      const updatedUser = await storage.updateUser(user.id, updates);
      
      if (!updatedUser) {
        return res.status(404).json({ error: "User not found" });
      }

      res.json({
        id: updatedUser.id,
        username: updatedUser.username,
        email: updatedUser.email,
        avatar: updatedUser.avatar,
        bio: updatedUser.bio,
        isPremium: updatedUser.isPremium,
        chatAccess: updatedUser.chatAccess,
        aiTrialsLeft: updatedUser.aiTrialsLeft
      });
    } catch (error) {
      res.status(400).json({ error: "Failed to update profile" });
    }
  });

  // Unlock code verification
  app.post("/api/unlock-code", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const { code } = req.body;
      const isValid = await storage.verifyUnlockCode(user.id, code);
      
      if (isValid) {
        res.json({ success: true, message: "Chat access granted!" });
      } else {
        res.status(400).json({ error: "Invalid unlock code. Contact WhatsApp +2348039896597 to purchase codes." });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to verify unlock code" });
    }
  });

  // Anime routes using zetsu.xyz API only

  // Anime search using zetsu.xyz API
  app.get('/api/anime/search', async (req, res) => {
    try {
      const { q } = req.query;
      if (!q) {
        return res.status(400).json({ error: 'Search query required' });
      }

      const apiKey = 'dbcbb1d2cd6121874d41b092f4d93a61';
      const searchUrl = `https://api.zetsu.xyz/animesu/search?q=${encodeURIComponent(q as string)}&apikey=${apiKey}`;
      
      console.log('Searching anime with URL:', searchUrl);
      
      const response = await fetch(searchUrl);
      const data = await response.json();
      
      console.log('API Response status:', response.status);
      console.log('API Response data:', data);
      
      if (!response.ok || !data.status) {
        throw new Error(`API error: ${response.status} - ${data.message || 'Unknown error'}`);
      }
      
      res.json(data);
    } catch (error) {
      console.error('Error searching anime:', error);
      res.status(500).json({ error: 'Failed to search anime', details: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Anime details using zetsu.xyz API
  app.get('/api/anime/detail', async (req, res) => {
    try {
      const { url } = req.query;
      if (!url) {
        return res.status(400).json({ error: 'Anime URL required' });
      }

      const apiKey = 'dbcbb1d2cd6121874d41b092f4d93a61';
      const detailUrl = `https://api.zetsu.xyz/animesu/detail?url=${encodeURIComponent(url as string)}&apikey=${apiKey}`;
      
      console.log('Fetching anime details with URL:', detailUrl);
      
      const response = await fetch(detailUrl);
      const data = await response.json();
      
      console.log('Detail API Response status:', response.status);
      console.log('Detail API Response data:', data);
      
      if (!response.ok || !data.status) {
        throw new Error(`API error: ${response.status} - ${data.message || 'Unknown error'}`);
      }
      
      res.json(data);
    } catch (error) {
      console.error('Error fetching anime details:', error);
      res.status(500).json({ error: 'Failed to fetch anime details', details: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Episode download using zetsu.xyz API
  app.get('/api/anime/download-episode', async (req, res) => {
    try {
      const { url } = req.query;
      if (!url) {
        return res.status(400).json({ error: 'Episode URL required' });
      }

      const apiKey = 'dbcbb1d2cd6121874d41b092f4d93a61';
      const downloadUrl = `https://api.zetsu.xyz/animesu/download?url=${encodeURIComponent(url as string)}&apikey=${apiKey}`;
      
      console.log('Fetching episode downloads with URL:', downloadUrl);
      
      const response = await fetch(downloadUrl);
      const data = await response.json();
      
      console.log('Download API Response status:', response.status);
      console.log('Download API Response data:', data);
      
      if (!response.ok || !data.status) {
        throw new Error(`API error: ${response.status} - ${data.message || 'Unknown error'}`);
      }
      
      res.json(data);
    } catch (error) {
      console.error('Error fetching download links:', error);
      res.status(500).json({ error: 'Failed to fetch download links', details: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Get trending anime
  app.get('/api/anime/trending', async (req, res) => {
    try {
      const apiKey = 'dbcbb1d2cd6121874d41b092f4d93a61';
      
      // Use varied trending anime titles for more diverse results
      const allTrendingQueries = [
        'demon slayer', 'attack on titan', 'one piece', 'naruto', 'dragon ball', 'jujutsu kaisen',
        'solo leveling', 'chainsaw man', 'spy family', 'mob psycho', 'hunter x hunter', 'bleach',
        'tokyo ghoul', 'fullmetal alchemist', 'death note', 'one punch man', 'my hero academia',
        'overlord', 'konosuba', 'black clover', 'fire force', 'tokyo revengers'
      ];
      
      // Randomly select 6 queries for variety
      const shuffledQueries = allTrendingQueries.sort(() => Math.random() - 0.5);
      const selectedQueries = shuffledQueries.slice(0, 6);
      
      console.log('Fetching trending anime with queries:', selectedQueries);
      
      const trendingResults = [];
      
      for (const query of selectedQueries) {
        try {
          const searchUrl = `https://api.zetsu.xyz/animesu/search?q=${encodeURIComponent(query)}&apikey=${apiKey}`;
          console.log(`Searching for trending: ${query}`);
          
          const response = await fetch(searchUrl);
          const data = await response.json();
          
          console.log(`Trending search result for "${query}":`, data.status, data.result?.length || 0, 'results');
          
          if (response.ok && data.status && data.result && data.result.length > 0) {
            // Take the first result for each query
            trendingResults.push(data.result[0]);
          }
        } catch (error) {
          console.error(`Error fetching trending anime for query ${query}:`, error);
        }
      }
      
      console.log(`Successfully fetched ${trendingResults.length} trending anime`);
      res.json({ status: true, result: trendingResults, author: 'Deku' });
    } catch (error) {
      console.error('Error fetching trending anime:', error);
      res.status(500).json({ error: 'Failed to fetch trending anime', details: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  // Get subbed anime
  app.get('/api/anime/subbed', async (req, res) => {
    try {
      const apiKey = 'dbcbb1d2cd6121874d41b092f4d93a61';
      
      // Use popular subbed/classic anime titles
      const allSubbedQueries = [
        'spirited away', 'your name', 'princess mononoke', 'akira', 'ghost in the shell', 'cowboy bebop',
        'neon genesis evangelion', 'perfect blue', 'grave of the fireflies', 'castle in the sky',
        'howls moving castle', 'totoro', 'violet evergarden', 'weathering with you', 'kiki delivery service',
        'porco rosso', 'nausicaa', 'wolf children', 'summer wars', 'paprika'
      ];
      
      // Randomly select 6 queries for variety
      const shuffledQueries = allSubbedQueries.sort(() => Math.random() - 0.5);
      const selectedQueries = shuffledQueries.slice(0, 6);
      
      console.log('Fetching subbed anime with queries:', selectedQueries);
      
      const subbedResults = [];
      
      for (const query of selectedQueries) {
        try {
          const searchUrl = `https://api.zetsu.xyz/animesu/search?q=${encodeURIComponent(query)}&apikey=${apiKey}`;
          console.log(`Searching for subbed: ${query}`);
          
          const response = await fetch(searchUrl);
          const data = await response.json();
          
          console.log(`Subbed search result for "${query}":`, data.status, data.result?.length || 0, 'results');
          
          if (response.ok && data.status && data.result && data.result.length > 0) {
            // Take the first result for each query
            subbedResults.push(data.result[0]);
          }
        } catch (error) {
          console.error(`Error fetching subbed anime for query ${query}:`, error);
        }
      }
      
      console.log(`Successfully fetched ${subbedResults.length} subbed anime`);
      res.json({ status: true, result: subbedResults, author: 'Deku' });
    } catch (error) {
      console.error('Error fetching subbed anime:', error);
      res.status(500).json({ error: 'Failed to fetch subbed anime', details: error instanceof Error ? error.message : 'Unknown error' });
    }
  });

  app.get("/api/anime/:id", async (req, res) => {
    try {
      const anime = await storage.getAnimeById(req.params.id);
      if (!anime) {
        return res.status(404).json({ error: "Anime not found" });
      }
      res.json(anime);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch anime" });
    }
  });

  // Chat routes with authentication
  app.get("/api/chat/messages", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const fullUser = await storage.getUser(user.id);
      if (!fullUser?.chatAccess) {
        return res.status(403).json({ error: "Chat access required. Contact WhatsApp +2348039896597 for unlock code" });
      }

      const messages = await storage.getChatMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  app.post("/api/chat/messages", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const fullUser = await storage.getUser(user.id);
      if (!fullUser?.chatAccess) {
        return res.status(403).json({ error: "Chat access required" });
      }

      const messageData = insertChatMessageSchema.parse({
        ...req.body,
        userId: user.id,
        username: user.username
      });
      
      const message = await storage.createChatMessage(messageData);
      
      // Broadcast to all connected WebSocket clients
      const messageToSend = JSON.stringify({
        type: 'new_message',
        data: message
      });
      
      clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(messageToSend);
        }
      });

      res.status(201).json(message);
    } catch (error) {
      res.status(400).json({ error: "Invalid message data" });
    }
  });

  // AI chat endpoint
  app.post("/api/ai/chat", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const fullUser = await storage.getUser(user.id);
      if (!fullUser?.chatAccess) {
        return res.status(403).json({ error: "Chat access required. Please enter your unlock code first." });
      }

      const { model, prompt, imageUrl, sessionId } = req.body;
      if (!model || !prompt) {
        return res.status(400).json({ error: "Model and prompt are required" });
      }

      // Check trials for non-premium users
      if (!fullUser.isPremium && fullUser.aiTrialsLeft <= 0) {
        return res.status(402).json({ error: "No AI trials remaining. Contact WhatsApp +2348039896597 to purchase more unlock codes." });
      }

      const aiResponse = await getAIResponse(model, prompt, imageUrl, sessionId);
      
      // Deduct trial if not premium
      if (!fullUser.isPremium) {
        await storage.updateUserTrials(user.id, fullUser.aiTrialsLeft - 1);
      }

      // Save AI response as chat message
      const aiMessage = await storage.createChatMessage({
        userId: null,
        username: `AI (${aiResponse.model})`,
        message: aiResponse.response,
        messageType: aiResponse.imageUrl ? 'image' : 'text',
        isBot: true,
        aiModel: aiResponse.model
      });

      // Broadcast AI response to all clients
      const messageToSend = JSON.stringify({
        type: 'new_message',
        data: aiMessage
      });
      
      clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
          client.send(messageToSend);
        }
      });

      res.json({
        response: aiResponse.response,
        model: aiResponse.model,
        imageUrl: aiResponse.imageUrl
      });
    } catch (error) {
      res.status(500).json({ error: error instanceof Error ? error.message : "AI request failed" });
    }
  });

  // Get available AI models
  app.get("/api/ai/models", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      const fullUser = await storage.getUser(user.id);
      if (!fullUser?.chatAccess) {
        return res.status(403).json({ error: "Chat access required" });
      }

      res.json({
        models: AVAILABLE_MODELS,
        userTrials: fullUser.aiTrialsLeft,
        isPremium: fullUser.isPremium
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch AI models" });
    }
  });

  // File upload endpoint
  app.post("/api/upload", upload.single('file'), async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Unauthorized" });
      }

      if (!req.file) {
        return res.status(400).json({ error: "No file uploaded" });
      }

      // Return data URL for immediate use in chatbot
      const fileUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
      res.json({ url: fileUrl });
    } catch (error) {
      res.status(500).json({ error: "File upload failed" });
    }
  });

  // Removed Stripe payment - using unlock codes only

  // Stats endpoint
  app.get("/api/stats", async (req, res) => {
    try {
      const allAnime = await storage.getAllAnime();
      const messages = await storage.getChatMessages();
      
      const stats = {
        totalAnime: allAnime.length,
        activeUsers: Math.floor(Math.random() * 2000) + 10000,
        downloadsToday: Math.floor(Math.random() * 10000) + 40000,
        onlineNow: Math.floor(Math.random() * 500) + 1500
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch stats" });
    }
  });

  // MangaDx API proxy endpoints to avoid CORS issues
  app.get("/api/manga/trending", async (req, res) => {
    try {
      const { page = 1, genre, search } = req.query;
      const offset = ((page as number) - 1) * 20;
      
      let url = `https://api.mangadex.org/manga?limit=20&offset=${offset}&order[followedCount]=desc&includes[]=cover_art&includes[]=author`;
      
      // Add genre filter if provided
      if (genre && genre !== 'all') {
        const genreIds: { [key: string]: string } = {
          'Action': '391b0423-d847-456f-aff0-8b0cfc03066b',
          'Romance': '423e2eae-a7a2-4a8b-ac03-a8351462d71d', 
          'Fantasy': 'cdc58593-87dd-415e-bbc0-2ec27bf404cc',
          'Comedy': '4d32cc48-9f00-4cca-9b5a-a839f0764984',
          'Drama': 'b9af3a63-f058-46de-a9a0-e0c13906197a'
        };
        
        if (genreIds[genre as string]) {
          url += `&includedTags[]=${genreIds[genre as string]}`;
        }
      }

      const response = await fetch(url);
      
      if (!response.ok) {
        throw new Error(`MangaDx API error: ${response.status}`);
      }

      const data = await response.json();
      
      // Transform data for frontend
      const mangaItems = data.data?.map((manga: any) => {
        const cover = manga.relationships.find((r: any) => r.type === 'cover_art');
        const author = manga.relationships.find((r: any) => r.type === 'author');
        const fileName = cover?.attributes?.fileName;
        const coverUrl = fileName 
          ? `https://uploads.mangadex.org/covers/${manga.id}/${fileName}.256.jpg`
          : null;

        return {
          id: manga.id,
          title: manga.attributes.title.en || manga.attributes.title.ja || 'No Title',
          description: manga.attributes.description.en || 'No description available',
          coverUrl,
          status: manga.attributes.status,
          author: author?.attributes?.name || 'Unknown',
          year: manga.attributes.year,
          tags: manga.attributes.tags?.map((tag: any) => tag.attributes.name.en).slice(0, 3) || []
        };
      }) || [];

      // Filter by search query if provided
      const filteredManga = search 
        ? mangaItems.filter((manga: any) => 
            manga.title.toLowerCase().includes((search as string).toLowerCase())
          )
        : mangaItems;

      res.json({
        data: filteredManga,
        total: data.total || 0
      });
      
    } catch (error) {
      console.error("Error in manga trending proxy:", error);
      res.status(500).json({ error: "Failed to fetch manga" });
    }
  });

  app.get("/api/manga/:id/chapters", async (req, res) => {
    try {
      const { id } = req.params;
      
      const response = await fetch(
        `https://api.mangadex.org/chapter?manga=${id}&translatedLanguage[]=en&order[chapter]=asc&limit=100`
      );
      
      if (!response.ok) {
        throw new Error(`MangaDx chapters API error: ${response.status}`);
      }
      
      const data = await response.json();
      
      const chapters = data.data?.map((chapter: any, index: number) => ({
        id: chapter.id,
        number: chapter.attributes.chapter || (index + 1).toString(),
        title: chapter.attributes.title || '',
        pages: chapter.attributes.pages,
        translatedLanguage: chapter.attributes.translatedLanguage
      })) || [];
      
      res.json({ chapters });
      
    } catch (error) {
      console.error("Error in manga chapters proxy:", error);
      res.status(500).json({ error: "Failed to fetch chapters" });
    }
  });

  app.get("/api/manga/chapter/:id/pages", async (req, res) => {
    try {
      const { id } = req.params;
      
      const response = await fetch(`https://api.mangadex.org/at-home/server/${id}`);
      
      if (!response.ok) {
        throw new Error(`MangaDx chapter pages API error: ${response.status}`);
      }
      
      const data = await response.json();
      const { baseUrl, chapter } = data;
      
      const pages = chapter.data?.map((filename: string) => 
        `${baseUrl}/data/${chapter.hash}/${filename}`
      ) || [];
      
      console.log(`Chapter ${id}: Found ${pages.length} pages`);
      
      res.json({
        data: pages,
        pages,
        hash: chapter.hash,
        baseUrl,
        total: pages.length
      });
      
    } catch (error) {
      console.error("Error in manga chapter pages proxy:", error);
      res.status(500).json({ error: "Failed to fetch chapter pages" });
    }
  });

  app.get("/api/manga/:id", async (req, res) => {
    try {
      const { id } = req.params;
      
      const response = await fetch(`https://api.mangadex.org/manga/${id}?includes[]=cover_art&includes[]=author`);
      
      if (!response.ok) {
        throw new Error(`MangaDx manga API error: ${response.status}`);
      }
      
      const data = await response.json();
      const manga = data.data;
      
      const cover = manga.relationships.find((r: any) => r.type === 'cover_art');
      const author = manga.relationships.find((r: any) => r.type === 'author');
      const fileName = cover?.attributes?.fileName;
      const coverUrl = fileName 
        ? `https://uploads.mangadex.org/covers/${manga.id}/${fileName}`
        : null;

      const mangaItem = {
        id: manga.id,
        title: manga.attributes.title.en || manga.attributes.title.ja || 'No Title',
        description: manga.attributes.description.en || 'No description available',
        coverUrl,
        status: manga.attributes.status,
        author: author?.attributes?.name || 'Unknown',
        year: manga.attributes.year,
        tags: manga.attributes.tags?.map((tag: any) => tag.attributes.name.en) || []
      };

      res.json({ manga: mangaItem });
      
    } catch (error) {
      console.error("Error in manga detail proxy:", error);
      res.status(500).json({ error: "Failed to fetch manga details" });
    }
  });

  const httpServer = createServer(app);
  
  // WebSocket server for real-time chat
  const wss = new WebSocketServer({ 
    server: httpServer, 
    path: '/ws' 
  });

  wss.on('connection', (ws) => {
    console.log('New WebSocket connection');
    clients.add(ws);

    ws.on('message', async (data) => {
      try {
        const message = JSON.parse(data.toString());
        
        if (message.type === 'auth') {
          const user = authenticateRequest(`Bearer ${message.token}`);
          if (user) {
            ws.send(JSON.stringify({ type: 'auth_success', user }));
          } else {
            ws.send(JSON.stringify({ type: 'auth_error', error: 'Invalid token' }));
          }
        }
        
        if (message.type === 'reply') {
          // Handle message replies
          const user = authenticateRequest(`Bearer ${message.token}`);
          if (user) {
            const replyMessage = await storage.createChatMessage({
              userId: user.id,
              username: user.username,
              message: message.content,
              messageType: 'reply',
              replyTo: message.replyTo
            });

            const messageToSend = JSON.stringify({
              type: 'new_message',
              data: replyMessage
            });
            
            clients.forEach(client => {
              if (client.readyState === WebSocket.OPEN) {
                client.send(messageToSend);
              }
            });
          }
        }
      } catch (error) {
        console.error('WebSocket message error:', error);
      }
    });

    ws.on('close', () => {
      console.log('WebSocket connection closed');
      clients.delete(ws);
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });

  // Reading History routes
  app.post("/api/reading-history", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Authentication required" });
      }

      const historyData = {
        userId: user.id,
        ...req.body
      };

      const history = await storage.addReadingHistory(historyData);
      res.status(201).json(history);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : "Failed to add reading history" });
    }
  });

  app.get("/api/reading-history", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Authentication required" });
      }

      const history = await storage.getReadingHistory(user.id);
      res.json(history);
    } catch (error) {
      res.status(500).json({ error: "Failed to get reading history" });
    }
  });

  app.put("/api/reading-history/:mangaId/progress", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Authentication required" });
      }

      const { mangaId } = req.params;
      const { chaptersRead, readingTime } = req.body;

      const history = await storage.updateReadingProgress(user.id, mangaId, chaptersRead, readingTime);
      if (!history) {
        return res.status(404).json({ error: "Reading history not found" });
      }

      res.json(history);
    } catch (error) {
      res.status(400).json({ error: "Failed to update reading progress" });
    }
  });

  app.put("/api/reading-history/:mangaId/favorite", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Authentication required" });
      }

      const { mangaId } = req.params;
      const history = await storage.toggleFavorite(user.id, mangaId);
      
      if (!history) {
        return res.status(404).json({ error: "Reading history not found" });
      }

      res.json(history);
    } catch (error) {
      res.status(400).json({ error: "Failed to toggle favorite" });
    }
  });

  // Recommendation routes
  app.get("/api/recommendations", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Authentication required" });
      }

      const recommendations = await storage.getRecommendations(user.id);
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ error: "Failed to get recommendations" });
    }
  });

  app.post("/api/recommendations/generate", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Authentication required" });
      }

      const recommendations = await storage.generateRecommendations(user.id);
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ error: "Failed to generate recommendations" });
    }
  });

  app.put("/api/recommendations/:recommendationId/viewed", async (req, res) => {
    try {
      const user = authenticateRequest(req.headers.authorization);
      if (!user) {
        return res.status(401).json({ error: "Authentication required" });
      }

      const { recommendationId } = req.params;
      await storage.markRecommendationViewed(user.id, recommendationId);
      res.json({ success: true });
    } catch (error) {
      res.status(400).json({ error: "Failed to mark recommendation as viewed" });
    }
  });

  return httpServer;
}