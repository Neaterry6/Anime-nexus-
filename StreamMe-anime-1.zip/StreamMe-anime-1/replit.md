# Overview

StreamMe Anime is a comprehensive anime streaming and community platform built with React, TypeScript, and Express.js. The application serves as a complete entertainment hub featuring anime catalog browsing, real-time chat with WebSocket communication, multi-AI chatbot integration, user authentication, and unlock code system. Users can browse anime content, engage in live community discussions, interact with multiple AI models (Gemini, Grok, Image Generation), and access premium features through unlock codes.

## Recent Updates (January 2025)

✅ **Complete Application Implementation**
- Fixed all server import errors and authentication system
- Implemented in-memory storage as fallback for development
- Created working authentication with JWT tokens
- Built functional real-time chat with WebSocket communication
- Added AI chatbot integration with multiple models
- Implemented unlock code system (contact WhatsApp for codes)
- Created complete anime catalog with search and filtering
- Added anime-themed styling and responsive design
- **NEW**: Added complete login/signup pages with beautiful UI
- **NEW**: Built comprehensive settings page with profile, premium, notifications, security tabs
- **NEW**: Created detailed profile page with user stats, achievements, and account info
- **NEW**: Enhanced header navigation with user dropdown menu
- **NEW**: All pages fully responsive and anime-themed
- **NEW**: Added Movies & Music Hub with search and download functionality
- **NEW**: YouTube integration for music and video downloads
- **NEW**: Lyrics search feature for music content
- **NEW**: Trending movies section with ratings, reviews, and detailed information
- **NEW**: Movie review system with user ratings and like/dislike functionality
- **NEW**: Detailed movie modals with cast, director, genre, and description
- **NEW**: Interactive star rating system for user reviews
- **NEW**: Featured movies and popular music sections
- **NEW**: Dedicated AI Chatbot page with advanced conversation features
- **NEW**: Multi-model AI support (Gemini, Grok, Image Generation)
- **NEW**: Conversation history and export functionality
- **NEW**: Enhanced navigation with AI Chat and Movies buttons
- **NEW**: Quick access buttons in hero section for logged-in users
- **NEW**: Episode selection modal for anime downloads
- **NEW**: Individual episode download or batch download all episodes
- **NEW**: Enhanced movie download API integration with better error handling
- **NEW**: Real Anime API Integration - zetsu.xyz API with working search, details, and downloads
- **NEW**: Anime Detail Pages - Complete episode browsing and download functionality
- **NEW**: YouTube Music & Video Downloader - Complete YouTube search, MP3/MP4 downloads with quality selection
- **NEW**: Lyrics Search Integration - Real-time lyrics fetching for music content
- **NEW**: YouTube API Integration - Using kaiz-apis.gleeze.com with multiple download formats
- **NEW**: Quality Selection Modal - Choose video quality (360p, 720p, 1080p) before download
- **NEW**: Download Progress Tracking - Visual progress indicators for all downloads
- **NEW**: Complete Manga Reader - MangaDex API integration with proper image loading and chapter navigation
- **NEW**: Manga Favorites System - Save and organize favorite manga titles with localStorage
- **NEW**: Manga Bookmarks - Chapter-level bookmarking with reading progress tracking
- **NEW**: Fullscreen Manga Reader - Immersive reading experience with fullscreen support
- **NEW**: Infinite Scroll Manga Loading - Seamless browsing with automatic content loading
- **NEW**: Personalized Recommendation Engine - AI-powered recommendations based on user reading history, genre preferences, and completion rates
- **NEW**: Reading History Tracking - Comprehensive tracking of manga reading progress, completion status, and reading time
- **NEW**: Smart Recommendations - Genre analysis, author preferences, and rating-based suggestions with explanations
- **NEW**: FAQ Page - Comprehensive app information, feature descriptions, developer portfolio link, and user support
- **NEW**: Enhanced Manga Experience - Continue reading section, progress tracking, and personalized content discovery
- **NEW**: Vercel Deployment Ready - Optimized configuration for production deployment
- All features now fully functional and tested

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The frontend is built with React 18 and TypeScript, utilizing Vite as the build tool for fast development and optimized production builds. The application follows a component-based architecture with:

- **UI Framework**: Radix UI components with shadcn/ui for consistent, accessible design system
- **Styling**: Tailwind CSS with custom anime-themed color variables and animations
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management and data fetching
- **Form Handling**: React Hook Form with Zod for validation

The application uses a single-page architecture with smooth scrolling navigation between sections (home, catalog, chat, trending) rather than separate routes.

## Backend Architecture
The backend follows a RESTful API design using Express.js with TypeScript:

- **Server Framework**: Express.js with custom middleware for request logging and error handling
- **Database Layer**: Currently using in-memory storage (MemStorage class) with plans for PostgreSQL integration
- **API Design**: RESTful endpoints organized by feature (anime, chat, stats)
- **Development**: Hot module replacement and middleware integration with Vite for seamless development experience

## Data Storage Solutions
The application uses in-memory storage for development with MongoDB/PostgreSQL schema compatibility:

- **Development Storage**: MemStorage class with full CRUD operations
- **Schema**: Type-safe database schemas defined in shared/schema.ts  
- **Tables**: Users, anime catalog, chat messages, and payments
- **Validation**: Zod schemas for runtime type checking and API validation
- **Fallback**: Graceful fallback from MongoDB to memory storage

## Authentication and Authorization
Fully implemented JWT-based authentication system:

- **User Management**: Complete user registration, login, and profile management
- **JWT Tokens**: Secure token-based authentication with 7-day expiration
- **Password Security**: bcrypt password hashing
- **Route Protection**: Middleware for protected API endpoints
- **Chat Access**: Unlock code system for premium chat features

## External Service Integrations
The application is designed to work with:

- **Database**: Neon Database (PostgreSQL) for production data storage
- **Image Hosting**: Currently uses Unsplash for anime cover images
- **Development Tools**: Replit-specific plugins for development environment integration
- **Build Pipeline**: ESBuild for production server bundling, Vite for client bundling

# External Dependencies

## Core Framework Dependencies
- **React 18**: Frontend framework with modern hooks and concurrent features
- **Express.js**: Backend web application framework
- **TypeScript**: Type safety across the entire application stack
- **Vite**: Frontend build tool and development server

## UI and Styling
- **Radix UI**: Comprehensive component library for accessible UI primitives
- **Tailwind CSS**: Utility-first CSS framework for custom styling
- **shadcn/ui**: Pre-built component library built on Radix UI and Tailwind
- **Class Variance Authority**: Type-safe variant API for component styling
- **Lucide React**: Icon library for consistent iconography

## Data Management
- **Drizzle ORM**: TypeScript ORM for database operations
- **TanStack Query**: Server state management and data fetching
- **Zod**: Schema validation for TypeScript
- **@neondatabase/serverless**: PostgreSQL database driver for Neon

## Development and Build Tools
- **ESBuild**: Fast JavaScript bundler for production builds
- **TSX**: TypeScript execution environment for development
- **PostCSS**: CSS processing with Tailwind CSS integration
- **Replit Plugins**: Development environment integration tools

## Additional Libraries
- **React Hook Form**: Form state management and validation
- **Date-fns**: Date manipulation and formatting utilities
- **Wouter**: Lightweight routing library for React
- **React DOM**: React rendering library for web applications